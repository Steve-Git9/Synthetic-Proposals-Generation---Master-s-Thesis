# Datasheet for SP02, synthetic project proposal

Following Gebru et al. (2021), Datasheets for Datasets. Version 1.0, release candidate. Written 2026-10-25 18:17 UTC.

## 1. Motivation

**Purpose.** SP02 is a synthetic test document for a master thesis that evaluates how well language models extract structured data from research project proposals. It tests the extraction pipeline under known, controlled difficulties, with a ground truth that is correct by construction. It is one of five documents in a set. The document is never submitted to any real call.

**Author and creation.** Created for the thesis author, Stefano Fanelli. The files were assembled by a language model (Claude) working to a written task from the researcher. Every language model contribution is recorded in SP02_generation_log.md. The model and interface details are left for the researcher to fill in.

**Funding.** No external funding is stated for the dataset.

## 2. Composition

**Instance.** One born digital PDF of 41 pages, English with European spelling, two column layout with sidebars, callout boxes, captioned figures and footnotes. Cover page, contents, executive summary, five sections and annexes (Gantt chart, work package descriptions, deliverables, risk register).

**Target fields.** Twenty values: proposal acronym, title, call identifier, funding programme, submission date (null by design), stated total requested amount, TRL start and target, MCRL start and target, and for each of the five partners the name as written in section 2.1 and the requested amount. Amounts are integers in euro cents. The answer key is SP02_answer_key.json.

**Fictional content.** All organisations, persons, projects and the call identifier are fictional. The only real name is the funding programme, Business Finland, which is a real public funder. No funding instrument is named and no real funding rule is stated. No personal data. No CVs. The five partners are listed in SP02_partner_register.csv, which is kept separate from any real partner register.

**What is crafted and what is filler.** Only three elements are crafted with care: the target fields, the distractors, and the eleven injected difficulties. Everything else is filler.

* Filler prose: 57 paragraphs in SP02_paragraph_bank.md, written once in a single pass. The build placed 213 body paragraphs (from 40 body entries, so each is used about 5 times), 40 boxes, 65 footnotes and 13 figure captions. The filler holds no numbers, dates, organisation names or acronyms.
* Filler graphics: five generic diagrams and the Gantt chart, drawn by code.
* Filler tables: work package descriptions, deliverables and risk register in the annexes, generated from the data file.
* Page furniture (sidebars, callouts, footnotes) follows a fixed rhythm from a seeded selection.
* Length is reached by adding filler sections and annexes, never by expanding the crafted parts.

**Distractors.** Total project volume including in kind contributions (executive summary callout, EUR 2,003,400); eligible costs and in kind contributions per partner (Table 5.2); percentage shares (Figure 5.2); funding that partner A received in an earlier project (section 2.1); the Document prepared date on the cover; the footer text.

## 3. Collection process

Data first, document second. SP02_draw_values.py draws every number with seed 20260314 and writes SP02_data.yaml. The document is rendered only from the data file, the template in SP02_template/ and the paragraph bank, with XeLaTeX. Every chart, the logo strip and the roadmap graphic are drawn by SP02_charts.py from the same data file; text inside the images is pixels and never enters the text layer. The build never calls a language model and is deterministic.

## 4. Preprocessing, cleaning and labelling

The answer key and the manifest are generated from the data file and the page locations found in the rendered PDF, so the key cannot drift from the document. SP02_checks.py runs 23 automatic checks (text layer, image only values, page map, consistency, filler, metadata, footer) and writes SP02_check_report.md. The authority rules are written into the answer key header.

## 5. Difficulties and their link to the literature

Issue numbers and source papers come from the thesis literature list: V = VRDU (Wang et al., 2023), D = DocILE (Šimsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanisławek et al., 2021). SP02 reproduces the type of difficulty that those works address; this datasheet does not restate their results.

| Issue | Source papers | Placement in SP02 (pages) | Difficulty |
|---|---|---|---|
| #1 | V, D, K, M | 33, 34 | Two column layout with sidebars, callout boxes, captioned figures and footnotes on most content pages. Tables and figures in section 5 span both columns. |
| #4 | D | 24, 30 | A footnote continues across the column break on one page in section 3. The MCRL sidebar box sits between the two columns, so a naive top to bottom reading interleaves it with body text. |
| #8 and #26 | M, K | 10, 33 | The requested amounts of partners D and E appear only as total labels in Figure 5.1. TRL start and TRL target appear only inside the roadmap graphic, Figure 1.1. |
| #14 | T, K | 33 | The scale EUR thousand is stated only in the column header of Table 5.1 and in the axis title of Figure 5.1. Cells and data labels show bare numbers with one decimal. |
| #15 and #16 | V, T, K | 3, 13, 34 | The callout states the total project volume including in kind contributions. Table 5.2 lists eligible costs per partner. Figure 5.2 shows percentage shares only. Section 2.1 mentions funding that partner A received in an earlier project. |
| #18 and #20 | T, M, K | 13, 33 | Table 5.1 and Figure 5.1 identify partners by acronym only. The legal names appear only in section 2.1, each followed by its acronym in brackets. Short aliases occur in the work plan. |
| #22 | V, D | 1 | The proposal title on the cover is set in large type with a forced line break in the middle. |
| #24 | K, V, D | 1, 13, 33 | Partner C is described in section 2.1, appears in Table 5.1 with the text no funding requested, and in the logo strip. It is absent from Figures 5.1 and 5.2. |
| #24 and #29 | M | 1 | The submission date is not stated anywhere. The Document prepared date on the cover is a distractor. |
| #25 | V | 33, 34 | Table 5.1 heads the partner column Organisation. Table 5.2 heads the same column Beneficiary. |
| #27 and #28 | M | 3, 30, 35 | The executive summary refers to section 5.3 for the requested funding. Section 5.3 states the total in text. The MCRL values sit deep in the document, in section 4. |

## 6. Uses

**Intended use.** An evaluation document for the extraction pipeline of the thesis, scored against SP02_answer_key.json under the authority rules in its header. Results should be reported separately for synthetic and authorised real documents.

**Not intended.** Prompt tuning. The document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning. It is not an example of a compliant application, contains no real funding rule, and must never be submitted to any call. It is not evidence about real proposals.

## 7. Distribution, licence and maintenance

**Licence.** To be decided by the researcher. Proposal for discussion: CC BY 4.0 for the document and data files, MIT for the scripts.

**Maintenance.** The thesis author maintains the files. Versions are recorded in CHANGELOG.md. After the freeze no file is edited; a change creates a new version.

## 8. Limitations

Results on documents written by the author are not evidence about real proposals. SP02 has a known answer by construction and a layout produced by one typesetting system. Filler is generic and repeated, which a real proposal would not show, and the 41 page length is reached with filler. The document only has to look plausible to a reader who skims it.

## 9. Open human steps

Visual confirmation that Figure 1.1 and Figure 5.1 are legible, blind second extraction (SP02_blind_extraction_form.md), realism review (SP02_realism_checklist.md), name check (SP02_name_check_list.md), and the freeze.
