#!/usr/bin/env python3
"""Prose check. Fails the build if model written prose holds a number, date, organisation name or acronym.

Scans the paragraph bank and the free text fields of the data file (work package titles, deliverable titles,
risk titles and mitigations). Facts may enter the document only through template placeholders.
"""
import re
import sys
import yaml

NUMBER_WORDS = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
                "twelve", "hundred", "thousand", "million", "billion", "first", "second", "third", "fourth",
                "fifth", "once", "twice", "single", "double", "half", "dozen"}
FORBIDDEN = {"submission", "submitted", "submit", "deadline", "euro", "euros", "eur", "percent", "trl", "mcrl",
             "readiness"}
MONTHS = ["January", "February", "March", "April", "June", "July", "August", "September", "October",
          "November", "December"]


def load_bank(path):
    entries, cur = [], None
    for line in open(path, encoding="utf-8"):
        line = line.rstrip("\n")
        m = re.match(r"^### (\w+) \| (\w+)$", line)
        if m:
            cur = {"id": m.group(1), "kind": m.group(2), "text": ""}
            entries.append(cur)
        elif cur is not None and line.strip():
            cur["text"] += (" " if cur["text"] else "") + line.strip()
    return entries


def scan(label, text, banned_strings, problems):
    if re.search(r"\d", text):
        problems.append(f"{label}: contains a digit")
    for mth in MONTHS:
        if re.search(rf"\b{mth}\b", text):
            problems.append(f"{label}: contains month name {mth}")
    words = re.findall(r"[A-Za-z]+", text)
    for w in words:
        if w.lower() in NUMBER_WORDS:
            problems.append(f"{label}: number word '{w}'")
        if w.lower() in FORBIDDEN:
            problems.append(f"{label}: forbidden word '{w}'")
    for tok in re.findall(r"\b[A-Z]{2,}\b", text):
        problems.append(f"{label}: acronym-like token '{tok}'")
    # capitalised word that does not start a sentence
    for m in re.finditer(r"(?<![.!?]\s)(?<!^)\b([A-Z][a-z]+)\b", text):
        start = m.start()
        if start == 0 or re.search(r"[.!?]\s+$", text[:start]):
            continue
        problems.append(f"{label}: capitalised word '{m.group(1)}' inside a sentence")
    low = text.lower()
    for b in banned_strings:
        if b and b.lower() in low:
            problems.append(f"{label}: contains protected string '{b}'")


def main(bank_path="SP02_paragraph_bank.md", data_path="SP02_data.yaml"):
    data = yaml.safe_load(open(data_path, encoding="utf-8"))
    banned = [data["proposal"]["acronym"], data["call"]["programme"], data["call"]["identifier"]]
    for p in data["partners"]:
        banned += [p["legal_name"], p["alias"], p["acronym"]]
    problems = []
    bank = load_bank(bank_path)
    if not 40 <= len(bank) <= 60:
        problems.append(f"bank has {len(bank)} entries, expected 40 to 60")
    ids = [e["id"] for e in bank]
    if len(ids) != len(set(ids)):
        problems.append("duplicate paragraph ids")
    for e in bank:
        scan(f"bank {e['id']}", e["text"], banned, problems)
    for p in data["partners"]:
        scan(f"profile {p['key']}", p["profile"], banned, problems)
    wp = data["workplan"]
    for w in wp["work_packages"]:
        scan(f"wp {w['id']} title", w["title"], banned, problems)
    for d in wp["deliverables"]:
        scan(f"deliverable {d['id']}", d["title"], banned, problems)
    for r in wp["risks"]:
        scan(f"risk {r['id']} title", r["title"], banned, problems)
        scan(f"risk {r['id']} mitigation", r["mitigation"], banned, problems)
    for m in wp["milestones"]:
        scan(f"milestone {m['id']}", m["title"], banned, problems)
    if problems:
        print("PROSE CHECK FAILED")
        for p in problems:
            print("  ", p)
        return 1
    print(f"prose check passed: {len(bank)} bank entries, {len(wp['risks'])} risks, "
          f"{len(wp['deliverables'])} deliverables scanned")
    return 0


if __name__ == "__main__":
    sys.exit(main())
