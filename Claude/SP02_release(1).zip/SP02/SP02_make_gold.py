#!/usr/bin/env python3
"""Writes SP02_gold.json, the gold set record for SP02 in the structure of the pipeline output schema.

Reads only SP02_data.yaml. Amounts are integers in euro cents, a field not stated in the document is null.
metadata.extraction_timestamp stays null because the gold record is not an extraction.
"""
import json
import os

import yaml

ROOT = os.path.dirname(os.path.abspath(__file__))


def main():
    d = yaml.safe_load(open(os.path.join(ROOT, "SP02_data.yaml"), encoding="utf-8"))
    gold = {
        "proposal": {
            "proposal_acronym": d["proposal"]["acronym"],
            "proposal_title": d["proposal"]["title"],
            "call_identifier": d["call"]["identifier"],
            "submission_date": d["dates"]["submission"],
        },
        "proposal_facts": {
            "requested_total_cents": d["totals"]["requested_cents"],
            "trl_start": d["readiness"]["trl_start"],
            "trl_target": d["readiness"]["trl_target"],
            "mcrl_start": d["readiness"]["mcrl_start"],
            "mcrl_target": d["readiness"]["mcrl_target"],
        },
        "partners": [{"partner_name": p["legal_name"], "requested_cents": p["requested_cents"]}
                     for p in d["partners"]],
        "metadata": {"extraction_timestamp": None, "source_file": "SP02.pdf"},
    }
    with open(os.path.join(ROOT, "SP02_gold.json"), "w", encoding="utf-8") as fh:
        json.dump(gold, fh, indent=4, ensure_ascii=False)
        fh.write("\n")
    print("SP02_gold.json written")


if __name__ == "__main__":
    main()
