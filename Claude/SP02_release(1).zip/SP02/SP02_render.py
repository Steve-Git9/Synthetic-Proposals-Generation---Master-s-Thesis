#!/usr/bin/env python3
"""Renders SP02.pdf from SP02_data.yaml, the template in SP02_template/ and SP02_paragraph_bank.md.

Reads only stored files. Never calls a language model. Filler is selected and ordered with the seed in the data file.
Usage: python3 SP02_render.py [--keep-log]
"""
import json
import os
import random
import re
import shutil
import subprocess
import sys

import jinja2
import yaml

ROOT = os.path.dirname(os.path.abspath(__file__))
BUILD = os.path.join(ROOT, "_work")
TEMPLATE_DIR = os.path.join(ROOT, "SP02_template")

sys.path.insert(0, ROOT)
from SP02_check_prose import load_bank  # noqa: E402


def tex_escape(s):
    if s is None:
        return ""
    s = str(s)
    table = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
             "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(table.get(ch, ch) for ch in s)


def tex_ref(s):
    """Escape and turn the literal 'Figure 5.1' into a live cross reference."""
    s = tex_escape(s)
    return s.replace("Figure 5.1", r"Figure~\ref{fig:req}")


def eur(cents):
    assert cents % 100 == 0, "amount is not a whole euro"
    return f"{cents // 100:,}"


CAPTION_IMAGE = {"C01": "generic_components", "C02": "generic_layers", "C03": "generic_workorg",
                 "C04": "generic_cycle", "C05": "generic_collab"}
BOX_TITLES = ["In brief", "Key point", "Good practice", "Note"]


class Filler:
    """Selects and orders bank paragraphs with a seeded generator. Holds no facts of its own."""

    def __init__(self, bank, seed):
        self.pools = {}
        for e in bank:
            self.pools.setdefault(e["kind"], []).append(e)
        self.rng = random.Random(seed)
        self.queues = {k: [] for k in self.pools}
        self.log = []
        self.pc = 0
        self.box_count = 0

    def next(self, kind):
        if not self.queues[kind]:
            q = list(self.pools[kind])
            self.rng.shuffle(q)
            self.queues[kind] = q
        e = self.queues[kind].pop()
        self.log.append(e["id"])
        return e

    def one(self, kind="body"):
        return tex_escape(self.next(kind)["text"])

    def split(self, total, weights):
        s = sum(weights)
        parts = [int(total * w / s) for w in weights]
        i = 0
        while sum(parts) < total:
            parts[i % len(parts)] += 1
            i += 1
        return parts

    def box(self):
        e = self.next("box")
        self.box_count += 1
        style = "sidebar" if self.box_count % 2 else "callout"
        title = BOX_TITLES[self.box_count % len(BOX_TITLES)]
        return (f"\\begin{{tcolorbox}}[{style}]\n{{\\bfseries {title}}}\\par\\smallskip\n"
                f"{tex_escape(e['text'])}\n\\end{{tcolorbox}}")

    def figure(self):
        e = self.next("caption")
        img = CAPTION_IMAGE[e["id"]]
        return (f"\\begin{{figure}}[H]\n\\centering\n\\includegraphics[width=\\columnwidth]{{{img}.png}}\n"
                f"\\caption{{{tex_escape(e['text'])}}}\n\\end{{figure}}")

    def long_footnote(self):
        e = self.next("longnote")
        return "\\footnote{" + tex_escape(e["text"]) + "}"

    def block(self, n, figs=True, furniture=True, split_at=None, split_pad=0):
        out = []
        for i in range(1, n + 1):
            e = self.next("body")
            self.pc += 1
            text = tex_escape(e["text"])
            if furniture:
                if split_at is not None and i == split_at:
                    text = (f"\\vspace*{{{int(split_pad)}pt}}\n" if split_pad else "") + text + self.long_footnote()
                elif self.pc % 3 == 0:
                    text += "\\footnote{" + tex_escape(self.next("note")["text"]) + "}"
            out.append(text)
            if furniture and self.pc % 5 == 2:
                out.append(self.box())
            if furniture and figs and self.pc % 9 == 4:
                out.append(self.figure())
        return "\n\n".join(out)


def render(data, bank):
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(TEMPLATE_DIR),
        variable_start_string="<<", variable_end_string=">>",
        block_start_string="<%", block_end_string="%>",
        comment_start_string="<#", comment_end_string="#>",
        trim_blocks=True, lstrip_blocks=True, keep_trailing_newline=True,
        undefined=jinja2.StrictUndefined, autoescape=False)
    env.filters["tex"] = tex_escape
    env.filters["tex_ref"] = tex_ref
    filler = Filler(bank, data["layout"]["filler_seed"])
    ctx = {"d": data, "F": filler, "eur": eur}
    os.makedirs(BUILD, exist_ok=True)
    for name in ("preamble.tex", "main.tex"):
        out = env.get_template(name + ".j2").render(**ctx)
        with open(os.path.join(BUILD, "SP02.tex" if name == "main.tex" else name), "w", encoding="utf-8") as fh:
            fh.write(out)
    with open(os.path.join(BUILD, "SP02_filler_log.json"), "w") as fh:
        json.dump({"seed": data["layout"]["filler_seed"], "paragraph_ids_in_order": filler.log}, fh, indent=1)
    return filler


def run_latex(data, passes=3):
    env = dict(os.environ)
    env["SOURCE_DATE_EPOCH"] = str(data["document"]["source_date_epoch"])
    env["FORCE_SOURCE_DATE"] = "1"
    env["TZ"] = "UTC"
    env["LC_ALL"] = "C.UTF-8"
    for i in range(passes):
        r = subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error", "SP02.tex"],
                           cwd=BUILD, env=env, capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stdout[-3500:])
            raise SystemExit(f"xelatex failed on pass {i + 1}")
    log = open(os.path.join(BUILD, "SP02.log"), encoding="utf-8", errors="replace").read()
    warn = [l for l in log.splitlines() if "undefined" in l.lower() and "reference" in l.lower()]
    if warn:
        print("WARNING undefined references:", warn[:3])
    shutil.copyfile(os.path.join(BUILD, "SP02.pdf"), os.path.join(ROOT, "SP02.pdf"))
    shutil.copyfile(os.path.join(BUILD, "SP02_filler_log.json"), os.path.join(ROOT, "SP02_filler_log.json"))


def main():
    data = yaml.safe_load(open(os.path.join(ROOT, "SP02_data.yaml"), encoding="utf-8"))
    bank = load_bank(os.path.join(ROOT, "SP02_paragraph_bank.md"))
    render(data, bank)
    run_latex(data)
    from pypdf import PdfReader
    n = len(PdfReader(os.path.join(ROOT, "SP02.pdf")).pages)
    print(f"SP02.pdf rendered, {n} pages")


if __name__ == "__main__":
    main()
