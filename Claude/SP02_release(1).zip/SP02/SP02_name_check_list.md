# SP02 name check list (HUMAN STEP, check 8)

Search each name in the Finnish Trade Register (YTJ, Business Information System) and in a web search. Any match with a real entity requires a replacement of the name in SP02_draw_values.py, a rebuild, and a new run of all checks.

| No | Legal name | Alias used in the document | Acronym | Category | YTJ result | Web search result | Real match (yes or no) | Action |
|---|---|---|---|---|---|---|---|---|
| 1 | Nordvalen Systems Oy | Nordvalen Systems | NVS | company | | | | |
| 2 | Kaltiora Analytics Oy | Kaltiora Analytics | KTA | company | | | | |
| 3 | Lumenthar Marine Oy | Lumenthar Marine | LMR | company | | | | |
| 4 | Havrenmaa University | University of Havrenmaa | HVU | university | | | | |
| 5 | Taimerra Research Institute | Taimerra Institute | TMI | research organisation | | | | |

Also check the following strings in a web search. They must not exist as a real call or project.

| No | String | Type | Web search result | Real match (yes or no) | Action |
|---|---|---|---|---|---|
| 1 | BF2026/93782 | call identifier (syntax BF[year]/[five digits]) | | | |
| 2 | TIDEMESH | proposal acronym | | | |
| 3 | Adaptive Sensor Networks for Resilient Coastal Infrastructure | proposal title | | | |

The funding programme name Business Finland is a real public funder and is expected to match. No funding instrument is named in the document.

Checked by: ______  Date: ______
