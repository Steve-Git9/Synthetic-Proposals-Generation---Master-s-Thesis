#!/usr/bin/env python3
"""Automatic verification of SP02 (section 11, checks 1 to 5, plus metadata, footer and reading order checks).

Writes SP02_check_report.md. Exits with status 1 if any check fails.
Human steps (visual legibility, blind second extraction, realism review, name check) are listed as OPEN, never passed.
"""
import os
import re
import subprocess
import sys

import yaml
from pypdf import PdfReader

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
import SP02_locate as L  # noqa: E402
from SP02_render import eur  # noqa: E402
import SP02_check_prose  # noqa: E402

PDF = os.path.join(ROOT, "SP02.pdf")
FIG = os.path.join(ROOT, "_work", "figures")
results = []


def check(cid, name, ok, detail=""):
    results.append((cid, name, "PASS" if ok else "FAIL", detail))
    return ok


def kf(c):
    return f"{c / 100000:.1f}"


def ocr(path, rotate=0):
    if rotate:
        from PIL import Image
        os.makedirs(os.path.join(ROOT, "_work", "ocr"), exist_ok=True)
        tmp = os.path.join(ROOT, "_work", "ocr", "rot_" + os.path.basename(path))
        Image.open(path).rotate(rotate, expand=True).save(tmp)
        path = tmp
    r = subprocess.run(["tesseract", path, "stdout", "--psm", "11"], capture_output=True, text=True)
    return re.sub(r"\s+", " ", r.stdout)


def main():
    data = yaml.safe_load(open(os.path.join(ROOT, "SP02_data.yaml"), encoding="utf-8"))
    lay = L.locate(PDF, os.path.join(ROOT, "SP02_data.yaml"))
    e = lay["elements"]
    pages = L.page_texts(PDF)
    norm = L.norm
    raw_all = "\n".join(pages)
    all_text = norm(raw_all)
    P = {p["key"]: p for p in data["partners"]}
    N = lay["page_count"]
    lo, hi = data["document"]["page_limits"]

    # ------------------------------------------------------------ 1 text layer check
    tl = []

    def on_page(label, needle, page, text_pages=None):
        ok = page is not None and needle in norm(pages[page - 1])
        tl.append((label, needle, page, ok))
        return ok

    on_page("proposal acronym", data["proposal"]["acronym"], e["cover"] or 1)
    title_one_string = data["proposal"]["title"]
    on_page("proposal title (joined)", title_one_string, 1)
    on_page("call identifier", data["call"]["identifier"], 1)
    on_page("funding programme", data["call"]["programme"], 1)
    on_page("stated total (section 5.3)", "EUR " + eur(data["totals"]["requested_cents"]), e["total_statement"])
    on_page("MCRL start", f"MCRL start: {data['readiness']['mcrl_start']}", e["mcrl_sidebar"])
    on_page("MCRL target", f"MCRL target: {data['readiness']['mcrl_target']}", e["mcrl_target"])
    for k, p in P.items():
        on_page(f"partner {k} name as written", f"{p['legal_name']} ({p['acronym']})", e["partners_2_1"][k])
    for k in "AB":
        on_page(f"partner {k} amount in Table 5.1", P[k]["table51_display"], e["table_5_1"])
    on_page("partner C zero funding text", "no funding requested", e["table_5_1"])
    on_page("unit in Table 5.1 header", "EUR thousand", e["table_5_1"])
    on_page("Table 5.1 heading Organisation", "Organisation", e["table_5_1"])
    on_page("Table 5.2 heading Beneficiary", "Beneficiary", e["table_5_2"])
    on_page("executive summary points to section 5.3", "detailed in section 5.3", e["exec_refers_to_5_3"])
    bad = [t for t in tl if not t[3]]
    check("1", "Text layer check: every text or table target is on its stated page", not bad,
          f"{len(tl) - len(bad)} of {len(tl)} present" + ("; missing: " + str(bad) if bad else ""))
    # two line title on the cover really has a forced break
    raw_p1 = subprocess.run(["pdftotext", "-f", "1", "-l", "1", "-layout", PDF, "-"], capture_output=True,
                            text=True).stdout
    lines = [l.strip() for l in raw_p1.splitlines()]
    two_lines = (data["proposal"]["title_line1"] in lines and data["proposal"]["title_line2"] in lines)
    check("1b", "Cover title is set on two lines (forced break)", two_lines)

    # answer key against the PDF: surface strings on the stated pages, image only values absent from the text layer
    import json as _json
    keyp = os.path.join(ROOT, "SP02_answer_key.json")
    if os.path.exists(keyp):
        key = _json.load(open(keyp, encoding="utf-8"))
        kbad = []
        for f in key["fields"]:
            s_ = f["surface_string"]
            if s_ is None:
                if f["value"] is not None:
                    kbad.append((f["field"], "null surface with a value"))
            else:
                flat = norm(s_.replace("\n", " "))
                present = flat in norm(pages[f["page"] - 1])
                if f["location_type"] in ("text", "table") and not present:
                    kbad.append((f["field"], "surface string not on page", f["page"]))
                if f["location_type"] == "figure" and re.search(r"(?<![\d.,])" + re.escape(flat) + r"(?![\d])", all_text):
                    kbad.append((f["field"], "image only value found in text layer"))
            for d in f["distractors"]:
                if d["page"] is None:
                    continue
                img = "image" in d["reason"]
                present = norm(d["surface_string"]) in norm(pages[d["page"] - 1])
                if (not img and not present) or (img and present):
                    kbad.append((f["field"], "distractor", d["surface_string"], d["page"]))
        check("1c", "Answer key: surface strings and distractors match the PDF text layer", not kbad,
              str(kbad) if kbad else f"{len(key['fields'])} fields verified")
    else:
        check("1c", "Answer key present", False, "SP02_answer_key.json missing")

    # gold set record against the answer key and the template structure
    goldp = os.path.join(ROOT, "SP02_gold.json")
    if os.path.exists(goldp) and os.path.exists(os.path.join(ROOT, "SP02_answer_key.json")):
        g = _json.load(open(goldp, encoding="utf-8"))
        kv = {f["field"]: f["value"] for f in key["fields"]}
        gbad = []
        if list(g) != ["proposal", "proposal_facts", "partners", "metadata"]:
            gbad.append("top level keys")
        pairs = [("proposal", "proposal_acronym", "proposal_acronym"), ("proposal", "proposal_title", "proposal_title"),
                 ("proposal", "call_identifier", "call_identifier"), ("proposal", "submission_date", "submission_date"),
                 ("proposal_facts", "requested_total_cents", "stated_total_requested_amount_cents"),
                 ("proposal_facts", "trl_start", "trl_start"), ("proposal_facts", "trl_target", "trl_target"),
                 ("proposal_facts", "mcrl_start", "mcrl_start"), ("proposal_facts", "mcrl_target", "mcrl_target")]
        for grp, gk, kk in pairs:
            if g[grp][gk] != kv[kk]:
                gbad.append(gk)
        for gp, (k, p) in zip(g["partners"], P.items()):
            if gp != {"partner_name": kv[f"partner_{k}_name_as_written"],
                      "requested_cents": kv[f"partner_{k}_requested_amount_cents"]}:
                gbad.append(f"partner {k}")
        if len(g["partners"]) != len(P) or sum(x["requested_cents"] for x in g["partners"]) != g["proposal_facts"]["requested_total_cents"]:
            gbad.append("partner count or sum")
        check("1d", "Gold set record equals the answer key and sums to the stated total", not gbad,
              str(gbad) if gbad else "9 proposal values and 5 partners compared")
    else:
        check("1d", "Gold set record present", False, "SP02_gold.json missing")

    # ------------------------------------------------------------ 2 image value check
    absent = []
    img_only = {"TRL start": [f"TRL {data['readiness']['trl_start']}", f"TRL{data['readiness']['trl_start']}"],
                "TRL target": [f"TRL {data['readiness']['trl_target']}", f"TRL{data['readiness']['trl_target']}"]}
    for k in "DE":
        c = P[k]["requested_cents"]
        img_only[f"partner {k} amount"] = [kf(c), eur(c), str(c // 100), str(c)]
    for k, v in data["pie_percent"].items():
        img_only[f"pie share {k}"] = [f"{v:.1f}%"]
    for label, needles in img_only.items():
        for n in needles:
            if re.search(r"(?<![\d.,])" + re.escape(n) + r"(?![\d])", all_text):
                absent.append((label, n))
    no_trl = "TRL" not in all_text
    check("2a", "Image only values do not appear in the PDF text layer", not absent and no_trl,
          "found in text: " + str(absent) if absent else ("TRL occurs in text layer" if not no_trl else
                                                          "no TRL, no D or E amount, no pie percentage in text"))
    reader = PdfReader(PDF)
    img_pages = {i + 1 for i, pg in enumerate(reader.pages) if len(pg.images) > 0}
    need = {1: "logo strip", e["figure_1_1"]: "Figure 1.1", e["figure_5_1"]: "Figure 5.1", e["figure_5_2"]: "Figure 5.2",
            e["gantt"]: "Gantt chart"}
    miss = [v for pgno, v in need.items() if pgno not in img_pages]
    check("2b", "Pages with graphics hold embedded images", not miss, "missing: " + str(miss) if miss else
          f"image pages: {sorted(img_pages)[:12]}...")
    # OCR of source figures: automatic legibility proxy only
    o_map = ocr(os.path.join(FIG, "fig_roadmap.png"))
    o_bar = ocr(os.path.join(FIG, "fig_requested_funding.png"))
    o_bar_rot = ocr(os.path.join(FIG, "fig_requested_funding.png"), rotate=-90)
    o_pie = ocr(os.path.join(FIG, "fig_funding_share.png"))
    want = {"roadmap TRL start": (o_map, f"TRL {data['readiness']['trl_start']}"),
            "roadmap TRL target": (o_map, f"TRL {data['readiness']['trl_target']}"),
            "bar axis title": (o_bar + " " + o_bar_rot, "EUR thousand")}
    for k in "ABDE":
        want[f"bar label {k}"] = (o_bar, P[k]["fig51_label"])
    ocr_fail = [k for k, (t, n) in want.items() if n.replace(" ", "") not in t.replace(" ", "")]
    check("2c", "OCR reads the image only values (automatic legibility proxy)", not ocr_fail,
          "unread: " + str(ocr_fail) if ocr_fail else "all labels read by OCR; human visual check still OPEN")
    check("2d", "Partner C is absent from Figures 5.1 and 5.2", "LMR" not in o_bar and "LMR" not in o_pie and
          "C" not in data["pie_percent"], "")

    # ------------------------------------------------------------ 3 page count and placement
    check("3a", f"Page count between {lo} and {hi}", lo <= N <= hi, f"{N} pages")
    rng = {"cover": (1, 1), "toc": (2, 2), "exec_summary_start": (3, 3), "exec_callout": (3, 4),
           "exec_refers_to_5_3": (3, 4), "section1": (5, 5), "figure_1_1": (9, 11), "section2": (13, 13),
           "section_2_1": (13, 20), "section3": (21, 21), "section4": (29, 29), "mcrl_sidebar": (29, 31),
           "mcrl_target": (29, 31), "section5": (33, 33), "table_5_1": (33, 36), "figure_5_1": (33, 36),
           "table_5_2": (33, 36), "figure_5_2": (33, 36), "section_5_3": (33, 36), "total_statement": (33, 36),
           "annex_start": (37, 45), "gantt": (37, 45), "work_package_tables": (37, 45),
           "deliverables_annex": (37, 45), "risk_register": (37, 45), "cover_title": (1, 1),
           "call_identifier": (1, 1), "prepared_date": (1, 1)}
    off = {k: (e[k], r) for k, r in rng.items() if e[k] is None or not (r[0] <= e[k] <= r[1])}
    for k, pg in e["partners_2_1"].items():
        if pg is None or not (13 <= pg <= 20):
            off[f"partner {k}"] = (pg, (13, 20))
    check("3b", "Page map: every element falls within its range", not off, str(off) if off else
          "sections start on pages 5, 13, 21, 29, 33; annexes from 37")
    sec_end = {"section1": (e["section1"], e["section2"] - 1), "section2": (e["section2"], e["section3"] - 1),
               "section3": (e["section3"], e["section4"] - 1), "section4": (e["section4"], e["section5"] - 1),
               "section5": (e["section5"], e["annex_start"] - 1)}
    ranges = {"section1": (5, 12), "section2": (13, 20), "section3": (21, 28), "section4": (29, 32),
              "section5": (33, 36)}
    wrong = {k: v for k, v in sec_end.items() if not (ranges[k][0] <= v[0] and v[1] <= ranges[k][1])}
    check("3c", "Every section ends within its page range", not wrong, str(wrong) if wrong else str(sec_end))
    sp = lay["split_footnote"]
    check("3d", "A footnote continues across the column break on a page in section 3",
          sp is not None and 21 <= sp <= 28, f"page {sp}")
    # MCRL box between the columns and interleaved with body lines
    page_w = h = None
    boxes = L.word_boxes(PDF)
    pg_idx = e["mcrl_sidebar"]
    w, h, words = boxes[pg_idx - 1]
    mid = w / 2
    hits = [x for x in words if x[0] in ("MCRL",)]
    inter = False
    if hits:
        a = hits[0]
        band = [x for x in words if x[2] < a[4] and x[4] > a[2]]
        left = [x for x in band if x[3] < mid - 40]
        right = [x for x in band if x[1] > mid + 40]
        inter = bool(left) and bool(right) and abs((a[1] + a[3]) / 2 - mid) < 60
    check("4a", "MCRL sidebar sits between the columns, on the same lines as body text", inter,
          f"page {pg_idx}")

    # ------------------------------------------------------------ 4 consistency
    t = data["totals"]
    sum_amounts = sum(p["requested_cents"] for p in data["partners"])
    stated = re.search(r"The total requested funding of the consortium is EUR ([\d,]+)\.", all_text)
    stated_c = int(stated.group(1).replace(",", "")) * 100 if stated else None
    check("5a", "Partner amounts sum to the total stated in section 5.3",
          stated_c == sum_amounts == t["requested_cents"], f"stated {stated_c}, sum {sum_amounts}")
    check("5b", "Figure 5.1 labels for A and B equal the Table 5.1 values",
          all(P[k]["fig51_label"] == P[k]["table51_display"] == kf(P[k]["requested_cents"]) for k in "AB"),
          "values compared as strings")
    check("5c", "Figure 5.1 labels for D and E equal the requested amounts",
          all(P[k]["fig51_label"] == kf(P[k]["requested_cents"]) for k in "DE"), "")
    rate_ok = all(0.40 <= P[k]["funding_rate"] <= 0.60 for k in "AB") and \
        all(0.70 <= P[k]["funding_rate"] <= 0.80 for k in "DE") and P["C"]["requested_cents"] == 0
    check("5d", "Funding rates, zero partner and total range follow section 4 of the task",
          rate_ok and 80000000 <= t["requested_cents"] <= 200000000, "")
    check("5e", "Volume > eligible costs > requested total",
          t["volume_cents"] > t["eligible_cents"] > t["requested_cents"] and
          t["eligible_cents"] == sum(p["eligible_cents"] for p in data["partners"]) and
          t["volume_cents"] == t["eligible_cents"] + sum(p["in_kind_cents"] for p in data["partners"]), "")
    check("5f", "Submission date is null and appears nowhere",
          data["dates"]["submission"] is None and "submission" not in all_text.lower() and
          len(re.findall(r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\b",
                         all_text)) == 1, "only the Document prepared date shows a month name")

    # ------------------------------------------------------------ 5 filler check
    import io
    import contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = SP02_check_prose.main(os.path.join(ROOT, "SP02_paragraph_bank.md"), os.path.join(ROOT, "SP02_data.yaml"))
    check("6a", "Filler check: bank and free text hold no number, date, name or acronym", rc == 0,
          buf.getvalue().strip().splitlines()[0])
    # every number in the PDF text layer must come from the data file
    corpus = yaml.safe_dump(data)
    for p in data["partners"]:
        corpus += " " + " ".join([eur(p["eligible_cents"]), eur(p["requested_cents"]), eur(p["in_kind_cents"]),
                                  kf(p["requested_cents"])])
    corpus += " " + " ".join(eur(v) for k, v in t.items() if k.endswith("_cents"))
    corpus += " " + eur(data["earlier_project"]["amount_cents"])
    toks = set(re.findall(r"\d[\d.,]*\d|\d", all_text))
    foreign = sorted(x for x in toks if len(x) >= 3 and not re.fullmatch(r"\d{1,2}\.\d{1,2}", x) and x not in corpus)
    check("6b", "Every number of three or more characters in the PDF text layer comes from the data file",
          not foreign, str(foreign) if foreign else f"{len(toks)} distinct numeric tokens checked")

    # ------------------------------------------------------------ metadata and footer
    md = reader.metadata
    meta_ok = all("SP02" in (md.get(k) or "") and "synthetic" in (md.get(k) or "").lower()
                  for k in ("/Title", "/Author", "/Subject"))
    check("7a", "PDF metadata title, author and subject state the ID and the word synthetic", meta_ok,
          f"{md.get('/Title')} | {md.get('/Author')} | {md.get('/Subject')}")
    footer = data["document"]["footer_text"]
    nofoot = [i + 1 for i, tx in enumerate(pages) if footer not in norm(tx)]
    check("7b", "Every page carries the footer text", not nofoot, str(nofoot) if nofoot else f"{N} of {N} pages")
    check("7c", "Footer is the same on every page and holds no target value",
          not any(v in footer for v in (data["proposal"]["acronym"], data["call"]["identifier"])), "")

    # ------------------------------------------------------------ report
    open_items = [
        ("2e", "Visual confirmation that Figure 1.1 and Figure 5.1 are legible (HUMAN STEP)"),
        ("8", "Blind second extraction with an empty form, record the initial agreement rate (HUMAN STEP)"),
        ("9", "Realism review by a person familiar with real proposals (HUMAN STEP)"),
        ("10", "Name check of all organisation names and the call identifier against YTJ and a web search (HUMAN STEP)"),
        ("11", "Freeze, tag version 1.0 and write final checksums, only after all checks pass (OPEN)"),
    ]
    lines = ["# SP02 check report", "", f"Pages: {N}. Split footnote page: {sp}. Layout in SP02_layout.json.", "",
             "| Check | Description | Result | Detail |", "|---|---|---|---|"]
    for cid, name, st, det in results:
        lines.append(f"| {cid} | {name} | {st} | {str(det).replace('|', '/')} |")
    lines += ["", "## Human steps still open", ""]
    for cid, name in open_items:
        lines.append(f"* {name}")
    open(os.path.join(ROOT, "SP02_check_report.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
    fails = [r for r in results if r[2] == "FAIL"]
    for cid, name, st, det in results:
        print(f"[{st}] {cid} {name} :: {det}")
    print(f"\n{len(results) - len(fails)} passed, {len(fails)} failed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
