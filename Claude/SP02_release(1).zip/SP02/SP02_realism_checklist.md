# SP02 realism review checklist (HUMAN STEP, check 7)

Reviewer: a person familiar with real innovation project proposals. The document needs to look plausible to a reader who skims it. Scientific validity, real literature and real call rules are not required and must not be judged.

Answer yes, no or unsure for each item and add a short comment.

1. The cover page looks like the front page of a real proposal (programme, call identifier, acronym, title, partners).
2. The two column layout with sidebars, callout boxes, captioned figures and footnotes looks like a real proposal and not like a template demonstration.
3. The structure (executive summary, challenge and solution, consortium, work plan, market, budget, annexes) is plausible for a national innovation application.
4. The consortium of five partners (three companies, a university, a research organisation) is plausible, and a partner without requested funding is plausible.
5. The budget section (requested funding table and chart, eligible costs table, share chart, total in text) looks like a real budget section.
6. The use of EUR thousand in table headers and axis titles with bare numbers in cells looks natural.
7. The annexes (Gantt chart, work package tables, deliverables, risk register) look plausible and complete.
8. The filler text is neutral enough that a skimming reader does not notice that it is generic. Note any passage that stands out.
9. Nothing in the document looks like a real funding rule, a real instrument name or a real organisation.
10. Anything that would make a real reader suspect that the document is synthetic, other than the footer.

Overall judgement (plausible, needs changes, not plausible): ______
Changes requested: ______
