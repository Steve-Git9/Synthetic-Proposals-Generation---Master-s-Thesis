# SP02 generation log

One entry per language model contribution to SP02. The work was done in one interactive session with a language model in a chat interface; the interface does not expose separate call times, so every entry carries the time at which this log was written (2026-10-25 18:17 UTC). The full prompt of each entry is the task text in SP02_task_prompt.md plus the parts named in the entry. Full outputs are the named files with their SHA-256 checksums. This log is itself listed in SP02_checksums.txt.

No language model is used by the build. The build script reads only stored files, so a rebuild reproduces an identical PDF.

## Entry 1: Clarifying questions on the task

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Resolve ambiguities of the task before building (set size, dash rule, rows for partners D and E in Table 5.1, build scope).
* Full prompt: SP02_task_prompt.md (the full task, SHA-256 a04b0e26cdcafa3c4e39cf8d39d2677de5d624ab48ba29046f667a379d197bb4) together with the project instructions and the knowledge file of the thesis project.
* Full output: Four questions put to the researcher: (1) set size, five documents as in the task or nine as in the knowledge file; answer: five documents. (2) dash rule against machine files; answer: ignore the no dash rule. (3) rows for partners D and E in Table 5.1; answer: rows with pointer text. (4) build scope; answer: full build.
* Where the output is used: Decisions recorded in SP02_data.yaml (table51_display) and in the scope of the build.
* Model and interface details: [to be filled in by the researcher]

## Entry 2: Fictional identity and structured texts

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Invent fictional organisation names, acronyms, addresses, the proposal acronym and title, partner profiles, work package, deliverable, milestone and risk texts, difficulty descriptions and failure modes. Numbers are drawn by the script from the seed, not by the model. Four texts (initial prototype, initial release, alternative supplier, initial prototype operational) were reworded after the prose check found the number words first and second.
* Full prompt: SP02_task_prompt.md sections 2 to 4 and 8 (SHA-256 a04b0e26cdcafa3c4e39cf8d39d2677de5d624ab48ba29046f667a379d197bb4).
* Full output: File SP02_draw_values.py, SHA-256 d80480edf8a43c7801ed56ff7455ef9f453deb7f11d078b6cf8fdb1183a4e00a.
* Where the output is used: SP02_data.yaml and, through it, the document, answer key and manifest.
* Model and interface details: [to be filled in by the researcher]

## Entry 3: Paragraph bank

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Write neutral filler prose about innovation, consortium work, dissemination and risk, in a single pass, with no numbers, dates, organisation names or acronyms.
* Full prompt: SP02_task_prompt.md section 6 (SHA-256 a04b0e26cdcafa3c4e39cf8d39d2677de5d624ab48ba29046f667a379d197bb4). Two bank paragraphs (P10 and N05) were corrected after the prose check found the number words once and one; one longer footnote text (L01) was added so that the split footnote can be detected.
* Full output: File SP02_paragraph_bank.md, SHA-256 ba4372d1bd6a21016378a28a1976fd342001b551760a4a79a0a91bb3fa5b836c.
* Where the output is used: Body text, boxes, captions and footnotes of the PDF through SP02_render.py.
* Model and interface details: [to be filled in by the researcher]

## Entry 4: Template and build code

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Write the LaTeX template, the chart script, the render script, the prose check, the page locator, the output generator and the checks.
* Full prompt: SP02_task_prompt.md sections 5, 7, 8, 9, 10 and 11 (SHA-256 a04b0e26cdcafa3c4e39cf8d39d2677de5d624ab48ba29046f667a379d197bb4).
* Full output: Files: SP02_template/preamble.tex.j2 (6854c1a1874bbba25883125f26e3bb8694eefcd9ac52f2ce9f0c3f178f697722), SP02_template/main.tex.j2 (2c9a9fcbb1dfcdfb3465776cfd569b22f99fa734176443ef7679af4b92003182), SP02_charts.py (d310a894cf0a5ac5ba1709f330fcd9c5521ab9c4547c88da4e2df2616b488d3a), SP02_render.py (2375b5cb41cbd81784d29f1e12c3649c2607e4ce9c6a42bc42d8e94e681167d5), SP02_check_prose.py (dd6c2c2c4980c49d92f92b57b149d08bc669362b84e6d80a1057cbaba5fad2e1), SP02_locate.py (fc2cb7ecb1b387b4a65078c54bb0656b3d0d7076246450ab523c43b3d8cd7c27), SP02_make_outputs.py (51407235c5130adc7e98d4e866689bdb440beb57623a54a8cfa3ba8ee02d5e73), SP02_make_gold.py (0d51abc46c128f0ac6599eec078f1fa60f12f9eb9a0b204461eab10cfd67476d), SP02_checks.py (da75e2fb8f542c03e958a3e4402234ee21fb2ae607bb5ace562d254df7fdfcbb), SP02_checksums.py (804fcf455a5513e21517aa16995b3ddadea2185d8c03d29680e0a8b0edac0eca), build (470514537cad3dc3e375e74530563957b2539722407a26bb509f580e22db1a15).
* Where the output is used: The build. None of these files calls a language model.
* Model and interface details: [to be filled in by the researcher]

## Entry 5: Layout tuning

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Tune the filler counts per section, the position of the split footnote and the vertical pad so that the page map of the task holds. The values were found by building and measuring; they hold no facts.
* Full prompt: Iterative build and locate runs during the session; the page map of SP02_task_prompt.md section 7.
* Full output: The values in SP02_data.yaml under layout.filler_counts (file SHA-256 e95def3c9539aebbc7fbb35d9118905cb1d491354dd1902af13fc61c6d310215).
* Where the output is used: Page positions of all elements, recorded in SP02_layout.json.
* Model and interface details: [to be filled in by the researcher]

## Entry 6: Documentation and human step material

* Date and time: 2026-10-25 18:17 UTC
* Purpose of the call: Write the datasheet, changelog, environment note, blind extraction form, realism checklist and name check list.
* Full prompt: SP02_task_prompt.md sections 10 and 11 (SHA-256 a04b0e26cdcafa3c4e39cf8d39d2677de5d624ab48ba29046f667a379d197bb4).
* Full output: Files SP02_write_docs.py (afd3d21a229042da4e1ac0ad4a7309d879d89fb1c408e6ea0f8b4ab604a3d94c), SP02_datasheet.md (da28a6a0778a8fb9365d3bbed5534e9e45f415d40fcb92fe5ede67cdebb8e61d), CHANGELOG.md (45d5d22d62c08b2a279f83fd392dbf7f078bb3c1c0f5a736b07e67b3ddd42566), SP02_environment_note.md (426f83f0a3efe420ac7a69756d66cdb7a902d685693571ce0240761813fcd2a3), SP02_blind_extraction_form.md (79e71e4f71a34e46f7f3bd5530858cd6d8b9669e8cedf75296a2d50e65d73321), SP02_realism_checklist.md (406f58086aba59039c325662143230a780911b5e2641c07d6bd4cf800f984c32), SP02_name_check_list.md (5aab4d1a592b52420acc76e64fa2c9064930e35fb005691b9d977e31f24f1812).
* Where the output is used: Release documentation; none of it enters the PDF.
* Model and interface details: [to be filled in by the researcher]

