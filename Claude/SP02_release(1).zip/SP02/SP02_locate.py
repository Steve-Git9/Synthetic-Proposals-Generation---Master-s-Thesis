#!/usr/bin/env python3
"""Finds the page of every element named in the page map and in the answer key. Writes SP02_layout.json.

Works only on the text layer of SP02.pdf (pdftotext). Elements that exist only inside images are located by
their caption text, which is a text element placed with the image.
"""
import json
import os
import re
import subprocess
import sys

import yaml

ROOT = os.path.dirname(os.path.abspath(__file__))


def page_texts(pdf):
    out = subprocess.run(["pdftotext", "-enc", "UTF-8", pdf, "-"], capture_output=True, text=True, check=True).stdout
    pages = out.split("\f")
    if pages and not pages[-1].strip():
        pages = pages[:-1]
    return pages


def norm(s):
    return re.sub(r"\s+", " ", s.replace(" ", " ")).strip()


def first_page(pages, needle, start=3, last=False):
    hits = [i + 1 for i, t in enumerate(pages) if i + 1 >= start and needle in norm(t)]
    if not hits:
        return None
    return hits[-1] if last else hits[0]


def locate(pdf=None, data_path=None):
    pdf = pdf or os.path.join(ROOT, "SP02.pdf")
    data = yaml.safe_load(open(data_path or os.path.join(ROOT, "SP02_data.yaml"), encoding="utf-8"))
    pages = page_texts(pdf)
    n = len(pages)
    P = {p["key"]: p for p in data["partners"]}
    lay = {"page_count": n, "elements": {}}
    el = lay["elements"]
    el["cover"] = 1 if "PROJECT PROPOSAL" in norm(pages[0]) else None
    el["toc"] = 2 if "Contents" in norm(pages[1]) else None
    el["exec_summary_start"] = first_page(pages, "Executive summary", start=3)
    el["exec_callout"] = first_page(pages, "Total project volume including in kind contributions", start=3)
    el["exec_refers_to_5_3"] = first_page(pages, "detailed in section 5.3", start=3)
    el["section1"] = first_page(pages, "1 Challenge and solution")
    el["section2"] = first_page(pages, "2 Consortium")
    el["section3"] = first_page(pages, "3 Work plan")
    el["section4"] = first_page(pages, "4 Market and commercialisation")
    el["section5"] = first_page(pages, "5 Budget and funding")
    el["annex_start"] = first_page(pages, "A Gantt chart")
    el["figure_1_1"] = first_page(pages, "Figure 1.1: Technology roadmap")
    el["section_2_1"] = first_page(pages, "2.1 Partners")
    el["partners_2_1"] = {k: first_page(pages, f"{p['legal_name']} ({p['acronym']})") for k, p in P.items()}
    el["earlier_funding_sentence"] = first_page(pages, "in funding for " + data["earlier_project"]["description"])
    el["mcrl_sidebar"] = first_page(pages, f"MCRL start: {data['readiness']['mcrl_start']}")
    el["mcrl_target"] = first_page(pages, f"MCRL target: {data['readiness']['mcrl_target']}")
    el["table_5_1"] = first_page(pages, "Table 5.1: Requested funding per partner")
    el["figure_5_1"] = first_page(pages, "Figure 5.1: Requested funding per funded partner")
    el["table_5_2"] = first_page(pages, "Table 5.2: Eligible costs and in kind contributions per partner")
    el["figure_5_2"] = first_page(pages, "Figure 5.2: Share of each funded partner")
    el["section_5_3"] = first_page(pages, "5.3 Requested funding")
    el["total_statement"] = first_page(pages, "The total requested funding of the consortium is EUR")
    el["gantt"] = first_page(pages, "Figure A.1: Work packages and milestones")
    el["work_package_tables"] = first_page(pages, "Work package descriptions", start=el["annex_start"] or 3)
    el["deliverables_annex"] = first_page(pages, "Deliverables", start=el["annex_start"] or 3, last=True)
    el["risk_register"] = first_page(pages, "Risk register", start=el["annex_start"] or 3, last=True)
    el["cover_title"] = first_page(pages, norm(data["proposal"]["title_line1"]), start=1)
    el["call_identifier"] = first_page(pages, data["call"]["identifier"], start=1)
    el["prepared_date"] = first_page(pages, "Document prepared: " + data["dates"]["prepared_display"], start=1)
    lay["page_text_chars"] = [len(norm(t)) for t in pages]
    # footnote split: a long footnote whose text starts in the left column and ends in the right column
    lay["split_footnote"] = detect_split_footnote(pdf, data)
    return lay


def word_boxes(pdf):
    """Word boxes per page from poppler: list of pages, each a list of (text, xmin, ymin, xmax, ymax)."""
    html = subprocess.run(["pdftotext", "-bbox", "-enc", "UTF-8", pdf, "-"], capture_output=True, text=True,
                          check=True).stdout
    pages = []
    for chunk in html.split("<page ")[1:]:
        m = re.match(r'width="([\d.]+)" height="([\d.]+)"', chunk)
        w, h = float(m.group(1)), float(m.group(2))
        words = [(t, float(a), float(b), float(c), float(d)) for a, b, c, d, t in
                 re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', chunk)]
        pages.append((w, h, words))
    return pages


def detect_split_footnote(pdf, data=None):
    """Finds the page where the long note starts at the foot of one column and ends at the foot of the other."""
    res = None
    for i, (w, h, words) in enumerate(word_boxes(pdf)):
        mid, low = w / 2, h * 0.55
        starts = [x for x in words if x[0] == "combines" and x[2] > low]
        ends = [x for x in words if x[0] == "sensible" and x[2] > low]
        if any(a[1] < mid < b[1] for a in starts for b in ends):
            res = i + 1
    return res


if __name__ == "__main__":
    lay = locate()
    json.dump(lay, open(os.path.join(ROOT, "SP02_layout.json"), "w"), indent=1)
    e = lay["elements"]
    print("pages:", lay["page_count"], "split footnote page:", lay["split_footnote"])
    for k, v in e.items():
        print(f"  {k}: {v}")
