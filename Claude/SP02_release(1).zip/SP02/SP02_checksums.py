#!/usr/bin/env python3
"""Writes SP02_checksums.txt with SHA-256 checksums of all outputs (everything except _work/ and the file itself)."""
import hashlib
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = {"_work", "__pycache__"}
SKIP_FILES = {"SP02_checksums.txt"}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    rows = []
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for f in sorted(files):
            rel = os.path.relpath(os.path.join(base, f), ROOT)
            if rel in SKIP_FILES or f.endswith(".pyc"):
                continue
            rows.append((rel, sha256(os.path.join(ROOT, rel))))
    rows.sort()
    with open(os.path.join(ROOT, "SP02_checksums.txt"), "w") as fh:
        for rel, h in rows:
            fh.write(f"{h}  {rel}\n")
    print(f"SP02_checksums.txt written, {len(rows)} files")


if __name__ == "__main__":
    main()
