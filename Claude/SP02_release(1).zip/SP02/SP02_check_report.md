# SP02 check report

Pages: 41. Split footnote page: 24. Layout in SP02_layout.json.

| Check | Description | Result | Detail |
|---|---|---|---|
| 1 | Text layer check: every text or table target is on its stated page | PASS | 19 of 19 present |
| 1b | Cover title is set on two lines (forced break) | PASS |  |
| 1c | Answer key: surface strings and distractors match the PDF text layer | PASS | 20 fields verified |
| 1d | Gold set record equals the answer key and sums to the stated total | PASS | 9 proposal values and 5 partners compared |
| 2a | Image only values do not appear in the PDF text layer | PASS | no TRL, no D or E amount, no pie percentage in text |
| 2b | Pages with graphics hold embedded images | PASS | image pages: [1, 10, 11, 15, 16, 18, 19, 21, 22, 24, 25, 26]... |
| 2c | OCR reads the image only values (automatic legibility proxy) | PASS | all labels read by OCR; human visual check still OPEN |
| 2d | Partner C is absent from Figures 5.1 and 5.2 | PASS |  |
| 3a | Page count between 40 and 45 | PASS | 41 pages |
| 3b | Page map: every element falls within its range | PASS | sections start on pages 5, 13, 21, 29, 33; annexes from 37 |
| 3c | Every section ends within its page range | PASS | {'section1': (5, 12), 'section2': (13, 20), 'section3': (21, 28), 'section4': (29, 32), 'section5': (33, 36)} |
| 3d | A footnote continues across the column break on a page in section 3 | PASS | page 24 |
| 4a | MCRL sidebar sits between the columns, on the same lines as body text | PASS | page 30 |
| 5a | Partner amounts sum to the total stated in section 5.3 | PASS | stated 99110000, sum 99110000 |
| 5b | Figure 5.1 labels for A and B equal the Table 5.1 values | PASS | values compared as strings |
| 5c | Figure 5.1 labels for D and E equal the requested amounts | PASS |  |
| 5d | Funding rates, zero partner and total range follow section 4 of the task | PASS |  |
| 5e | Volume > eligible costs > requested total | PASS |  |
| 5f | Submission date is null and appears nowhere | PASS | only the Document prepared date shows a month name |
| 6a | Filler check: bank and free text hold no number, date, name or acronym | PASS | prose check passed: 57 bank entries, 10 risks, 18 deliverables scanned |
| 6b | Every number of three or more characters in the PDF text layer comes from the data file | PASS | 91 distinct numeric tokens checked |
| 7a | PDF metadata title, author and subject state the ID and the word synthetic | PASS | SP02 synthetic proposal document / SP02 synthetic document for research purposes / SP02 version 1.0, synthetic test document, never submitted to any call |
| 7b | Every page carries the footer text | PASS | 41 of 41 pages |
| 7c | Footer is the same on every page and holds no target value | PASS |  |

## Human steps still open

* Visual confirmation that Figure 1.1 and Figure 5.1 are legible (HUMAN STEP)
* Blind second extraction with an empty form, record the initial agreement rate (HUMAN STEP)
* Realism review by a person familiar with real proposals (HUMAN STEP)
* Name check of all organisation names and the call identifier against YTJ and a web search (HUMAN STEP)
* Freeze, tag version 1.0 and write final checksums, only after all checks pass (OPEN)
