# SP02 blind extraction form (HUMAN STEP, check 6)

Document: SP02.pdf, version 1.0 (synthetic, never submitted to any call).
Extractor code (anonymised): ______  Date: ______  Time spent: ______

Rules for the second person
* Use only the PDF. Do not open SP02_data.yaml, SP02_answer_key.json, SP02_manifest.csv or any other file of the set.
* Do not search the web for the names in the document.
* Write amounts in euro cents as integers, apply any scale stated in headers or axis titles, and write dates in ISO 8601.
* Write null for a field that the document does not state. Write the page number where you found each value, and whether it sat in text, a table or a figure.
* Partners: list every partner you find. Use the name as written in the partner descriptions of section 2.1.

## Part 1. Single fields

| No | Field | Value | Page | Location (text, table, figure) | Notes |
|---|---|---|---|---|---|
| 1 | Proposal acronym | | | | |
| 2 | Proposal title | | | | |
| 3 | Call identifier | | | | |
| 4 | Funding programme | | | | |
| 5 | Submission date (ISO 8601 or null) | | | | |
| 6 | Stated total requested amount (euro cents) | | | | |
| 7 | TRL start | | | | |
| 8 | TRL target | | | | |
| 9 | MCRL start | | | | |
| 10 | MCRL target | | | | |

## Part 2. Partners

| No | Name as written in section 2.1 | Requested amount (euro cents) | Page of name | Page and location of amount | Notes |
|---|---|---|---|---|---|
| P1 | | | | | |
| P2 | | | | | |
| P3 | | | | | |
| P4 | | | | | |
| P5 | | | | | |
| P6 | | | | | |
| P7 | | | | | |
| P8 | | | | | |

## Part 3. Agreement (filled by the researcher after unblinding)

Total values compared: 20 (10 single fields, 5 partner names, 5 partner amounts).
Values in agreement on first comparison: ____ of 20. Initial agreement rate: ____ %.

| No | Field | Extractor value | Answer key value | Cause (key error, design error, extractor error) | Fix applied |
|---|---|---|---|---|---|
| | | | | | |

Complete agreement must be reached by fixing the design or the key before the document is frozen. Record the initial rate even if later fixes lead to full agreement.
