# Task: create synthetic project proposal SP02 (national innovation application with code generated visuals)

You are helping a researcher build a synthetic test document for a master thesis. The thesis evaluates how well language models extract structured data from research project proposals. The document will never be submitted to any real call. Its only purpose is to test the extraction pipeline under known, controlled difficulties, with a ground truth that is correct by construction.

This document is one of five in a set. You do not need the others; everything you need is in this prompt.

Work through the steps in order. Where a step needs a human (marked HUMAN STEP), prepare the material and a checklist, and never claim the step is done.

## 1. Status and identification

* Document ID: SP02. Version: 1.0.
* Every page carries a small footer: "Synthetic document for research purposes, ID SP02, version 1.0". Record this footer in the answer key as a known non target string.
* The PDF metadata fields (title, author, subject) state the ID and the word "synthetic".
* Language: English, with European spelling (organisation, modelling, programme).
* Length: 40 to 45 pages including annexes. Born digital PDF.
* Layout: two column layout throughout the main text, with sidebars, callout boxes, captioned figures and footnotes.

## 2. Fictional content rules

* All organisations, persons, projects and call identifiers are fictional.
* The funding programme field is "Business Finland" (a real public funder). Do not name any specific Business Finland funding instrument, and do not state any real funding rule.
* The call identifier is invented, follows the syntax BF[year]/[five digits], and must not exist.
* No partner may use or imitate CLIC Innovation or any real organisation.
* No personal data. No CVs, no named individuals except obviously fictional contact roles (for example "Project Manager").
* Produce a list of all organisation names and the call identifier for the HUMAN STEP check against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced.
* Produce a synthetic partner register file (`SP02_partner_register.csv`) with the columns legal name, all aliases used in the document, acronym and category (company, university, research organisation, public body, other). It is kept separate from any real partner register.

## 3. Target fields (ground truth schema)

The answer key covers exactly these fields:

1. Proposal acronym
2. Proposal title
3. Call identifier
4. Funding programme
5. Submission date
6. Stated total requested amount
7. TRL start
8. TRL target
9. MCRL start
10. MCRL target
11. For each partner: the name as written in the partner descriptions (section 2.1) and its requested amount

Formats in the answer key:
* Amounts are integers in euro cents.
* Dates use ISO 8601.
* Booleans are 0 or 1.
* A field not stated in the document is null.

The derived requested total is the sum of the partner amounts. In SP02, the stated total equals that sum.

## 4. Consortium and values

* Five partners:
  * Partner A, a company (funded);
  * Partner B, a company (funded);
  * Partner C, a company with no requested funding, recorded as zero in the answer key;
  * Partner D, a university (funded);
  * Partner E, a research organisation (funded).
* Total requested amount: between 800,000 and 2,000,000 euro.
* Funding rate: between 40% and 60% of eligible costs for companies, and between 70% and 80% for the university and the research organisation. These are synthetic ranges, not real programme rules.
* Total project volume including in kind contributions is always higher than total eligible costs, which is always higher than the total requested amount.
* All values are drawn with a fixed random seed recorded in the data file.

## 5. Build method: data first, document second

1. **Write the data file first** (`SP02_data.yaml`). It holds every target value, every distractor value, every difficulty placement with its page, and the random seed.
2. **Render the document only from the data file** (`SP02_template`), using LaTeX or HTML rendered to PDF. Every number, date, name and acronym in the document must come from the data file.
3. **Generate every chart, logo strip and roadmap graphic with code** (Python with matplotlib), from the same data file and seed. Save the scripts with the output. Text inside images must be rendered as part of the image, not as a text layer.
4. **Keep language model text free of facts.** A language model may write narrative prose only. Numbers, dates, organisation names and acronyms enter the text only through template placeholders.
5. **Check the prose.** A script scans all model written prose and fails the build if it finds any number, date, organisation name or acronym that does not come from the data file.
6. **Build without the model.** The build script reads only stored files (data file, template, paragraph bank) and never calls a language model, so a rebuild produces an identical PDF.

## 6. Effort limits

* The document only has to look plausible to a reader skimming it. Scientific validity, real literature, coherent research logic and compliance with real call rules are not required.
* Only three elements are crafted with care:
  * the target fields;
  * the distractors;
  * the injected difficulties in section 8.

  Everything else is filler.
* Write a paragraph bank once for this document (`SP02_paragraph_bank.md`): 40 to 60 neutral, domain plausible paragraphs about innovation, consortium work, dissemination and risk. Write each paragraph once, in a single pass, with no iterative polishing. Regenerate a paragraph only if verification in section 11 fails.
* Filler paragraphs are selected and ordered from the bank with the seed recorded in the data file, and may repeat.
* Filler contains no numbers, dates, organisation names or acronyms.
* Annexes use repeatable structures generated from the data file: work package tables, deliverable lists, risk tables and a Gantt chart. No CVs.
* Length is reached by adding filler sections and annexes, never by expanding the crafted parts.

## 7. Document structure and page map

Keep within these page ranges. Adjust filler to fit.

| Pages | Content |
|---|---|
| 1 | Cover page. Text: funding programme, call identifier, proposal acronym, and the proposal title set in large type with a forced line break in the middle of the title. A line "Document prepared: [date]" shows a date that is not the submission date. A code generated logo strip shows the five partner acronyms as images. |
| 2 | Table of contents |
| 3 to 4 | Executive summary, with a callout box stating the total project volume including in kind contributions. The text says the requested funding is "detailed in section 5.3". |
| 5 to 12 | Section 1, Challenge and solution. A code generated roadmap graphic (Figure 1.1, around page 10) carries the TRL start and TRL target as labels inside the image. |
| 13 to 20 | Section 2, Consortium. Section 2.1 introduces each partner by legal name followed by its acronym in brackets, with a postal address spread over three lines. |
| 21 to 28 | Section 3, Work plan, with sidebars and footnotes. |
| 29 to 32 | Section 4, Market and commercialisation. A sidebar box (around page 30) states MCRL start and MCRL target. |
| 33 to 36 | Section 5, Budget and funding: Table 5.1, Figure 5.1, Table 5.2, Figure 5.2 and section 5.3. |
| 37 to 45 | Annexes: Gantt chart, work package tables, deliverables, risk register |

## 8. Difficulties to inject

Record each difficulty in the manifest with its issue number. Issue numbers and source papers come from the thesis literature list: V = VRDU (Wang et al., 2023), D = DocILE (Šimsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanisławek et al., 2021).

1. **#1 Complex layout [V, D, K, M].** Two columns, sidebars, callout boxes, captioned figures and footnotes on most content pages. Tables and figures in section 5 span both columns.
2. **#4 Reading order [D].**
   * On one page in section 3, a footnote continues across the column break.
   * The MCRL sidebar box is placed between the two columns, so a naive top to bottom reading interleaves it with body text.
3. **#8 and #26 Values only in images [M, K].**
   * Figure 5.1 is a stacked bar chart of requested funding per funded partner, with segments for year 1 and year 2 and a printed total label on top of each bar.
   * The requested amounts of partners D and E appear only in Figure 5.1, as the total labels.
   * TRL start and TRL target appear only in the roadmap graphic (Figure 1.1).
4. **#14 Scale stated elsewhere [T, K].**
   * Table 5.1 states "EUR thousand" only in its column header; the cells show bare numbers with one decimal.
   * Figure 5.1 states "EUR thousand" only in its axis title; the data labels show bare numbers.
   * The answer key holds full euro cents.
5. **#15 and #16 Several amounts with different meanings [V, T, K].**
   * The executive summary callout states the total project volume including in kind contributions.
   * Table 5.2 lists eligible costs per partner, which are not requested amounts.
   * Figure 5.2 is a pie chart of each partner's share of the requested total, shown as percentages only.
   * Section 2.1 mentions funding that partner A received in an earlier, unrelated project.
6. **#18 and #20 Table plus text, name variants [T, M, K].**
   * Table 5.1 and Figure 5.1 identify partners only by acronym.
   * The legal names, the target "name as written", appear only in section 2.1, each followed by its acronym in brackets.
   * Answering requires linking the acronym in the table or chart to the legal name in the text.
7. **#22 Value spread over several lines [V, D].** The proposal title on the cover has a forced line break in the middle. The answer key holds the full title as one string.
8. **#24 Zero funded partner [K, V, D].** Partner C appears in section 2.1, in Table 5.1 with the text "no funding requested", and in the logo strip. Partner C is absent from Figures 5.1 and 5.2.
9. **#24 and #29 Absent field [M].** The submission date is not stated anywhere, so the answer key value is null. The "Document prepared" date on the cover is a distractor and must be recorded as such.
10. **#25 Varying labels [V].** Table 5.1 heads its partner column "Organisation". Table 5.2 heads the same column "Beneficiary".
11. **#27 and #28 Cross reference and locating [M].**
    * The executive summary refers to section 5.3 for the requested funding.
    * Section 5.3 states the total requested amount in text.
    * The MCRL values sit deep in the document, in section 4.

## 9. Authority rules

Write these into the answer key header:

* Table 5.1 is authoritative for the requested amounts of partners A, B and C.
* The total labels in Figure 5.1 are authoritative for partners D and E. For partners A and B, the Figure 5.1 labels must equal the Table 5.1 values.
* Section 5.3 is authoritative for the stated total requested amount.
* Figure 5.2, Table 5.2 and the executive summary callout are never authoritative for any target field.
* The "Document prepared" date is not the submission date.
* The footer text is a non target string.

## 10. Deliverables

1. `SP02.pdf`
2. `SP02_data.yaml`, with the seed
3. `SP02_template` (source files) and `build` script: one command rebuilds everything
4. `SP02_charts.py` (bar chart, pie chart, roadmap graphic, logo strip)
5. `SP02_answer_key.json`. For each target value: field, value, page, location type (text, table, figure), exact surface string, authority rule applied, and a list of distractors with page and surface string.
6. `SP02_manifest.csv`. One row per difficulty, with the columns issue number, source papers, page, affected field, description and expected failure mode.
7. `SP02_partner_register.csv`
8. `SP02_paragraph_bank.md`
9. `SP02_generation_log.md`. One entry per language model call, with: date and time, purpose of the call, full prompt, full output (or file name with SHA-256 checksum), and where the output is used. Leave a field "model and interface details" in each entry for the researcher to fill in.
10. `requirements.lock` with pinned versions, plus a note of operating system and fonts used
11. `SP02_checksums.txt` with SHA-256 checksums of all outputs
12. `CHANGELOG.md`, starting at version 1.0
13. `SP02_datasheet.md`, following Gebru et al. (2021), _Datasheets for Datasets_. It states purpose, creation process, author, intended use, which parts are filler, the link between each difficulty and the literature, licence, and the limitation that results on author written synthetic documents are not evidence about real proposals.

## 11. Verification before release

1. **Text layer check (automatic).** A script confirms that every target value expected in text or tables is present on the stated page of the PDF text layer.
2. **Image value check (automatic plus manual).**
   * A script confirms that the values in Figure 1.1 and Figure 5.1 do **not** appear in the PDF text layer, so they exist only inside images.
   * A person then confirms visually that they are legible.
3. **Page count and placement check (automatic).** The PDF has between 40 and 45 pages, and the elements in the page map fall within their ranges.
4. **Consistency check (automatic).**
   * The Figure 5.1 labels for partners A and B equal the Table 5.1 values.
   * The partner amounts sum to the total stated in section 5.3.
5. **Filler check (automatic).** No filler paragraph contains a number, date, organisation name or acronym.
6. **Blind second extraction (HUMAN STEP).** Prepare an empty extraction form with the target fields. A second person extracts all values from the PDF without seeing the answer key. Every disagreement leads to a fix of the design or the key until agreement is complete. Record the initial agreement rate.
7. **Realism review (HUMAN STEP).** Prepare a short plausibility checklist for a person familiar with real proposals.
8. **Name check (HUMAN STEP).** Prepare the list of organisation names and the call identifier for the YTJ and web search.
9. **Freeze.** After all checks pass, tag version 1.0, write checksums, and do not edit the files again. Any later change creates a new version recorded in the changelog. The document must be frozen before any extraction prompt is developed, and must never be opened during prompt tuning.

At the end, report:
* what was produced;
* the results of the automatic checks;
* the human steps still open.