# SP02 environment note

Recorded when version 1.0 was built. Python packages are pinned in requirements.lock.

* Operating system: "Ubuntu 24.04.5 LTS" (Linux 6.18.44-fc-v153, x86_64)
* Python: Python 3.13.17
* Typesetting: XeTeX 3.141592653-2.6-0.999995 (TeX Live 2023/Debian); the PDF is written by xdvipdfmx with SOURCE_DATE_EPOCH and FORCE_SOURCE_DATE set from the data file, so a rebuild gives an identical file
* Text layer and page tools: pdftotext version 24.02.0, pdftoppm version 24.02.0
* OCR used only in the automatic legibility proxy: tesseract 5.3.4
* Fonts in the PDF: TeX Gyre Pagella (body), TeX Gyre Heros (headings, boxes, tables)
  * :file=/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyrepagella-regular.otf
  * :file=/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyreheros-regular.otf
* Fonts in the images (matplotlib, rendered as pixels): DejaVu Sans
  * :file=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf
* Ligatures are switched off so that the text layer holds plain letters.
* Random seed: 20260314 (values), 20260314 (filler selection). Both are recorded in SP02_data.yaml.
* Build command: ./build (runs the prose check, the charts, the render, the page location, the answer key, the checks and the checksums).
