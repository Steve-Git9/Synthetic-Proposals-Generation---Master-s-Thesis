#!/usr/bin/env python3
"""Generates every chart, logo strip and graphic of SP02 from SP02_data.yaml.

Text inside the images is rendered as pixels (PNG), so it never enters the PDF text layer.
Usage: python3 SP02_charts.py [data.yaml] [output_dir]
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Polygon
import yaml

NAVY, TEAL, SAND, SLATE, ROSE, GREEN = "#1f3a5f", "#2a9d8f", "#e9c46a", "#5c6b7a", "#c8553d", "#6a994e"
PALETTE = {"A": NAVY, "B": TEAL, "C": SAND, "D": ROSE, "E": GREEN}
INK = "#1d2733"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": SLATE, "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": INK, "ytick.color": INK, "figure.dpi": 100, "savefig.dpi": 300,
    "svg.fonttype": "path",
})


def save(fig, path):
    fig.savefig(path, format="png", facecolor="white", metadata={"Software": "matplotlib"})
    plt.close(fig)


def rbox(ax, x, y, w, h, fc, ec=None, r=0.12, lw=1.0):
    p = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec or fc, lw=lw)
    ax.add_patch(p)
    return p


def logo_strip(data, out):
    parts = data["partners"]
    fig, ax = plt.subplots(figsize=(6.7, 0.95))
    ax.set_xlim(0, 5 * 1.34)
    ax.set_ylim(0, 1)
    ax.axis("off")
    for i, p in enumerate(parts):
        x = i * 1.34 + 0.04
        rbox(ax, x, 0.08, 1.22, 0.84, PALETTE[p["key"]], r=0.14)
        tc = INK if p["key"] == "C" else "white"
        ax.text(x + 0.61, 0.5, p["acronym"], ha="center", va="center", fontsize=17, fontweight="bold", color=tc)
    save(fig, out)


def roadmap(data, out):
    r = data["readiness"]
    fig, ax = plt.subplots(figsize=(5.2, 3.9))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 8)
    ax.axis("off")
    cols = ["#9ccfc8", "#6fb8ae", "#3fa497", NAVY]
    names = ["Concept", "Prototype", "Field\nvalidation", "Demon-\nstration"]
    names = ["Concept", "Prototype", "Field trials", "Pilot use"]
    for i in range(4):
        h = 1.3 + 1.05 * i
        x = 0.9 + 2.15 * i
        rbox(ax, x, 0.9, 2.0, h, cols[i], r=0.1)
        ax.text(x + 1.0, 0.9 + h - 0.35, names[i], ha="center", va="center", fontsize=9,
                color=INK if i < 3 else "white", fontweight="bold")
    # start and end badges
    for (cx, cy, head, val) in [(1.9, 3.7, "Project start", f"TRL {r['trl_start']}"),
                                (8.35, 6.55, "Project end", f"TRL {r['trl_target']}")]:
        rbox(ax, cx - 1.05, cy - 0.7, 2.1, 1.4, "white", ec=NAVY, r=0.15, lw=1.6)
        ax.text(cx, cy + 0.32, head, ha="center", va="center", fontsize=8.5, color=SLATE)
        ax.text(cx, cy - 0.16, val, ha="center", va="center", fontsize=15, fontweight="bold", color=NAVY)
    ax.add_patch(FancyArrowPatch((3.05, 4.25), (7.25, 6.6), arrowstyle="-|>", mutation_scale=14, lw=1.4,
                                 color=SLATE, linestyle=(0, (4, 3)), connectionstyle="arc3,rad=-0.18"))
    ax.add_patch(FancyArrowPatch((0.75, 0.35), (9.6, 0.35), arrowstyle="-|>", mutation_scale=12, lw=1.2, color=SLATE))
    ax.text(5.1, 0.05, "Project time", ha="center", va="top", fontsize=8, color=SLATE)
    ax.add_patch(FancyArrowPatch((0.35, 0.9), (0.35, 7.6), arrowstyle="-|>", mutation_scale=12, lw=1.2, color=SLATE))
    ax.text(0.05, 4.2, "Technology readiness", rotation=90, ha="center", va="center", fontsize=8, color=SLATE)
    save(fig, out)


def fig51(data, out):
    parts = [p for p in data["partners"] if p["requested_cents"] > 0 and p["key"] in "ABDE"]
    labels = [p["acronym"] for p in parts]
    y1 = [p["year1_cents"] / 100000 for p in parts]
    y2 = [p["year2_cents"] / 100000 for p in parts]
    tot = [p["requested_cents"] / 100000 for p in parts]
    fig, ax = plt.subplots(figsize=(6.7, 3.3))
    xs = range(len(parts))
    ax.bar(xs, y1, width=0.55, color=NAVY, label="Year 1")
    ax.bar(xs, y2, width=0.55, bottom=y1, color=TEAL, label="Year 2")
    for x, t, p in zip(xs, tot, parts):
        assert p["fig51_label"] == f"{t:.1f}"
        ax.text(x, t + max(tot) * 0.025, p["fig51_label"], ha="center", va="bottom", fontsize=11, fontweight="bold")
    ax.set_xticks(list(xs))
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("EUR thousand")
    ax.set_ylim(0, max(tot) * 1.2)
    ax.spines[["top", "right"]].set_visible(False)
    ax.legend(frameon=False, loc="upper left", fontsize=8.5)
    fig.tight_layout()
    save(fig, out)


def fig52(data, out):
    pct = data["pie_percent"]
    keys = [k for k in "ABCDE" if k in pct]
    acr = {p["key"]: p["acronym"] for p in data["partners"]}
    fig, ax = plt.subplots(figsize=(6.7, 3.1))
    wedges, _t, autot = ax.pie([pct[k] for k in keys], colors=[PALETTE[k] for k in keys], startangle=90,
                               counterclock=False, autopct=lambda v: "", pctdistance=0.72,
                               wedgeprops=dict(edgecolor="white", linewidth=2))
    import math
    cum = 0.0
    for k in keys:
        mid = 90 - (cum + pct[k] / 2) * 3.6
        cum += pct[k]
        x, y = 0.68 * math.cos(math.radians(mid)), 0.68 * math.sin(math.radians(mid))
        ax.text(x, y, f"{pct[k]:.1f}%", ha="center", va="center", fontsize=10, fontweight="bold",
                color=INK if k in "C" else "white")
    ax.legend(wedges, [acr[k] for k in keys], frameon=False, loc="center left", bbox_to_anchor=(1.0, 0.5),
              fontsize=10, title="Share of the requested total", title_fontsize=9)
    ax.set_aspect("equal")
    save(fig, out)


def gantt(data, out):
    wps = data["workplan"]["work_packages"]
    ms = data["workplan"]["milestones"]
    acr = {p["key"]: p["acronym"] for p in data["partners"]}
    n = len(wps)
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    for i, w in enumerate(wps):
        y = n - i
        ax.barh(y, w["end_month"] - w["start_month"] + 1, left=w["start_month"] - 1, height=0.55,
                color=[NAVY, TEAL, SLATE, ROSE, GREEN, "#b08900"][i % 6])
        ax.text(w["start_month"] - 1 + 0.4, y, acr[w["lead"]], va="center", ha="left", fontsize=8, color="white",
                fontweight="bold")
    ax.scatter([m["month"] for m in ms], [0] * len(ms), marker="D", s=46, color=INK, zorder=3, clip_on=False)
    for m in ms:
        ax.text(m["month"], -0.55, m["id"], ha="center", va="top", fontsize=7.5)
    ax.set_yticks(list(range(n, 0, -1)) + [0])
    ax.set_yticklabels([w["id"] for w in wps] + ["Milestones"], fontsize=9)
    ax.set_xlim(0, data["project"]["duration_months"] + 1)
    ax.set_xticks(range(0, data["project"]["duration_months"] + 1, 3))
    ax.set_xlabel("Project month")
    ax.set_ylim(-1.2, n + 0.7)
    ax.grid(axis="x", color="#d8dee4", lw=0.7)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    save(fig, out)


# ----------------------------------------------------------------------- generic filler diagrams
def generic_components(out):
    fig, ax = plt.subplots(figsize=(4.4, 2.5))
    ax.set_xlim(0, 10); ax.set_ylim(0, 5.5); ax.axis("off")
    for x, t, c in [(0.3, "Sensing", NAVY), (3.7, "Platform", TEAL), (7.1, "Services", ROSE)]:
        rbox(ax, x, 2.0, 2.6, 1.5, c, r=0.2)
        ax.text(x + 1.3, 2.75, t, ha="center", va="center", color="white", fontsize=10, fontweight="bold")
    for x0, x1 in [(2.9, 3.6), (6.3, 7.0)]:
        ax.add_patch(FancyArrowPatch((x0, 2.75), (x1, 2.75), arrowstyle="-|>", mutation_scale=14, lw=1.5, color=SLATE))
    rbox(ax, 3.7, 0.2, 2.6, 1.1, "#eef2f5", ec=SLATE, r=0.15)
    ax.text(5.0, 0.75, "Data store", ha="center", va="center", fontsize=9)
    ax.add_patch(FancyArrowPatch((5.0, 2.0), (5.0, 1.35), arrowstyle="<|-|>", mutation_scale=11, lw=1.2, color=SLATE))
    rbox(ax, 3.7, 4.0, 2.6, 1.1, "#eef2f5", ec=SLATE, r=0.15)
    ax.text(5.0, 4.55, "Users", ha="center", va="center", fontsize=9)
    ax.add_patch(FancyArrowPatch((5.0, 3.5), (5.0, 4.0), arrowstyle="<|-|>", mutation_scale=11, lw=1.2, color=SLATE))
    return fig


def generic_layers(out):
    fig, ax = plt.subplots(figsize=(4.4, 2.7))
    ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")
    names = ["Decision support", "Analytics", "Data platform", "Communication", "Sensing"]
    cols = [ROSE, "#d98a73", TEAL, "#5aa9a0", NAVY]
    for i, (n, c) in enumerate(zip(names, cols)):
        y = 5.0 - i * 1.05
        rbox(ax, 1.0 + i * 0.0, y - 0.45, 8.0, 0.9, c, r=0.12)
        ax.text(5.0, y, n, ha="center", va="center", color="white", fontsize=9.5, fontweight="bold")
    return fig


def generic_workorg(out):
    fig, ax = plt.subplots(figsize=(4.4, 2.5))
    ax.set_xlim(0, 10); ax.set_ylim(0, 5.5); ax.axis("off")
    rbox(ax, 3.2, 4.1, 3.6, 1.1, NAVY, r=0.15)
    ax.text(5.0, 4.65, "Coordination", ha="center", va="center", color="white", fontsize=9.5, fontweight="bold")
    for i, t in enumerate(["Design", "Build", "Test", "Share"]):
        x = 0.3 + i * 2.45
        rbox(ax, x, 1.5, 2.1, 1.2, TEAL if i % 2 == 0 else "#5aa9a0", r=0.15)
        ax.text(x + 1.05, 2.1, t, ha="center", va="center", color="white", fontsize=9.5, fontweight="bold")
        ax.add_patch(FancyArrowPatch((5.0, 4.1), (x + 1.05, 2.75), arrowstyle="-", lw=1.0, color=SLATE))
    rbox(ax, 0.3, 0.1, 9.25, 0.8, "#eef2f5", ec=SLATE, r=0.12)
    ax.text(4.9, 0.5, "Shared results and documentation", ha="center", va="center", fontsize=8.5)
    return fig


def generic_cycle(out):
    import math
    fig, ax = plt.subplots(figsize=(4.4, 2.7))
    ax.set_xlim(-2.6, 2.6); ax.set_ylim(-1.7, 1.7); ax.set_aspect("equal"); ax.axis("off")
    names = ["Observe", "Analyse", "Decide", "Act"]
    cols = [NAVY, TEAL, ROSE, GREEN]
    pts = []
    for i, n in enumerate(names):
        ang = 90 - i * 90
        x, y = 1.35 * math.cos(math.radians(ang)) * 1.25, 1.0 * math.sin(math.radians(ang)) * 1.15
        pts.append((x, y))
        rbox(ax, x - 0.62, y - 0.26, 1.24, 0.52, cols[i], r=0.1)
        ax.text(x, y, n, ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    for i in range(4):
        (x0, y0), (x1, y1) = pts[i], pts[(i + 1) % 4]
        ax.add_patch(FancyArrowPatch((x0 * 0.82, y0 * 0.78), (x1 * 0.82, y1 * 0.78), arrowstyle="-|>",
                                     mutation_scale=12, lw=1.3, color=SLATE, connectionstyle="arc3,rad=-0.35"))
    return fig


def generic_collab(out):
    fig, ax = plt.subplots(figsize=(4.4, 2.5))
    ax.set_xlim(0, 10); ax.set_ylim(0, 5.5); ax.axis("off")
    rbox(ax, 3.4, 4.2, 3.2, 1.0, NAVY, r=0.15)
    ax.text(5.0, 4.7, "Steering group", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    rbox(ax, 0.4, 2.2, 3.6, 1.1, TEAL, r=0.15)
    ax.text(2.2, 2.75, "Partners", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    rbox(ax, 6.0, 2.2, 3.6, 1.1, ROSE, r=0.15)
    ax.text(7.8, 2.75, "User group", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    for x in (2.2, 7.8):
        ax.add_patch(FancyArrowPatch((5.0, 4.2), (x, 3.35), arrowstyle="-", lw=1.1, color=SLATE))
    ax.add_patch(FancyArrowPatch((4.05, 2.75), (5.95, 2.75), arrowstyle="<|-|>", mutation_scale=11, lw=1.2, color=SLATE))
    rbox(ax, 2.2, 0.3, 5.6, 0.9, "#eef2f5", ec=SLATE, r=0.12)
    ax.text(5.0, 0.75, "Regular exchange of results", ha="center", va="center", fontsize=8.5)
    return fig


def main():
    data_path = sys.argv[1] if len(sys.argv) > 1 else "SP02_data.yaml"
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join("_work", "figures")
    os.makedirs(out_dir, exist_ok=True)
    data = yaml.safe_load(open(data_path, encoding="utf-8"))
    logo_strip(data, os.path.join(out_dir, "logo_strip.png"))
    roadmap(data, os.path.join(out_dir, "fig_roadmap.png"))
    fig51(data, os.path.join(out_dir, "fig_requested_funding.png"))
    fig52(data, os.path.join(out_dir, "fig_funding_share.png"))
    gantt(data, os.path.join(out_dir, "fig_gantt.png"))
    for name, fn in [("generic_components", generic_components), ("generic_layers", generic_layers),
                     ("generic_workorg", generic_workorg), ("generic_cycle", generic_cycle),
                     ("generic_collab", generic_collab)]:
        fig = fn(None)
        save(fig, os.path.join(out_dir, name + ".png"))
    print("figures written to", out_dir)


if __name__ == "__main__":
    main()
