#!/usr/bin/env python3
"""Draws every numeric value of SP02 with a fixed seed and writes SP02_data.yaml.

Run once. The build reads only the resulting data file; it never calls this script.
All names, titles and texts in this file are fictional and were written by a language model
(see SP02_generation_log.md). All numbers are drawn here from the seed.
"""
import datetime
import random
import yaml

SEED = 20260314
rng = random.Random(SEED)

# ---------------------------------------------------------------- fictional identity
PARTNERS = [
    dict(key="A", profile="is a company that develops and manufactures ruggedised sensor hardware for outdoor monitoring. In the project it leads the development of the sensor platform.", legal_name="Nordvalen Systems Oy", alias="Nordvalen Systems", acronym="NVS",
         category="company", funded=True,
         address=["Tervaniemi Road 14", "00000 Pelmora", "Finland"],
         elig=(260_000, 520_000), rate=(0.40, 0.60)),
    dict(key="B", profile="is a company that provides data analytics and software services for infrastructure operators. In the project it leads the work on requirements and system architecture.", legal_name="Kaltiora Analytics Oy", alias="Kaltiora Analytics", acronym="KTA",
         category="company", funded=True,
         address=["Meriharju Lane 7", "00000 Kaltiora", "Finland"],
         elig=(220_000, 460_000), rate=(0.40, 0.60)),
    dict(key="C", profile="is a company that provides installation and maintenance services for marine and coastal equipment. In the project it contributes its customer network and leads the work on exploitation.", legal_name="Lumenthar Marine Oy", alias="Lumenthar Marine", acronym="LMR",
         category="company", funded=False,
         address=["Satamakuja 3", "00000 Lumenthar", "Finland"],
         elig=(120_000, 280_000), rate=None),
    dict(key="D", profile="is a university with research groups in statistical modelling and environmental engineering. In the project it leads the work on data analytics and modelling.", legal_name="Havrenmaa University", alias="University of Havrenmaa", acronym="HVU",
         category="university", funded=True,
         address=["Campus Ring 1", "00000 Havrenmaa", "Finland"],
         elig=(300_000, 540_000), rate=(0.70, 0.80)),
    dict(key="E", profile="is a research organisation that operates test facilities and field sites along the coast. In the project it leads the field trials and the validation.", legal_name="Taimerra Research Institute", alias="Taimerra Institute", acronym="TMI",
         category="research organisation", funded=True,
         address=["Laboratory Street 22", "00000 Taimerra", "Finland"],
         elig=(280_000, 500_000), rate=(0.70, 0.80)),
]


def r100(x):
    """Round a euro amount to the nearest 100 euro (one decimal in EUR thousand)."""
    return int(round(x / 100.0)) * 100


def draw_money():
    for attempt in range(1, 200):
        out = {}
        for p in PARTNERS:
            elig = r100(rng.uniform(*p["elig"]))
            if p["funded"]:
                rate = round(rng.uniform(*p["rate"]), 2)
                req = r100(elig * rate)
                real_rate = req / elig
                assert p["rate"][0] <= real_rate <= p["rate"][1]
            else:
                req, real_rate = 0, None
            inkind = r100(elig * rng.uniform(0.06, 0.14))
            share = rng.uniform(0.38, 0.58)
            y1 = r100(req * share) if req else 0
            out[p["key"]] = dict(elig=elig, req=req, rate=real_rate, inkind=inkind, y1=y1, y2=req - y1)
        total = sum(v["req"] for v in out.values())
        if 800_000 <= total <= 2_000_000:
            return out, attempt
    raise RuntimeError("no draw satisfied the range")


money, attempts = draw_money()
req_total = sum(v["req"] for v in money.values())
elig_total = sum(v["elig"] for v in money.values())
inkind_total = sum(v["inkind"] for v in money.values())
volume_total = elig_total + inkind_total
assert volume_total > elig_total > req_total

# pie percentages, one decimal, forced to sum to 100.0
funded_keys = [k for k, v in money.items() if v["req"] > 0]
pct = {k: round(money[k]["req"] / req_total * 100, 1) for k in funded_keys}
diff = round(100.0 - sum(pct.values()), 1)
if diff:
    big = max(funded_keys, key=lambda k: money[k]["req"])
    pct[big] = round(pct[big] + diff, 1)
assert abs(sum(pct.values()) - 100.0) < 1e-9

trl_start = rng.choice([2, 3, 4])
trl_target = trl_start + rng.choice([2, 3])
mcrl_start = rng.choice([1, 2, 3])
mcrl_target = mcrl_start + rng.choice([2, 3])

prepared = datetime.date(2026, 2, 2) + datetime.timedelta(days=rng.randint(0, 80))
while prepared.weekday() > 4:
    prepared += datetime.timedelta(days=1)
call_number = rng.randint(10000, 99999)
earlier_amount = int(round(rng.uniform(120_000, 260_000) / 1000.0)) * 1000

# ---------------------------------------------------------------- work plan (annex material)
WPS = [
    ("WP1", "Project management and coordination", "A", 1, 30),
    ("WP2", "Requirements and system architecture", "B", 1, 9),
    ("WP3", "Sensor platform development", "A", 4, 20),
    ("WP4", "Data analytics and modelling", "D", 6, 24),
    ("WP5", "Field trials and validation", "E", 16, 28),
    ("WP6", "Dissemination, exploitation and commercialisation", "C", 10, 30),
]
person_months = {}
for wp, _t, lead, s, e in WPS:
    row = {}
    for p in PARTNERS:
        base = 3 if p["key"] != lead else 8
        row[p["key"]] = rng.randint(base, base + 9) if (p["key"] == lead or rng.random() < 0.85) else 0
    person_months[wp] = row

DELIVERABLES = [
    ("D1.1", "Project management handbook", "WP1", 3),
    ("D1.2", "Periodic coordination report", "WP1", 15),
    ("D1.3", "Final coordination report", "WP1", 30),
    ("D2.1", "Stakeholder requirements catalogue", "WP2", 5),
    ("D2.2", "Reference architecture description", "WP2", 9),
    ("D3.1", "Sensor node specification", "WP3", 8),
    ("D3.2", "Initial prototype of the sensor platform", "WP3", 14),
    ("D3.3", "Hardened platform release", "WP3", 20),
    ("D4.1", "Data model and ingestion design", "WP4", 10),
    ("D4.2", "Analytics toolbox, initial release", "WP4", 17),
    ("D4.3", "Analytics toolbox, final release", "WP4", 24),
    ("D5.1", "Trial plan and measurement protocol", "WP5", 18),
    ("D5.2", "Field trial report", "WP5", 26),
    ("D5.3", "Validation summary", "WP5", 28),
    ("D6.1", "Dissemination and communication plan", "WP6", 12),
    ("D6.2", "Market analysis report", "WP6", 18),
    ("D6.3", "Exploitation and commercialisation plan", "WP6", 28),
    ("D6.4", "Final dissemination report", "WP6", 30),
]

RISKS = [
    ("R1", "Delay in the availability of sensor components", "medium", "high",
     "Order critical components early and qualify an alternative supplier before the prototype phase."),
    ("R2", "Partner staff turnover reduces continuity", "medium", "medium",
     "Document all work in shared repositories and keep deputies for every lead role."),
    ("R3", "Field trial conditions are not representative", "low", "high",
     "Select trial sites jointly with the end users and agree measurement protocols in advance."),
    ("R4", "Data quality from the sensors is lower than planned", "medium", "high",
     "Run calibration campaigns and apply quality flags in the ingestion layer."),
    ("R5", "Integration of platform and analytics takes longer than planned", "medium", "medium",
     "Agree interfaces early and test integration continuously instead of at the end."),
    ("R6", "Regulatory requirements change during the project", "low", "medium",
     "Monitor guidance from authorities and involve a compliance advisor at each milestone."),
    ("R7", "Market uptake is slower than expected", "medium", "medium",
     "Engage lead customers during development and adjust the offering based on trial feedback."),
    ("R8", "Cyber security weaknesses are found in the platform", "low", "high",
     "Perform security reviews at each release and keep an independent test before the trials."),
    ("R9", "Conflicts about intellectual property between partners", "low", "medium",
     "Conclude the consortium agreement before the start and record background rights clearly."),
    ("R10", "Weather interrupts field activities", "high", "low",
     "Plan buffer periods for outdoor work and keep indoor test benches available."),
]

# ---------------------------------------------------------------- difficulties (manifest source)
DIFFICULTIES = [
    dict(id=1, issue="#1", papers="V, D, K, M", field="all", location="main text, section 5 spans",
         planned_pages=[3, 36],
         description="Two column layout with sidebars, callout boxes, captioned figures and footnotes on most content pages. Tables and figures in section 5 span both columns.",
         failure="Text from sidebars, callouts and footnotes is merged with body text, or values are read from the wrong block."),
    dict(id=2, issue="#4", papers="D", field="MCRL start, MCRL target", location="section 3 footnote, section 4 sidebar",
         planned_pages=[21, 32],
         description="A footnote continues across the column break on one page in section 3. The MCRL sidebar box sits between the two columns, so a naive top to bottom reading interleaves it with body text.",
         failure="Lines of the sidebar are interleaved with body lines so MCRL values are missed or mixed; the split footnote is read as two unrelated fragments."),
    dict(id=3, issue="#8 and #26", papers="M, K", field="requested amount of D and E, TRL start, TRL target",
         location="Figure 5.1, Figure 1.1", planned_pages=[10, 35],
         description="The requested amounts of partners D and E appear only as total labels in Figure 5.1. TRL start and TRL target appear only inside the roadmap graphic, Figure 1.1.",
         failure="The model returns null or invents a value because the numbers exist only in images; a text only conversion cannot succeed."),
    dict(id=4, issue="#14", papers="T, K", field="requested amount of A, B, D, E",
         location="Table 5.1 header, Figure 5.1 axis title", planned_pages=[33, 35],
         description="The scale EUR thousand is stated only in the column header of Table 5.1 and in the axis title of Figure 5.1. Cells and data labels show bare numbers with one decimal.",
         failure="Amounts are copied as bare numbers (for example 412.5 euro) or the scale is applied inconsistently."),
    dict(id=5, issue="#15 and #16", papers="V, T, K", field="requested amount of every partner, stated total",
         location="executive summary callout, Table 5.2, Figure 5.2, section 2.1", planned_pages=[3, 36],
         description="The callout states the total project volume including in kind contributions. Table 5.2 lists eligible costs per partner. Figure 5.2 shows percentage shares only. Section 2.1 mentions funding that partner A received in an earlier project.",
         failure="An eligible cost, the project volume, a percentage share or the earlier funding is returned as a requested amount."),
    dict(id=6, issue="#18 and #20", papers="T, M, K", field="partner names",
         location="Table 5.1, Figure 5.1, section 2.1", planned_pages=[13, 36],
         description="Table 5.1 and Figure 5.1 identify partners by acronym only. The legal names appear only in section 2.1, each followed by its acronym in brackets. Short aliases occur in the work plan.",
         failure="The acronym or an alias is returned as the partner name, or amounts are attached to the wrong partner."),
    dict(id=7, issue="#22", papers="V, D", field="proposal title", location="cover page", planned_pages=[1, 1],
         description="The proposal title on the cover is set in large type with a forced line break in the middle.",
         failure="Only the first line is returned, or the two lines are joined with a stray separator."),
    dict(id=8, issue="#24", papers="K, V, D", field="requested amount of partner C", location="section 2.1, Table 5.1, logo strip",
         planned_pages=[1, 34],
         description="Partner C is described in section 2.1, appears in Table 5.1 with the text no funding requested, and in the logo strip. It is absent from Figures 5.1 and 5.2.",
         failure="Partner C is dropped from the list, given null instead of zero, or given an invented amount."),
    dict(id=9, issue="#24 and #29", papers="M", field="submission date", location="cover page",
         planned_pages=[1, 1],
         description="The submission date is not stated anywhere. The Document prepared date on the cover is a distractor.",
         failure="The prepared date is returned as the submission date instead of null."),
    dict(id=10, issue="#25", papers="V", field="requested amount, eligible costs", location="Table 5.1, Table 5.2",
         planned_pages=[33, 35],
         description="Table 5.1 heads the partner column Organisation. Table 5.2 heads the same column Beneficiary.",
         failure="The two tables are not recognised as describing the same entities, so eligible costs are mapped to requested amounts."),
    dict(id=11, issue="#27 and #28", papers="M", field="stated total requested amount, MCRL start, MCRL target",
         location="executive summary, section 5.3, section 4", planned_pages=[3, 36],
         description="The executive summary refers to section 5.3 for the requested funding. Section 5.3 states the total in text. The MCRL values sit deep in the document, in section 4.",
         failure="The model answers from the summary callout or fails to follow the reference and to locate the deep values."),
]

data = {
    "document": {
        "id": "SP02", "version": "1.0", "language": "en-GB",
        "footer_text": "Synthetic document for research purposes, ID SP02, version 1.0",
        "pdf_metadata": {"title": "SP02 synthetic proposal document",
                         "author": "SP02 synthetic document for research purposes",
                         "subject": "SP02 version 1.0, synthetic test document, never submitted to any call"},
        "page_limits": [40, 45],
        "source_date_epoch": 1773446400,
    },
    "seed": SEED,
    "draw_log": {"money_attempts": attempts, "generator": "SP02_draw_values.py"},
    "call": {"identifier": f"BF2026/{call_number}", "programme": "Business Finland"},
    "proposal": {
        "acronym": "TIDEMESH",
        "title": "Adaptive Sensor Networks for Resilient Coastal Infrastructure",
        "title_line1": "Adaptive Sensor Networks for",
        "title_line2": "Resilient Coastal Infrastructure",
    },
    "dates": {"submission": None, "prepared": prepared.isoformat(),
              "prepared_display": f"{prepared.day} {prepared.strftime('%B %Y')}"},
    "readiness": {"trl_start": trl_start, "trl_target": trl_target,
                  "mcrl_start": mcrl_start, "mcrl_target": mcrl_target},
    "partners": [],
    "totals": {
        "requested_cents": req_total * 100,
        "eligible_cents": elig_total * 100,
        "in_kind_cents": inkind_total * 100,
        "volume_cents": volume_total * 100,
        "stated_equals_derived": True,
    },
    "pie_percent": pct,
    "earlier_project": {"partner": "A", "description": "an earlier project on acoustic calibration of sensor nodes",
                        "amount_cents": earlier_amount * 100, "year": rng.choice([2019, 2020, 2021])},
    "project": {"duration_months": 30},
    "authority_rules": [
        "Table 5.1 is authoritative for the requested amounts of partners A, B and C.",
        "The total labels in Figure 5.1 are authoritative for partners D and E. For partners A and B, the Figure 5.1 labels equal the Table 5.1 values.",
        "Section 5.3 is authoritative for the stated total requested amount.",
        "Figure 5.2, Table 5.2 and the executive summary callout are never authoritative for any target field.",
        "The Document prepared date is not the submission date.",
        "The footer text is a non target string.",
    ],
    "workplan": {
        "work_packages": [dict(id=w, title=t, lead=l, start_month=s, end_month=e, person_months=person_months[w])
                          for w, t, l, s, e in WPS],
        "deliverables": [dict(id=i, title=t, wp=w, month=m) for i, t, w, m in DELIVERABLES],
        "risks": [dict(id=i, title=t, likelihood=l, impact=im, mitigation=m) for i, t, l, im, m in RISKS],
        "milestones": [dict(id="M1", title="Architecture agreed", month=9),
                       dict(id="M2", title="Initial prototype operational", month=14),
                       dict(id="M3", title="Trial campaign completed", month=26),
                       dict(id="M4", title="Final results presented", month=30)],
    },
    "layout": {
        "filler_seed": SEED,
        "filler_counts": {"exec": 15, "s1": 53, "s2": 48, "s3": 50, "s4_before": 5, "s4_left": 2, "s4_right": 3, "s4_after": 8, "s5a": 2, "s5b": 6, "s5c": 8, "annex": 3, "split_footnote_paragraph": 7, "split_footnote_pad_pt": 40},
        "notes": "filler_counts tune the page ranges only; they hold no facts",
    },
    "difficulties": [dict(d, page=None) for d in DIFFICULTIES],
}

for p in PARTNERS:
    m = money[p["key"]]
    data["partners"].append({
        "key": p["key"], "legal_name": p["legal_name"], "alias": p["alias"], "acronym": p["acronym"],
        "category": p["category"], "funded": p["funded"], "address": p["address"], "profile": p["profile"],
        "eligible_cents": m["elig"] * 100,
        "requested_cents": m["req"] * 100,
        "funding_rate": None if m["rate"] is None else round(m["rate"], 4),
        "in_kind_cents": m["inkind"] * 100,
        "year1_cents": m["y1"] * 100, "year2_cents": m["y2"] * 100,
        "table51_display": "no funding requested" if m["req"] == 0 else (
            f"{m['req'] / 1000:.1f}" if p["key"] in "AB" else "shown in Figure 5.1"),
        "fig51_label": None if m["req"] == 0 else f"{m['req'] / 1000:.1f}",
    })

with open("SP02_data.yaml", "w", encoding="utf-8") as fh:
    fh.write("# SP02 data file. Single source of every value in the document. Generated by SP02_draw_values.py\n")
    yaml.safe_dump(data, fh, sort_keys=False, allow_unicode=True, width=120)
print("written SP02_data.yaml; total requested EUR", req_total, "attempts", attempts)
