# Datasheet for SP05 (following Gebru et al., 2021, Datasheets for Datasets)

Document: SP05, version 1.0, build candidate 2026-10-26, not frozen.

## 1. Motivation

**Purpose.** SP05 is a synthetic research project proposal built to test how well language model pipelines extract structured fields from proposals. It is the adversarial document of a set of five. It concentrates layout and formatting edge cases that are rare in one real proposal but do occur, so that the limits of an extraction pipeline can be measured against a ground truth that is correct by construction.

**Who created it and for whom.** The document set was commissioned by the thesis author (Haaga-Helia master thesis, design science project). The generator was written in one run with a language model assistant (Claude), following the task prompt stored in SP05_task_prompt.md. Details of the model and interface are left open in SP05_generation_log.md for the researcher to fill in.

**Funding.** None specific to this document.

## 2. Composition

**Content.** A 78 page proposal for a fictional project (acronym NIVALIS) under the real public programme name "Digital Europe Programme". No real call, topic or rule is named. The call identifier is deliberately not given. Eight fictional partners P1 to P8. All names, amounts and dates are fictional. No personal data appears; signatures are code generated scribbles and only roles are named.

**Files.** SP05.pdf, SP05_data.yaml, template/ and build, SP05_charts.py, SP05_answer_key.json, SP05_manifest.csv, SP05_partner_register.csv, SP05_paragraph_bank.md, SP05_generation_log.md, requirements.lock, SP05_checksums.txt, CHANGELOG.md, this datasheet, SP05_gold.json (gold set in the ByggMap structure, written by SP05_make_gold.py). Support files: SP05_make_data.py (draws the data), SP05_build.py, SP05_verify.py, SP05_human_steps.md, SP05_check_report.md and .json, SP05_task_prompt.md.

**Target fields.** Acronym, title, call identifier (null), funding programme, submission date, stated total requested amount, TRL start and target, MCRL start and target, and per partner the name as written in the consortium list and the requested amount. The derived total (sum of partner amounts) is recorded separately.

**Parts that are filler.** Everything except the target fields, the distractors and the injected difficulties. Narrative prose comes from a bank of 56 paragraphs and a set of short text blocks, all free of numbers, dates, organisation names and acronyms. Annex tables (work packages, deliverables, risks, dissemination, checklist) are generated from the data file. Length is reached with filler, never by enlarging the crafted parts.

**Labels.** The answer key holds, for each target, the value, page, bounding box, location type, exact surface string, authority rule and distractors. Amounts are integer euro cents, dates are ISO 8601, and a field not stated is null.

**Known errors and mismatches by design.** The stated total requested amount is 2.346 percent above the derived total. This is intended. The pipeline is expected to flag it, not to correct it.

**Confidentiality.** None. The document is fully synthetic.

## 3. Collection and creation process

1. SP05_make_data.py draws all values with seed 20261026 and writes SP05_data.yaml. It also stores filler sequences and the calibrated length of each filler block, so the build does not depend on a random number generator.
2. SP05_charts.py draws the radar chart, the stamp, eight signature scribbles and the Gantt chart with matplotlib from the data file. Text in images is part of the image.
3. SP05_build.py renders the template with Jinja2 (strict undefined variables), typesets with xelatex in three passes, and post processes the PDF with pypdf (landscape page boxes, fixed metadata and dates).
4. The prose check scans all bank paragraphs and text blocks and fails the build on any digit, date, organisation name, acronym or number word that does not come through a placeholder.
5. SP05_verify.py runs the automatic checks, finds every target on its page with pdfplumber and writes the answer key, manifest, partner register and human steps file.
6. The build never calls a language model. Two builds in the same environment gave identical files.

**Language model use.** The model wrote the generator code, the template, the paragraph bank and the narrative blocks in one session. Facts enter the document only from the data file.

**Landscape pages.** xelatex cannot change page size per page. Landscape pages (41 to 43 and 67) are typeset on a portrait sheet with swapped text dimensions, then cropped and translated to A4 landscape boxes. The result has true landscape page boxes and a landscape text layer. It is not a rotated portrait page. A pipeline that relies on a page rotation flag will see rotation zero.

## 4. Difficulties and the literature they come from

Sources: V = VRDU (Wang et al., 2023), D = DocILE (Šimsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanisławek et al., 2021).

| Issue | Difficulty | Source papers | Where |
|---|---|---|---|
| #1 | Mixed portrait and landscape, switching between one and two columns | V, D, K, M | pages 4 to 78 |
| #3 | Long document, deep evidence, table continued 22 pages later | K, M | pages 42 and 64 |
| #10 and #11 | Grouped multi level header, two line rows, header reworded in annex | T, V, D | pages 42 and 64 |
| Nested table | TRL start inside a cell of Table 1.1 | V, D | page 9 |
| #14 and #21 | Finnish and international number formats, thousand scale, two date formats | T, K, V | pages 1, 3, 42, 43, 64, 60, 67, 77, 78 |
| #15 and #16 | Several amounts with different meanings, subtotal rows | V, T, K | pages 3, 42, 64 |
| #18 and #20 | Table with short names, legal names only in text | T, M, K | pages 16, 42, 64 |
| #20 and #30 | One entity under several spellings (P3) | K, M | pages 31, 67, 77 |
| #30 | Two entities with similar names (P5, P7) | M | pages 42 and 64 |
| #22 | Merged cell with mixed content (P4 and subcontracting) | V, D | page 42 |
| #23 | Stamp overlapping the submission date | D | page 1 |
| #24 and #29 | Placeholder instead of a call identifier | M | page 1 |
| #8 and #26 | MCRL target only in an image | M, K | page 38 |
| #24 | Zero funded partner (P6) | K, V, D | pages 16 and 64 |
| Design | Stated total differs from the derived total | none | pages 3, 43, 42, 64 |
| #31 | Localisation, every target at one verifiable place | D | all |

The issue numbers are those of the thesis literature list. The exact page numbers are in SP05_manifest.csv and SP05_answer_key.json.

## 5. Intended uses

Testing extraction pipelines on layout robustness, table continuation, name matching, number format handling, values in images, placeholders, and the detection of an inconsistent total. Scoring against SP05_answer_key.json under its authority rules.

**Not intended for.** Training. Estimating performance on real proposals. Any claim about real organisations, programmes or calls. The document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.

## 6. Adversarial nature

SP05 is built to make extraction fail in known ways, and each failure mode is declared in the manifest (for example wrong reading order, a duplicate partner for P3, mixed up P5 and P7, the call identifier invented, the total read from the stamp date or from the carried forward row). Every difficulty is meant to be fair: a careful human reader can find each target value. This fairness has to be confirmed by a person (human step 8) and has not been confirmed yet. Stacking many difficulties in one document makes it harder than any real proposal.

## 7. Distribution and licence

The licence is for the researcher to decide. A suggestion: CC BY 4.0 for the PDF and data files, and an open source licence such as MIT for the scripts. No licence text has been attached.

## 8. Maintenance

The author is the maintainer. After the freeze (human step 12), no file is edited. A later change creates a new version recorded in CHANGELOG.md. The current files are a pre freeze candidate. SP05_checksums.txt must be rewritten at freeze.

## 9. Limitations

* Results on author written synthetic documents are not evidence about real proposals. They show how a pipeline behaves under controlled, declared difficulties, nothing more.
* The document looks plausible to a skimming reader. It has not been reviewed by a person familiar with real proposals (human step 10).
* Organisation names have not been checked against the Finnish Trade Register (YTJ) or a web search (human step 11). Any match with a real entity must be replaced before freeze.
* A blind second extraction has not been done (human step 9), so the answer key has not been tested against an independent reader.
* The build is deterministic in the recorded environment (requirements.lock). Other TeX distributions or font versions may change line breaks and page counts.
