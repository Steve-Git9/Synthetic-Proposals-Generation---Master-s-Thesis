# SP05 automatic check report

Pages: 78. Result: ALL AUTOMATIC CHECKS PASSED.

* PASS: 1 Text layer: every text or table target found on its page. 25 text and table targets found
* PASS: 1b Text layer: target surface strings are unique in the document (apart from partner names and the stated total). all unique
* PASS: 2a Image value: MCRL target not in text layer. MCRL 5
* PASS: 2b Image value: stamp date not in text layer. 21.09.2026
* PASS: 2c Image value: bounding boxes of the radar chart and the stamp exist. 
* PASS: 3 Bounding box: each text layer bbox contains its surface string. all contain
* PASS: 4a Page count between 70 and 80. 78 pages
* PASS: 4b Pages of Section 5 (Table 5.1 part 1) are landscape. pages [41, 42, 43]
* PASS: 4b2 Landscape pages as planned. landscape pages [41, 42, 43, 67]
* PASS: 4c Annex C starts at least twenty pages after the last page of Table 5.1 part 1. part 1 on page 42, Annex C starts on page 64, gap 22
* PASS: 4d Layout switches between one and two columns at least four times. 8 switches; runs one column pages 2 to 3, two column pages 4 to 15, one column pages 16 to 25, two column pages 26 to 35, one column pages 36 to 47, two column pages 48 to 50, one column pages 51 to 54, two column pages 55 to 59, one column pages 60 to 78
* PASS: 5a Partner amounts parsed back from the PDF equal the data file. {'P1': 87076593, 'P2': 67949318, 'P3': 59420574, 'P4': 64930003, 'P5': 44983512, 'P6': 0, 'P7': 29800000, 'P8': 19920000}
* PASS: 5b Carried forward row equals the sum of P1 to P5 (all columns). carried forward row [273260000, 28740000, 60070000, 90520000, 452590000, 324360000]
* PASS: 5c Brought forward row equals the carried forward row. brought forward row [2732.6, 287.4, 600.7, 905.2, 4525.9, 3243.6]
* PASS: 5d Stated total is between 1% and 3% higher than the derived total. stated 3828561.00, derived 3740800.00, stated is 2.346% higher
* PASS: 5e Amounts of P5 and P7 differ by at least 20%. P5 449835.12, P7 298000.00, difference 33.8% of the larger
* PASS: 5f Total project cost is higher than the stated total. 
* PASS: 5g Derived total between 3,000,000 and 5,000,000 euro. 3740800.00
* PASS: 5h Data file derived total equals sum of partner amounts. 
* PASS: 6a P3 spelling variants never appear in the consortium list or in Table 5.1. []
* PASS: 6b P3 variants appear in a work package description and on the signature page. {'Valoria Laboratories Ltd': [31], 'Valoria Labs Ltd': [77]}
* PASS: 6c No call identifier pattern in the text layer. patterns found: []; pages with the word 'Call': [1]
* PASS: 7 Filler: no number, date, organisation name or acronym in bank paragraphs and text blocks outside placeholders. 56 bank paragraphs and all text blocks scanned; none
* PASS: 8 Footer text present on every page. present on all 78 pages
* PASS: 9 No text outside the page area. []
* PASS: 10 Cover, table of contents and key facts are one page each. {'cover': True, 'toc': True, 'key': True}
* PASS: 11 PDF metadata carries the ID and the word synthetic. title=SP05 synthetic test document (synthetic proposal, ID SP05); author=SP05 synthetic document generator (synthetic, no real author); subject=Synthetic document ID SP05, version 1.0, for research purposes only
* PASS: 12 Placements match the pages recorded in the data file. all match
