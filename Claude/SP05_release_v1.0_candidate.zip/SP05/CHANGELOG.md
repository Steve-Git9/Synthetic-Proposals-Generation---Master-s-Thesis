# Changelog

All notable changes to the SP05 synthetic document set. Versions follow the document version printed in the footer.

## 1.0 (build candidate, not frozen)

Date of build: 2026-10-26.

* First release of SP05, the adversarial synthetic project proposal (acronym NIVALIS), 78 pages, born digital.
* Data first build: SP05_data.yaml (seed 20261026) is the only source of values. The PDF is rendered by xelatex from template/main.tex.j2 and template/SP05_text_blocks.yaml, with filler drawn from SP05_paragraph_bank.md (56 paragraphs).
* Injected difficulties: mixed portrait and landscape pages (landscape pages 41 to 43 and 67), eight switches between one and two columns, nested table in Table 1.1, Table 5.1 continued in Annex C 22 pages later, grouped header with changed wording, two line partner rows, merged P4 cell with subcontracting, Finnish and international number formats, thousand scale in Annex C, name variants of P3, similar names P5 and P7, zero funded partner P6, call placeholder, stamp overlapping the submission date, MCRL target only in the radar chart, stated total 2.346 percent above the derived total.
* All 12 verification checks that can run automatically pass (see SP05_check_report.md).
* Landscape pages are typeset by xelatex on a portrait physical page and then cropped and translated to true A4 landscape page boxes with pypdf. Text extraction coordinates are in the landscape frame.
* Added SP05_gold.json (gold set in the ByggMap structure, written from the answer key by SP05_make_gold.py). requested_total_cents is the stated total, not the derived total; the sum of the partner amounts equals the derived total, so the two differ by design. P3 carries its legal name from the consortium list.
* Open: the human steps 8 to 12 in SP05_human_steps.md (fairness check, blind second extraction, realism review, YTJ name check, freeze). Nothing has been frozen. Checksums in SP05_checksums.txt describe this candidate and must be rewritten at freeze.

Any change after the freeze creates a new version and must be recorded here.
