#!/usr/bin/env python3
"""SP05 data generator.

Draws every target value, distractor value and structure with a fixed random
seed and writes SP05_data.yaml. The build never calls this script; it only
reads the stored YAML. Run once, then calibrate the layout (SP05_build.py
--calibrate), then freeze.
"""
import datetime as dt
import random
import sys
from pathlib import Path

import yaml

SEED = 20261026
OUT = Path(__file__).with_name("SP05_data.yaml")
rng = random.Random(SEED)

# ---------------------------------------------------------------- identity
IDENT = {
    "document_id": "SP05",
    "version": "1.0",
    "footer": "Synthetic document for research purposes, ID SP05, version 1.0",
    "acronym": "NIVALIS",
    "title": "Federated Data Spaces for Resilient Cold Climate Infrastructure Monitoring",
    "programme": "Digital Europe Programme",
    "call_identifier": None,
    "call_cover_text": "Call: to be confirmed",
}

# ---------------------------------------------------------------- partners
PARTNERS = {
    "P1": dict(legal="Nordvane Systems Oy", short="Nordvane", acronym="NVS",
               category="company", role="Coordinator", variants=[]),
    "P2": dict(legal="University of Teralund", short="Teralund University", acronym="TLU",
               category="university", role="Partner", variants=[]),
    "P3": dict(legal="Valoria Labs Oy", short="Valoria", acronym="VAL",
               category="company", role="Partner",
               variants=["Valoria Laboratories Ltd", "Valoria Labs Ltd"]),
    "P4": dict(legal="Hallavik Applied Research Centre", short="Hallavik", acronym="HARC",
               category="research organisation", role="Partner", variants=[]),
    "P5": dict(legal="Arctic Sensor Systems Oy", short="Arctic Sensor", acronym="ARSS",
               category="company", role="Partner", variants=[]),
    "P6": dict(legal="Lumivara Edge Oy", short="Lumivara", acronym="LVE",
               category="company", role="Associated partner", variants=[]),
    "P7": dict(legal="Arctic Sensing Solutions Oy", short="Arctic Sensing", acronym="ARSL",
               category="company", role="Partner", variants=[]),
    "P8": dict(legal="Kaltio Regional Council", short="Kaltio Council", acronym="KRC",
               category="public body", role="Partner", variants=[]),
}
# where the P3 variants are used (variant check relies on this)
P3_VARIANT_USE = {
    "work_package_description": "Valoria Laboratories Ltd",
    "gantt_image": "Valoria Laboratories Ltd",
    "signature_page": "Valoria Labs Ltd",
}

# ---------------------------------------------------------------- money
def eur(c):
    return c * 100


def adjust_to_100eur(others_sum, v):
    """Raise v by less than 100 euro so that others_sum + v is a multiple of 100 euro."""
    return v + ((-(others_sum + v)) % 10000)


def round100(c):
    """Round cents to a multiple of 100 euro."""
    return int(round(c / 10000.0)) * 10000


derived_target = rng.uniform(3_650_000, 4_450_000)  # euro
sh = {
    "P1": rng.uniform(0.215, 0.250),
    "P2": rng.uniform(0.170, 0.200),
    "P3": rng.uniform(0.140, 0.165),
    "P4": rng.uniform(0.150, 0.180),
    "P5": rng.uniform(0.115, 0.135),
    "P8": rng.uniform(0.045, 0.060),
}
sh["P7"] = sh["P5"] * rng.uniform(0.62, 0.74)
norm = sum(sh.values())
fund = {}
for k in ("P1", "P2", "P3", "P4"):
    fund[k] = int(round(sh[k] / norm * derived_target * 100))
fund["P5"] = int(round(sh["P5"] / norm * derived_target * 100))
fund["P5"] = adjust_to_100eur(sum(fund[k] for k in ("P1", "P2", "P3", "P4")), fund["P5"])
fund["P6"] = 0
fund["P7"] = round100(sh["P7"] / norm * derived_target * 100)
fund["P8"] = round100(sh["P8"] / norm * derived_target * 100)
derived_total = sum(fund.values())
assert 3_000_000 * 100 <= derived_total <= 5_000_000 * 100

rate_range = {"P1": (0.60, 0.70), "P2": (0.80, 0.90), "P3": (0.60, 0.70), "P4": (0.80, 0.90),
              "P5": (0.60, 0.70), "P7": (0.60, 0.70), "P8": (0.75, 0.85)}
COMP = ("personnel", "equipment", "other", "indirect")
costs = {}
for k in ("P1", "P2", "P3", "P4", "P5", "P7", "P8"):
    rate = rng.uniform(*rate_range[k])
    t0 = fund[k] / rate
    direct = t0 / 1.25
    pers = direct * rng.uniform(0.72, 0.80)
    equip = direct * rng.uniform(0.05, 0.10)
    other = direct - pers - equip
    ind = 0.25 * direct
    costs[k] = dict(personnel=int(round(pers)), equipment=int(round(equip)),
                    other=int(round(other)), indirect=int(round(ind)))
# P5 columns: make the P1..P5 subtotals multiples of 100 euro
for c in COMP:
    s = sum(costs[k][c] for k in ("P1", "P2", "P3", "P4"))
    costs["P5"][c] = adjust_to_100eur(s, costs["P5"][c])
# P7 and P8 on whole 100 euro
for k in ("P7", "P8"):
    for c in COMP:
        costs[k][c] = round100(costs[k][c])
# P6: associated partner, own funded costs, no requested funding, no zero cells
costs["P6"] = {
    "personnel": round100(eur(rng.uniform(120_000, 170_000))),
    "equipment": round100(eur(rng.uniform(9_000, 16_000))),
    "other": round100(eur(rng.uniform(12_000, 24_000))),
    "indirect": 0,
}
costs["P6"]["indirect"] = round100(0.25 * (costs["P6"]["personnel"] + costs["P6"]["equipment"] + costs["P6"]["other"]))
for k in costs:
    costs[k]["total"] = sum(costs[k][c] for c in COMP)
    assert fund[k] <= costs[k]["total"], k
    if k in ("P6", "P7", "P8"):
        assert all(costs[k][c] % 10000 == 0 for c in COMP + ("total",))
        assert fund[k] % 10000 == 0

# P4 subcontracting (smaller amount inside the merged cell), distractor
subcontract_p4 = int(round(fund["P4"] * rng.uniform(0.12, 0.20)))
subcontract_p4 = (subcontract_p4 // 100) * 100  # whole euro

# subtotal P1..P5 (carried forward) per column
carry = {c: sum(costs[k][c] for k in ("P1", "P2", "P3", "P4", "P5")) for c in COMP + ("total",)}
carry["funding"] = sum(fund[k] for k in ("P1", "P2", "P3", "P4", "P5"))
for v in carry.values():
    assert v % 10000 == 0, "carry must be multiple of 100 euro"

total_project_cost = sum(costs[k]["total"] for k in costs)
stated_uplift = rng.uniform(0.012, 0.028)
stated_total = int(round(derived_total * (1 + stated_uplift) / 100.0)) * 100  # whole euro
ratio = stated_total / derived_total
assert 1.01 < ratio < 1.03, ratio
assert total_project_cost > stated_total
own_contribution = total_project_cost - stated_total
assert own_contribution % 100 == 0 and total_project_cost % 100 == 0
p5_p7_diff = abs(fund["P5"] - fund["P7"]) / max(fund["P5"], fund["P7"])
assert p5_p7_diff >= 0.20, p5_p7_diff

# ---------------------------------------------------------------- dates
def weekdays(a, b):
    d = a
    while d <= b:
        if d.weekday() < 5:
            yield d
        d += dt.timedelta(days=1)


cands = list(weekdays(dt.date(2026, 4, 6), dt.date(2026, 9, 18)))
submission = rng.choice(cands)
stamp_date = submission + dt.timedelta(days=rng.randint(2, 5))
sign_date = submission - dt.timedelta(days=rng.randint(2, 6))
version_dates = [submission - dt.timedelta(days=rng.randint(40, 55)),
                 submission - dt.timedelta(days=rng.randint(20, 35)),
                 submission - dt.timedelta(days=rng.randint(8, 15))]
start_date = dt.date(2027, rng.choice([1, 2, 3]), 1)
assert submission not in (stamp_date, sign_date, start_date)

# ---------------------------------------------------------------- readiness
trl_start = rng.choice([3, 4])
trl_target = rng.choice([7, 8])
mcrl_start = rng.choice([2, 3])
mcrl_target = rng.choice([5, 6])
trl_checkpoint = trl_start + 1
mcrl_checkpoint = mcrl_start + 1
trl_other = [v for v in (5, 6, 7) if v not in (trl_start, trl_target, trl_checkpoint)][0]
mcrl_other = [v for v in (4, 5, 6) if v not in (mcrl_start, mcrl_target, mcrl_checkpoint)][0]
assert len({trl_start, trl_target, trl_checkpoint, trl_other}) == 4
assert len({mcrl_start, mcrl_target, mcrl_checkpoint, mcrl_other}) == 4

# ---------------------------------------------------------------- work plan
duration = 36
WPS = [
    dict(id="WP1", title="Project management and coordination", lead="P1", start=1, end=36),
    dict(id="WP2", title="Requirements and reference architecture", lead="P2", start=1, end=12),
    dict(id="WP3", title="Sensor data acquisition layer", lead="P5", start=4, end=24),
    dict(id="WP4", title="Federated analytics services", lead="P3", start=7, end=30),
    dict(id="WP5", title="Pilot operation and validation", lead="P8", start=15, end=34),
    dict(id="WP6", title="Dissemination, exploitation and sustainability", lead="P7", start=1, end=36),
]
TASK_TITLES = {
    "WP1": ["Consortium coordination", "Quality and risk management", "Data management planning", "Reporting and reviews"],
    "WP2": ["Stakeholder requirements", "Reference architecture", "Interface specification"],
    "WP3": ["Sensor integration", "Edge preprocessing", "Data quality monitoring", "Field installation support"],
    "WP4": ["Federated learning service", "Data space connectors", "Anomaly detection models", "Service orchestration"],
    "WP5": ["Pilot preparation", "Pilot operation", "Evaluation and lessons learned"],
    "WP6": ["Communication and outreach", "Exploitation planning", "Standardisation contribution", "Sustainability model"],
}
TASK_LEADS = {
    "WP1": ["P1", "P1", "P4", "P1"], "WP2": ["P2", "P2", "P4"], "WP3": ["P5", "P6", "P5", "P8"],
    "WP4": ["P3", "P4", "P3", "P2"], "WP5": ["P8", "P8", "P2"], "WP6": ["P7", "P7", "P2", "P1"],
}
for wp in WPS:
    titles = TASK_TITLES[wp["id"]]
    n = len(titles)
    span = wp["end"] - wp["start"] + 1
    tasks = []
    for i, ttl in enumerate(titles):
        a = wp["start"] + (span * i) // n
        b = wp["start"] + (span * (i + 1)) // n - 1
        if wp["id"] in ("WP1", "WP6") and i in (0, 1):
            a, b = wp["start"], wp["end"]
        tasks.append(dict(id=f"T{wp['id'][2:]}.{i + 1}", title=ttl, lead=TASK_LEADS[wp["id"]][i],
                          start=max(a, 1), end=min(max(b, a), 36)))
    wp["tasks"] = tasks

person_months = {}
for wp in WPS:
    person_months[wp["id"]] = {}
    for k in PARTNERS:
        if k == "P6":
            pm = rng.randint(0, 3) if wp["id"] in ("WP3", "WP5") else 0
        elif k == wp["lead"]:
            pm = rng.randint(18, 34)
        else:
            pm = rng.randint(2, 14)
        person_months[wp["id"]][k] = pm

DELIVERABLES = [
    ("Project handbook and quality plan", "WP1", "Report", "Public", 3),
    ("Data management plan", "WP1", "Report", "Public", 6),
    ("Stakeholder requirements report", "WP2", "Report", "Public", 6),
    ("Reference architecture specification", "WP2", "Report", "Public", 10),
    ("Interface and connector specification", "WP2", "Report", "Public", 12),
    ("Sensor integration toolkit", "WP3", "Software", "Public", 14),
    ("Edge preprocessing module", "WP3", "Software", "Confidential", 18),
    ("Data quality monitoring service", "WP3", "Software", "Public", 22),
    ("Field installation guide", "WP3", "Report", "Public", 24),
    ("Federated learning service, first release", "WP4", "Software", "Public", 18),
    ("Data space connector library", "WP4", "Software", "Public", 20),
    ("Anomaly detection model package", "WP4", "Software", "Confidential", 26),
    ("Federated analytics services, final release", "WP4", "Software", "Public", 30),
    ("Pilot site preparation report", "WP5", "Report", "Confidential", 18),
    ("Pilot operation dataset", "WP5", "Dataset", "Confidential", 28),
    ("Validation and evaluation report", "WP5", "Report", "Public", 34),
    ("Communication and outreach plan", "WP6", "Report", "Public", 4),
    ("Exploitation strategy", "WP6", "Report", "Confidential", 20),
    ("Standardisation briefing", "WP6", "Report", "Public", 30),
    ("Sustainability and business model report", "WP6", "Report", "Public", 36),
    ("Interim technical report", "WP1", "Report", "Confidential", 18),
    ("Final technical report", "WP1", "Report", "Confidential", 36),
    ("Training material for operators", "WP5", "Report", "Public", 32),
    ("Open data release package", "WP6", "Dataset", "Public", 34),
]
deliverables = []
for i, (ttl, wpid, typ, lvl, mo) in enumerate(DELIVERABLES):
    wp = next(w for w in WPS if w["id"] == wpid)
    idx = sum(1 for d in deliverables if d["wp"] == wpid) + 1
    deliverables.append(dict(id=f"D{wpid[2:]}.{idx}", title=ttl, wp=wpid, type=typ, level=lvl,
                             lead=wp["lead"], month=mo))

RISKS = [
    ("Delay in data access agreements between consortium members", "Medium", "High",
     "Agree a common data sharing template early and review it at every steering committee meeting."),
    ("Sensor hardware delivery delays at pilot sites", "Medium", "Medium",
     "Keep a buffer stock of critical components and qualify a second supplier."),
    ("Insufficient data quality from field installations", "Medium", "High",
     "Introduce automated quality checks at the edge and a clear escalation path for faulty devices."),
    ("Key staff leave a partner organisation", "Low", "Medium",
     "Document the work in shared repositories and nominate deputies for every task lead."),
    ("Federated models underperform on heterogeneous sites", "Medium", "High",
     "Compare several aggregation strategies and keep a local fallback model for each site."),
    ("Interface specifications change late in the work", "Medium", "Medium",
     "Freeze interfaces through a change control board and version every specification."),
    ("Cyber security incident affecting the pilot platform", "Low", "High",
     "Apply a baseline security checklist and run a tabletop exercise before the pilot starts."),
    ("Pilot site access restricted by weather or safety rules", "High", "Medium",
     "Plan flexible pilot windows and use remote diagnostics wherever possible."),
    ("Partner financial or administrative problems", "Low", "High",
     "Monitor budget use quarterly and keep the coordinator informed of liquidity concerns."),
    ("Low stakeholder engagement in requirements work", "Low", "Medium",
     "Use short structured interviews and offer feedback sessions at convenient times."),
    ("Standards evolve and make results incompatible", "Medium", "Medium",
     "Follow relevant standardisation groups and keep adapters modular."),
    ("Exploitation plans diverge between partners", "Medium", "Medium",
     "Hold exploitation workshops and record agreed principles in the consortium agreement."),
    ("Privacy concerns about operational data", "Low", "High",
     "Minimise personal data, apply pseudonymisation and review the approach with the ethics advisor."),
    ("Scheduling conflicts between work packages", "Medium", "Low",
     "Maintain a joint calendar and review dependencies at monthly technical meetings."),
    ("Software integration takes longer than planned", "High", "Medium",
     "Adopt continuous integration, small releases and early integration tests."),
    ("Limited availability of reference data for validation", "Medium", "Medium",
     "Create synthetic reference datasets and agree access to historical records early."),
    ("Communication tools not accepted by all partners", "Low", "Low",
     "Agree a small set of tools in the handbook and provide short onboarding sessions."),
    ("Regulatory changes affecting data sharing", "Low", "Medium",
     "Track regulatory developments and involve legal advisers at planned checkpoints."),
    ("Dependence on a single cloud or hosting provider", "Medium", "Medium",
     "Keep deployments portable and document the steps to move between providers."),
    ("Budget overruns in field installation", "Medium", "Medium",
     "Use fixed price quotations where possible and reserve a contingency in the work plan."),
    ("Delays in ethics approvals for pilot activities", "Low", "Medium",
     "Prepare documentation early and keep regular contact with the competent bodies."),
    ("Results not adopted by infrastructure operators", "Medium", "High",
     "Involve operators from the start and demonstrate benefits using their own data."),
    ("Documentation falls behind development", "Medium", "Low",
     "Make documentation a condition of every release review."),
    ("Disagreement about publication of results", "Low", "Medium",
     "Apply the publication procedure in the consortium agreement and allow short review periods."),
]
risks = []
owner_cycle = ["P1", "P2", "P4", "P8", "P5", "P3", "P7", "P1"]
for i, (desc, lik, imp, mit) in enumerate(RISKS):
    risks.append(dict(id=f"R{i + 1}", description=desc, likelihood=lik, impact=imp, mitigation=mit,
                      owner=owner_cycle[i % len(owner_cycle)], wp=WPS[i % 6]["id"]))

DISSEM = [
    ("Project website and news items", "General public", "Web", "P7"),
    ("Policy brief for regional authorities", "Public bodies", "Briefing", "P8"),
    ("Scientific paper on federated analytics", "Researchers", "Journal", "P2"),
    ("Conference presentation on sensor networks", "Researchers", "Conference", "P4"),
    ("Practitioner webinar on data spaces", "Infrastructure operators", "Webinar", "P3"),
    ("Pilot site open day", "Local stakeholders", "Event", "P8"),
    ("Technical blog posts", "Developers", "Web", "P5"),
    ("Standardisation working group contribution", "Standards bodies", "Meeting", "P1"),
    ("Training workshop for operators", "Infrastructure operators", "Workshop", "P7"),
    ("Open source release announcement", "Developers", "Repository", "P3"),
    ("Newsletter to interested organisations", "Industry", "Email", "P7"),
    ("Joint session with related projects", "Project community", "Event", "P1"),
    ("Final results conference", "All audiences", "Conference", "P1"),
    ("Student thesis topics and guest lectures", "Students", "Teaching", "P2"),
]
dissem = []
months_cycle = [3, 6, 9, 12, 15, 18, 21, 24, 26, 28, 30, 32, 34, 36]
for i, (a, aud, ch, lead) in enumerate(DISSEM):
    dissem.append(dict(activity=a, audience=aud, channel=ch, lead=lead, month=months_cycle[i]))

CHECKLIST = [
    "Interfaces are described in a versioned specification",
    "Every deliverable has a named reviewer from another partner",
    "Data sets have a documented owner and access rule",
    "Software releases pass the agreed integration tests",
    "Pilot procedures are reviewed by site representatives",
    "Security settings are checked before each pilot phase",
    "Sensor calibration records are stored with the data",
    "Model versions are recorded together with training data descriptions",
    "Risks are reviewed at each steering committee meeting",
    "Dissemination material is checked for confidential content",
    "Ethical considerations are reviewed before data collection starts",
    "Meeting decisions are recorded and shared within a short period",
    "Budget use is reported against the work plan",
    "Open source licences are checked before release",
    "Training material is tested with a small group of users",
    "Lessons learned are collected after each pilot period",
    "Exploitation plans are updated at each major review",
    "Documentation is complete before a release is approved",
]
BODIES = [
    ("Steering committee", "P1", 2), ("Technical board", "P2", 4), ("Pilot board", "P8", 4),
    ("Exploitation board", "P7", 2), ("Quality and risk group", "P4", 4),
]
bodies = [dict(name=n, chair=c, meetings_per_year=m) for n, c, m in BODIES]

# ---------------------------------------------------------------- filler sequences
BANK_SIZE = 56
SECTION_KEYS = ["S1", "S2", "S3", "S4", "S5a", "S5c", "S6", "S7", "S8", "A", "B", "C", "E", "G", "F"]
filler_seq = {}
for s in SECTION_KEYS:
    seq = []
    pool = []
    while len(seq) < 700:
        if not pool:
            pool = list(range(BANK_SIZE))
            rng.shuffle(pool)
        seq.append(pool.pop())
    filler_seq[s] = seq

# ---------------------------------------------------------------- layout plan
# order matters; target pages per block; filler counts are written by calibration
BLOCKS = [
    dict(id="cover", pages=1, cols=1, orient="portrait", filler=False),
    dict(id="toc", pages=1, cols=1, orient="portrait", filler=False),
    dict(id="key", pages=1, cols=1, orient="portrait", filler=False),
    dict(id="S1", pages=12, cols=2, orient="portrait", filler=True),
    dict(id="S2", pages=10, cols=1, orient="portrait", filler=True),
    dict(id="S3", pages=10, cols=2, orient="portrait", filler=True),
    dict(id="S4", pages=5, cols=1, orient="portrait", filler=True),
    dict(id="S5a", pages=1, cols=1, orient="landscape", filler=True),
    dict(id="S5t", pages=1, cols=1, orient="landscape", filler=False),
    dict(id="S5c", pages=1, cols=1, orient="landscape", filler=True),
    dict(id="S6", pages=4, cols=1, orient="portrait", filler=True),
    dict(id="S7", pages=3, cols=2, orient="portrait", filler=True),
    dict(id="S8", pages=4, cols=1, orient="portrait", filler=True),
    dict(id="A", pages=5, cols=2, orient="portrait", filler=True),
    dict(id="B", pages=4, cols=1, orient="portrait", filler=True),
    dict(id="C", pages=3, cols=1, orient="portrait", filler=True),
    dict(id="D", pages=1, cols=1, orient="landscape", filler=False),
    dict(id="E", pages=4, cols=1, orient="portrait", filler=True),
    dict(id="F", pages=2, cols=1, orient="portrait", filler=True),
    dict(id="G", pages=3, cols=1, orient="portrait", filler=True),
    dict(id="H", pages=2, cols=1, orient="portrait", filler=False),
]
filler_counts = {b["id"]: (6 if b["filler"] else 0) for b in BLOCKS}
# G (risk register) and F (deliverables) fill with rows, not paragraphs
filler_counts["G"] = 10   # number of risk rows
filler_counts["F"] = 14   # number of deliverable rows

# ---------------------------------------------------------------- distractors (surface strings are built in the build step from these keys)
distractors = [
    dict(id="X01", field="submission_date", kind="date inside stamp image", location="figure", key="stamp_date_fi"),
    dict(id="X02", field="submission_date", kind="ISO date in annex (signature date)", location="text", key="sign_date_iso"),
    dict(id="X03", field="submission_date", kind="ISO date in annex (project start)", location="text", key="start_date_iso"),
    dict(id="X04", field="submission_date", kind="ISO date in annex (version history)", location="text", key="version_dates_iso"),
    dict(id="X05", field="stated_total_requested_amount", kind="total project cost in key facts box", location="text", key="total_project_cost_fi"),
    dict(id="X06", field="stated_total_requested_amount", kind="own contribution in key facts box", location="text", key="own_contribution_fi"),
    dict(id="X07", field="stated_total_requested_amount", kind="carried forward subtotal (requested funding, P1 to P5)", location="table", key="carry_funding_fi"),
    dict(id="X08", field="partner_amount", kind="total costs per partner next to requested funding", location="table", key="total_costs_all"),
    dict(id="X09", field="P4.requested_amount", kind="of which subcontracting inside merged cell", location="table", key="subcontract_p4_fi"),
    dict(id="X10", field="partner_amount", kind="brought forward subtotal in Annex C", location="table", key="carry_funding_k"),
    dict(id="X11", field="trl_start", kind="supporting component readiness mentioned in text", location="text", key="trl_other"),
    dict(id="X12", field="trl_target", kind="mid term checkpoint readiness mentioned in text", location="text", key="trl_checkpoint"),
    dict(id="X13", field="mcrl_start", kind="mid term checkpoint market readiness mentioned in text", location="text", key="mcrl_checkpoint"),
    dict(id="X14", field="mcrl_target", kind="competing approach market readiness mentioned in text", location="text", key="mcrl_other"),
    dict(id="X15", field="partner_name", kind="P3 spelling variant in work package description", location="text", key="p3_var_wp"),
    dict(id="X16", field="partner_name", kind="P3 spelling variant on signature page", location="text", key="p3_var_sig"),
    dict(id="X17", field="partner_name", kind="P3 spelling variant in Gantt chart image", location="figure", key="p3_var_gantt"),
    dict(id="X18", field="partner_name", kind="P5 and P7 short names are similar", location="table", key="p5_p7_short"),
]

data = dict(
    meta=dict(document_id="SP05", version="1.0", seed=SEED, generated_by="SP05_make_data.py",
              note="All values are drawn with the seed. The build reads this file only."),
    identity=IDENT,
    partners={k: dict(v) for k, v in PARTNERS.items()},
    p3_variant_use=P3_VARIANT_USE,
    money_cents=dict(
        funding=fund, costs=costs, carry=carry, subcontract_p4=subcontract_p4,
        derived_total=derived_total, stated_total=stated_total,
        stated_uplift_pct=round((stated_total / derived_total - 1) * 100, 4),
        total_project_cost=total_project_cost, own_contribution=own_contribution,
        p5_p7_relative_difference=round(p5_p7_diff, 4),
    ),
    dates=dict(
        submission=submission.isoformat(), stamp=stamp_date.isoformat(), signature=sign_date.isoformat(),
        project_start=start_date.isoformat(), versions=[d.isoformat() for d in version_dates],
    ),
    readiness=dict(trl_label="TRL", mcrl_label="MCRL", trl_start=trl_start, trl_target=trl_target, mcrl_start=mcrl_start, mcrl_target=mcrl_target,
                   trl_checkpoint=trl_checkpoint, trl_other=trl_other,
                   mcrl_checkpoint=mcrl_checkpoint, mcrl_other=mcrl_other),
    project=dict(duration_months=duration, n_partners=len(PARTNERS), n_wp=len(WPS)),
    work_packages=WPS,
    person_months=person_months,
    deliverables=deliverables,
    risks=risks,
    dissemination=dissem,
    checklist=CHECKLIST,
    bodies=bodies,
    radar=dict(axes=["Customer need", "Value proposition", "Business model", "Competition",
                     "Partnerships", "Regulation", "Go to market"],
               start=[mcrl_start + d for d in (0, 1, 0, -1, 1, 0, 0)],
               target=[mcrl_target + d for d in (0, 0, 0, 0, 0, 0, 0)],
               target_label=f"MCRL {mcrl_target}"),
    layout=dict(blocks=BLOCKS, filler_counts=filler_counts, bank_size=BANK_SIZE, filler_sequences=filler_seq,
                calibrated=False, block_start_pages={}, total_pages=None),
    distractors=distractors,
    placements={},
)

class Dumper(yaml.SafeDumper):
    pass


def _repr_list(dumper, seq):
    flow = all(isinstance(x, (int, float)) for x in seq) and len(seq) > 6
    return dumper.represent_sequence("tag:yaml.org,2002:seq", seq, flow_style=flow)


Dumper.add_representer(list, _repr_list)

if __name__ == "__main__":
    if OUT.exists() and "--force" not in sys.argv:
        print(f"{OUT} exists; use --force to overwrite (this discards calibration).")
        sys.exit(1)
    OUT.write_text(yaml.dump(data, Dumper=Dumper, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
    print("wrote", OUT)
    print("derived total EUR", derived_total / 100, "stated", stated_total / 100,
          "uplift %", round((stated_total / derived_total - 1) * 100, 3))
    print("project cost EUR", total_project_cost / 100, "own", own_contribution / 100)
    print("P5", fund["P5"] / 100, "P7", fund["P7"] / 100, "diff", round(p5_p7_diff, 3))
    print("submission", submission, "stamp", stamp_date, "TRL", trl_start, trl_target, "MCRL", mcrl_start, mcrl_target)
