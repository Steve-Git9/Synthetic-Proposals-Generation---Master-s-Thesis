#!/usr/bin/env python3
"""SP05 chart and graphic generator.

Creates, from SP05_data.yaml and its seed: the radar chart (Figure 4.1), the
RECEIVED stamp, the signature scribbles and the Gantt chart. Text inside the
images is rendered as part of the raster image, never as a text layer.

Usage: SP05_charts.py DATA_YAML OUT_DIR
"""
import datetime as dt
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import yaml
from matplotlib.patches import FancyBboxPatch

PNG_META = {"Software": None}
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["figure.dpi"] = 100


def save(fig, path, **kw):
    fig.savefig(path, metadata=PNG_META, **kw)
    plt.close(fig)


def radar(d, out):
    axes = d["radar"]["axes"]
    start = d["radar"]["start"]
    target = d["radar"]["target"]
    n = len(axes)
    ang = np.linspace(0, 2 * np.pi, n, endpoint=False)
    angc = np.concatenate([ang, ang[:1]])
    fig = plt.figure(figsize=(6.4, 5.6))
    ax = fig.add_subplot(111, polar=True)
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    ax.set_ylim(0, 9)
    ax.set_yticks(range(1, 10))
    ax.set_yticklabels([str(i) for i in range(1, 10)], fontsize=7, color="#555555")
    ax.set_xticks(ang)
    ax.set_xticklabels(axes, fontsize=9)
    ax.grid(color="#bbbbbb", linewidth=0.6)
    tv = np.array(target + target[:1], dtype=float)
    sv = np.array(start + start[:1], dtype=float)
    ax.plot(angc, sv, color="#7a7a7a", linewidth=1.8, linestyle="--", label="Start of project")
    ax.fill(angc, sv, color="#7a7a7a", alpha=0.12)
    ax.plot(angc, tv, color="#1f5a99", linewidth=2.4, label="Target at end of project")
    ax.fill(angc, tv, color="#1f5a99", alpha=0.14)
    ax.set_title("Market readiness profile", fontsize=12, pad=18)
    fig.text(0.5, 0.045, d["radar"]["target_label"] + " target level",
             ha="center", fontsize=11, fontweight="bold", color="#1f5a99")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.05), ncol=2, fontsize=8, frameon=False)
    fig.subplots_adjust(top=0.86, bottom=0.17, left=0.05, right=0.95)
    save(fig, out / "SP05_fig4_1_radar.png", dpi=220)


def fmt_stamp_date(iso):
    y, m, dd = iso.split("-")
    return f"{dd}.{m}.{y}"


def stamp(d, out):
    fig = plt.figure(figsize=(3.4, 1.7))
    fig.patch.set_alpha(0.0)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 3.4)
    ax.set_ylim(0, 1.7)
    ax.axis("off")
    ax.patch.set_alpha(0.0)
    ink = (0.80, 0.10, 0.10)
    alpha = 0.50
    box = FancyBboxPatch((0.12, 0.14), 3.16, 1.42, boxstyle="round,pad=0.0,rounding_size=0.12",
                         fill=False, edgecolor=ink, linewidth=3.2, alpha=alpha)
    ax.add_patch(box)
    ax.text(1.70, 1.07, "RECEIVED", ha="center", va="center", fontsize=25, fontweight="bold", color=ink, alpha=alpha)
    ax.plot([0.35, 3.05], [0.76, 0.76], color=ink, linewidth=1.6, alpha=alpha)
    ax.text(1.70, 0.42, fmt_stamp_date(d["dates"]["stamp"]), ha="center", va="center", fontsize=19,
            fontweight="bold", color=ink, alpha=alpha)
    fig.savefig(out / "SP05_stamp.png", transparent=True, dpi=240, metadata=PNG_META)
    plt.close(fig)


def signatures(d, out):
    import random
    rng = random.Random(d["meta"]["seed"] + 7)
    for k in d["partners"]:
        fig = plt.figure(figsize=(3.0, 1.0))
        fig.patch.set_alpha(0.0)
        ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(0, 3.0)
        ax.set_ylim(0, 1.0)
        ax.axis("off")
        npts = rng.randint(9, 13)
        xs = np.sort(np.array([rng.uniform(0.1, 2.9) for _ in range(npts)]))
        ys = np.array([rng.uniform(0.15, 0.85) for _ in range(npts)])
        t = np.linspace(0, 1, npts)
        tt = np.linspace(0, 1, 400)
        # smooth scribble: cubic interpolation through random points plus loops
        from numpy.polynomial import polynomial as P
        xs2 = np.interp(tt, t, xs)
        ys2 = np.interp(tt, t, ys)
        k1 = np.ones(25) / 25
        xs3 = np.convolve(np.pad(xs2, 12, mode="edge"), k1, mode="valid")
        ys3 = np.convolve(np.pad(ys2, 12, mode="edge"), k1, mode="valid")
        loop = 0.10 * np.sin(tt * rng.uniform(18, 26) * np.pi)
        ax.plot(xs3, ys3 + loop, color="#1a2a6c", linewidth=1.5, solid_capstyle="round")
        ax.plot([0.15, 2.6 + rng.uniform(-0.2, 0.2)], [0.18, 0.12], color="#1a2a6c", linewidth=1.0)
        fig.savefig(out / f"SP05_sig_{k}.png", transparent=True, dpi=200, metadata=PNG_META)
        plt.close(fig)


def gantt(d, out):
    wps = d["work_packages"]
    rows = []
    for wp in wps:
        rows.append(("wp", wp["id"] + "  " + wp["title"], wp["start"], wp["end"], wp["lead"]))
        for t in wp["tasks"]:
            rows.append(("task", t["id"] + "  " + t["title"], t["start"], t["end"], t["lead"]))
    n = len(rows)
    fig, ax = plt.subplots(figsize=(12.6, 7.0))
    colours = ["#1f5a99", "#2e8b57", "#b5651d", "#7b4a9e", "#c0392b", "#5d6d7e"]
    p3 = d["p3_variant_use"]["gantt_image"]
    for i, (kind, label, a, b, lead) in enumerate(rows):
        y = n - 1 - i
        wi = int(label[2]) - 1 if label.startswith("WP") else int(label[1]) - 1
        c = colours[wi % len(colours)]
        if kind == "wp":
            ax.barh(y, b - a + 1, left=a - 1, height=0.62, color=c, alpha=0.95)
        else:
            ax.barh(y, b - a + 1, left=a - 1, height=0.42, color=c, alpha=0.55)
        name = p3 if lead == "P3" else d["partners"][lead]["legal"]
        xpos = min(b, 36) + 0.4
        if a <= 2 and b >= 34:
            ax.text((a - 1 + b) / 2.0, y, name, ha="center", va="center", fontsize=6.6,
                    color="#111111" if kind == "task" else "white")
        elif b >= 28:
            ax.text(a - 1 - 0.4, y, name, ha="right", va="center", fontsize=6.6, color="#333333")
        else:
            ax.text(xpos, y, name, ha="left", va="center", fontsize=6.6, color="#333333")
    ax.set_yticks(range(n))
    ax.set_yticklabels([r[1] for r in rows][::-1], fontsize=7.4)
    for lab in ax.get_yticklabels():
        if lab.get_text().startswith("WP"):
            lab.set_fontweight("bold")
    ax.set_xlim(0, 36)
    ax.set_xticks(range(0, 37, 3))
    ax.set_xlabel("Project month", fontsize=9)
    ax.grid(axis="x", color="#cccccc", linewidth=0.5)
    ax.set_axisbelow(True)
    ax.set_title("Work plan timeline with task leads", fontsize=12)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    save(fig, out / "SP05_gantt.png", dpi=200)


def main():
    data_path, out_dir = Path(sys.argv[1]), Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    d = yaml.safe_load(data_path.read_text(encoding="utf-8"))
    radar(d, out_dir)
    stamp(d, out_dir)
    signatures(d, out_dir)
    gantt(d, out_dir)
    print("charts written to", out_dir)


if __name__ == "__main__":
    main()
