# SP05 human steps (open)

Nothing in this file has been done. Each step needs a person. The automatic checks are in SP05_check_report.md.

## Step 8. Fairness check

A person confirms that every target value can be found and read by a careful human reader. Page numbers are physical page numbers of SP05.pdf. Tick each line.

| Done | Field | Where to look | Location type |
|---|---|---|---|
| [ ] | proposal_acronym | page 1 | text |
| [ ] | proposal_title | page 1 | text |
| [ ] | call_identifier | page 1, placeholder only; confirm no identifier appears anywhere else | text |
| [ ] | funding_programme | page 1 | text |
| [ ] | submission_date | page 1, cover, next to the stamp (check the date is readable where the stamp overlaps it) | text |
| [ ] | stated_total_requested_amount | page 3 | text |
| [ ] | trl_start | page 9, Table 1.1, nested table, technology readiness row | nested table |
| [ ] | trl_target | page 11 | text |
| [ ] | mcrl_start | page 37 | text |
| [ ] | mcrl_target | page 38, Figure 4.1 (the radar chart), check the label and the scale are legible | figure |
| [ ] | partner.P1.name | page 16 | table |
| [ ] | partner.P1.requested_amount | page 42 | table |
| [ ] | partner.P2.name | page 16 | table |
| [ ] | partner.P2.requested_amount | page 42 | table |
| [ ] | partner.P3.name | page 16 | table |
| [ ] | partner.P3.requested_amount | page 42 | table |
| [ ] | partner.P4.name | page 16 | table |
| [ ] | partner.P4.requested_amount | page 42, merged cell, first amount only | table |
| [ ] | partner.P5.name | page 16 | table |
| [ ] | partner.P5.requested_amount | page 42 | table |
| [ ] | partner.P6.name | page 16 | table |
| [ ] | partner.P6.requested_amount | page 64, Annex C, values in EUR thousand | table |
| [ ] | partner.P7.name | page 16 | table |
| [ ] | partner.P7.requested_amount | page 64, Annex C, values in EUR thousand | table |
| [ ] | partner.P8.name | page 16 | table |
| [ ] | partner.P8.requested_amount | page 64, Annex C, values in EUR thousand | table |

Also confirm: the landscape pages 41 to 43 can be read without strain, and the Gantt chart on page 67 is legible. Any value a human cannot read must be made legible and the document rebuilt as a new version.

## Step 9. Blind second extraction

A second person fills in the form below from SP05.pdf without seeing SP05_answer_key.json. Compare with the key. Every disagreement leads to a fix of the design or the key until agreement is complete. Record the initial agreement rate here: ______ of ______ fields.

| Field | Value extracted by the second person | Page | Notes |
|---|---|---|---|
| Proposal acronym | | | |
| Proposal title | | | |
| Call identifier | | | |
| Funding programme | | | |
| Submission date (ISO) | | | |
| Stated total requested amount (euro cents) | | | |
| TRL start | | | |
| TRL target | | | |
| MCRL start | | | |
| MCRL target | | | |
| Partner P1: name as written in the consortium list | | | |
| Partner P1: requested amount (euro cents) | | | |
| Partner P2: name as written in the consortium list | | | |
| Partner P2: requested amount (euro cents) | | | |
| Partner P3: name as written in the consortium list | | | |
| Partner P3: requested amount (euro cents) | | | |
| Partner P4: name as written in the consortium list | | | |
| Partner P4: requested amount (euro cents) | | | |
| Partner P5: name as written in the consortium list | | | |
| Partner P5: requested amount (euro cents) | | | |
| Partner P6: name as written in the consortium list | | | |
| Partner P6: requested amount (euro cents) | | | |
| Partner P7: name as written in the consortium list | | | |
| Partner P7: requested amount (euro cents) | | | |
| Partner P8: name as written in the consortium list | | | |
| Partner P8: requested amount (euro cents) | | | |
| Derived total (sum of the partner amounts, euro cents) | | | |
| Stated total matches the sum of partners (yes or no) | | | |

## Step 10. Realism review

A person familiar with real proposals answers yes or no for each item and adds comments. The document only has to look plausible to a reader skimming it.

* [ ] The cover looks like a plausible proposal cover.
* [ ] The table of contents and the section structure look plausible.
* [ ] The key facts box looks plausible.
* [ ] The consortium list and the roles look plausible.
* [ ] The work plan, tasks and deliverables look plausible.
* [ ] The budget table layout looks like budget tables in real proposals.
* [ ] The landscape budget pages and the table continued in an annex look plausible.
* [ ] The annexes (Gantt chart, work package tables, deliverables, risk register, signature page) look plausible.
* [ ] The filler text reads like neutral proposal prose and contains nothing that looks like a real fact.
* [ ] Anything that makes the document look obviously artificial (apart from the footer) is noted below.

Comments: ______________________________

## Step 11. Name check (YTJ and web search)

Check every name below against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced, and the document rebuilt as a new version. Record the result per line.

| Done | Name | Kind | YTJ result | Web search result |
|---|---|---|---|---|
| [ ] | NIVALIS | proposal acronym | | |
| [ ] | Federated Data Spaces for Resilient Cold Climate Infrastructure Monitoring | proposal title | | |
| [ ] | Nordvane Systems Oy | P1 legal name | | |
| [ ] | Nordvane | P1 short name | | |
| [ ] | NVS | P1 acronym | | |
| [ ] | University of Teralund | P2 legal name | | |
| [ ] | Teralund University | P2 short name | | |
| [ ] | TLU | P2 acronym | | |
| [ ] | Valoria Labs Oy | P3 legal name | | |
| [ ] | Valoria | P3 short name | | |
| [ ] | VAL | P3 acronym | | |
| [ ] | Valoria Laboratories Ltd | P3 spelling variant | | |
| [ ] | Valoria Labs Ltd | P3 spelling variant | | |
| [ ] | Hallavik Applied Research Centre | P4 legal name | | |
| [ ] | Hallavik | P4 short name | | |
| [ ] | HARC | P4 acronym | | |
| [ ] | Arctic Sensor Systems Oy | P5 legal name | | |
| [ ] | Arctic Sensor | P5 short name | | |
| [ ] | ARSS | P5 acronym | | |
| [ ] | Lumivara Edge Oy | P6 legal name | | |
| [ ] | Lumivara | P6 short name | | |
| [ ] | LVE | P6 acronym | | |
| [ ] | Arctic Sensing Solutions Oy | P7 legal name | | |
| [ ] | Arctic Sensing | P7 short name | | |
| [ ] | ARSL | P7 acronym | | |
| [ ] | Kaltio Regional Council | P8 legal name | | |
| [ ] | Kaltio Council | P8 short name | | |
| [ ] | KRC | P8 acronym | | |

Also check: the names of the management bodies and the project title are not real project names.

## Step 12. Freeze

Not done. After all automatic and human checks pass: tag version 1.0, regenerate SP05_checksums.txt, and do not edit the files again. The document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.

