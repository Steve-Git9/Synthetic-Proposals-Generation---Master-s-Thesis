#!/usr/bin/env python3
"""SP05 answer key, manifest, register and automatic verification checks.

Reads SP05.pdf and SP05_data.yaml. Writes SP05_answer_key.json, SP05_manifest.csv,
SP05_partner_register.csv, SP05_human_steps.md, SP05_check_report.md/json.
"""
import csv
import hashlib
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path

import pdfplumber
import yaml

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "SP05_data.yaml"
PDF = ROOT / "SP05.pdf"
XTOL = 1.5
NUM_FI = re.compile(r"(\d{1,3}(?: \d{3})*,\d{2}) €")
NUM_K = re.compile(r"^\d{1,3}(?:,\d{3})*\.\d$")


# ------------------------------------------------------------------ formatting (plain text, as seen in the text layer)
def fi_p(c):
    euros, cents = divmod(int(c), 100)
    return f"{euros:,}".replace(",", " ") + f",{cents:02d} €"


def intl_p(c):
    euros, cents = divmod(int(c), 100)
    return f"EUR {euros:,}.{cents:02d}"


def kf_p(c):
    t = int(c) // 10000
    return f"{t // 10:,}.{t % 10}"


def dfi(iso):
    y, m, d = iso.split("-")
    return f"{d}.{m}.{y}"


def parse_fi(s):
    m = NUM_FI.search(s)
    if not m:
        return None
    a, b = m.group(1).replace(" ", "").split(",")
    return int(a) * 100 + int(b)


# ------------------------------------------------------------------ PDF access
class Pdf:
    def __init__(self, path):
        self.pdf = pdfplumber.open(str(path))
        self.n = len(self.pdf.pages)
        self._words = {}

    def page(self, i):
        return self.pdf.pages[i - 1]

    def words(self, i):
        if i not in self._words:
            self._words[i] = self.page(i).extract_words(use_text_flow=True, x_tolerance=XTOL, y_tolerance=3)
        return self._words[i]

    def sorted_words(self, i):
        return self.page(i).extract_words(x_tolerance=XTOL, y_tolerance=3)

    def find(self, surface, pages=None):
        toks = surface.split()
        res = []
        for pg in (pages or range(1, self.n + 1)):
            ws = self.words(pg)
            txt = [w["text"].rstrip(".,;:") if j < len(ws) else w["text"] for j, w in enumerate(ws)]
            for i in range(len(ws) - len(toks) + 1):
                ok = True
                for j, t in enumerate(toks):
                    if txt[i + j] != t and ws[i + j]["text"] != t:
                        ok = False
                        break
                if ok:
                    seg = ws[i:i + len(toks)]
                    res.append(dict(page=pg, bbox=[round(min(w["x0"] for w in seg), 2), round(min(w["top"] for w in seg), 2),
                                                   round(max(w["x1"] for w in seg), 2), round(max(w["bottom"] for w in seg), 2)]))
        return res

    def text_in(self, pg, bbox, pad=0.6):
        p = self.page(pg)
        x0, t, x1, b = bbox
        box = (max(x0 - pad, 0), max(t - pad, 0), min(x1 + pad, p.width), min(b + pad, p.height))
        ws = p.crop(box).extract_words(x_tolerance=XTOL, y_tolerance=3)
        return " ".join(w["text"] for w in ws)

    def images(self, pg):
        return [dict(bbox=[round(i["x0"], 2), round(i["top"], 2), round(i["x1"], 2), round(i["bottom"], 2)]) for i in self.page(pg).images]


def norm(s):
    return re.sub(r"\s+", "", s)


# ------------------------------------------------------------------ prose check (filler and text blocks)
MONTHS = "january february march april may june july august september october november december".split()
NUMWORDS = "one two three four five six seven eight nine ten eleven twelve hundred thousand million".split()
ALLOWED_CAPS = {"I", "English", "European", "Gantt"}


def prose_violations(text, banned):
    """Return a list of violations found in text outside placeholders."""
    text = re.sub(r"\{\{.*?\}\}", " ", text)
    text = re.sub(r"\b(Table|Figure|Annex|Section)\s+[A-Z]?\d*(\.\d+)*\b", " ", text)
    v = []
    if re.search(r"\d", text):
        v.append("digit")
    low = text.lower()
    for m in MONTHS:
        if re.search(rf"\b{m.capitalize()}\b", text):
            v.append(f"month name {m}")
    for w in NUMWORDS:
        if re.search(rf"\b{w}\b", low):
            v.append(f"number word {w}")
    for t in re.findall(r"\b[A-Z]{2,}\b", text):
        v.append(f"acronym-like token {t}")
    for b in banned:
        if re.search(rf"(?<![A-Za-z]){re.escape(b)}(?![A-Za-z])", text):
            v.append(f"organisation name {b}")
    # capitalised word that is not at sentence start
    for m in re.finditer(r"(?<![.!?]\s)(?<!^)\b([A-Z][a-z]+)\b", text):
        w = m.group(1)
        if w not in ALLOWED_CAPS and not re.search(r"(?:^|[.!?:]\s+|\n)" + w, text[max(0, m.start() - 3):m.end()]):
            v.append(f"capitalised word {w}")
    return v


def run_prose_check(d):
    import SP05_build as B
    banned = set()
    for k, p in d["partners"].items():
        banned.update([p["legal"], p["short"], p["acronym"]] + p["variants"])
    banned.update(["CLIC", "Digital Europe", d["identity"]["acronym"]])
    res = []
    bank = B.load_bank()
    for bid, txt in bank:
        for x in prose_violations(txt, banned):
            res.append(f"bank {bid}: {x}")
    tbs = yaml.safe_load((B.TEMPLATE_DIR / "SP05_text_blocks.yaml").read_text(encoding="utf-8"))

    def walk(node, path):
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, path + [k])
        else:
            for x in prose_violations(node, banned):
                res.append(f"text block {'.'.join(path)}: {x}")
            # every placeholder must resolve to the data file
            for ph in re.findall(r"\{\{\s*(.*?)\s*\}\}", node):
                if not re.match(r"^(p|f|r|d|var)\.", ph):
                    res.append(f"text block {'.'.join(path)}: unknown placeholder {ph}")
    walk(tbs, [])
    return res, len(bank)


# ------------------------------------------------------------------ main logic
def run():
    d = yaml.safe_load(DATA.read_text(encoding="utf-8"))
    starts = yaml.safe_load((ROOT / "build_out" / "starts.yaml").read_text())
    st = starts["starts"]
    land = set(starts["landscape"])
    P = Pdf(PDF)
    m = d["money_cents"]
    pids = list(d["partners"].keys())
    ident = d["identity"]
    rd = d["readiness"]
    checks = []

    def chk(name, ok, detail=""):
        checks.append(dict(name=name, ok=bool(ok), detail=detail))

    blocks = {b["id"]: b for b in d["layout"]["blocks"]}
    order = [b["id"] for b in d["layout"]["blocks"]]

    def pages_of(bid):
        i = order.index(bid)
        nxt = st[order[i + 1]] if i + 1 < len(order) else starts["total"] + 1
        return list(range(st[bid], nxt))

    # ---------------------------------------------------------- locate target values
    targets = []

    def add(field, value, loc_type, surface, pages, authority, pick=None, image=False, extra=None):
        if image:
            pg = pages[0]
            imgs = P.images(pg)
            bb = pick(imgs) if pick else imgs[0]["bbox"]
            targets.append(dict(field=field, value=value, page=pg, bbox=bb, location_type=loc_type,
                                surface_string=surface, authority_rule=authority, text_layer_present=False,
                                additional_locations=[], distractors=[]))
            return targets[-1]
        occ = P.find(surface, pages)
        if pick:
            occ = pick(occ)
        n_all = len(P.find(surface))
        t = dict(field=field, value=value, page=occ[0]["page"] if occ else None, bbox=occ[0]["bbox"] if occ else None,
                 location_type=loc_type, surface_string=surface, authority_rule=authority, text_layer_present=bool(occ),
                 additional_locations=[], distractors=[], occurrences_in_document=n_all)
        if extra:
            t.update(extra)
        targets.append(t)
        return t

    R_ACR = "The proposal acronym is the large printed text on the cover."
    add("proposal_acronym", ident["acronym"], "text", ident["acronym"], [1], R_ACR)
    add("proposal_title", ident["title"], "text", ident["title"], [1], "The proposal title is the printed title on the cover.")
    t = add("call_identifier", None, "text", ident["call_cover_text"], [1],
            "The call identifier is null. The cover only carries a placeholder; no identifier appears anywhere in the document.")
    t["note"] = "Value is null. The bounding box is that of the placeholder text, which is not an identifier."
    add("funding_programme", ident["programme"], "text", ident["programme"], [1], "The funding programme is the printed programme name on the cover.")
    sub_fi = dfi(d["dates"]["submission"])
    add("submission_date", d["dates"]["submission"], "text", sub_fi, [1],
        "The submission date is the printed text on the cover, not the date inside the stamp.")
    stated_fi = fi_p(m["stated_total"])
    stated_intl = intl_p(m["stated_total"])
    t = add("stated_total_requested_amount", m["stated_total"], "text", stated_fi, [st["key"]],
            "The key facts box and section 5.2 are authoritative for the stated total. The derived total is never substituted.")
    occ2 = P.find(stated_intl)
    t["additional_locations"] = [dict(page=o["page"], bbox=o["bbox"], surface_string=stated_intl,
                                      location_type="text", note="Section 5.2, international number format") for o in occ2]
    add("trl_start", rd["trl_start"], "nested table", f"TRL {rd['trl_start']}", pages_of("S1"),
        "The TRL start value is in the nested table of Table 1.1, technology readiness row.")
    add("trl_target", rd["trl_target"], "text", f"TRL {rd['trl_target']}", pages_of("S1"),
        "The TRL target is stated in the text of section 1.5.")
    add("mcrl_start", rd["mcrl_start"], "text", f"MCRL {rd['mcrl_start']}", pages_of("S4"),
        "The MCRL start is stated in the text of section 4.2.")
    s4 = pages_of("S4")
    rad_pg = [pg for pg in s4 if P.images(pg)]
    add("mcrl_target", rd["mcrl_target"], "figure", d["radar"]["target_label"], rad_pg or s4,
        "The MCRL target appears only inside the radar chart (Figure 4.1). The surface string is rendered inside the image.",
        image=True)

    # partners
    part_pages_list = pages_of("S2")
    partner_entries = {}
    for k in pids:
        p = d["partners"][k]
        tn = add(f"partner.{k}.name", p["legal"], "table", p["legal"], part_pages_list,
                 "The partner name is the legal name from the consortium list (section 2.1). Spelling variants are aliases.")
        if k in ("P1", "P2", "P3", "P4", "P5"):
            surf = fi_p(m["funding"][k])
            ta = add(f"partner.{k}.requested_amount", m["funding"][k], "table", surf, [st["S5t"]],
                     "Table 5.1 is authoritative for partner amounts. Carried forward rows are never partner amounts."
                     + (" For P4 only the first amount in the merged cell counts; the subcontracting amount never does." if k == "P4" else ""))
        else:
            surf = kf_p(m["funding"][k])
            pg = st["C"]

            def pick_row(occ, k=k, pg=pg):
                short = d["partners"][k]["short"].split()[0]
                nm = [w for w in P.sorted_words(pg) if w["text"] == short]
                if not nm:
                    return occ
                top = nm[0]["top"]
                cand = [o for o in occ if abs(o["bbox"][1] - top) < 4]
                cand.sort(key=lambda o: -o["bbox"][0])
                return cand[:1]

            ta = add(f"partner.{k}.requested_amount", m["funding"][k], "table", surf, pages_of("C"),
                     "Table 5.1 continued (Annex C) is authoritative for partner amounts; values are in EUR thousand, so the answer key holds the full euro cents.",
                     pick=pick_row)
        partner_entries[k] = (tn, ta)

    # ---------------------------------------------------------- distractors
    def occ_list(surface, pages=None):
        return [dict(page=o["page"], bbox=o["bbox"], surface_string=surface) for o in P.find(surface, pages)]

    dis_by_key = {}
    dd = d["dates"]
    stamp_surface = dfi(dd["stamp"])
    stamp_img = P.images(1)[0]["bbox"] if P.images(1) else None
    dis_by_key["stamp_date_fi"] = [dict(page=1, bbox=stamp_img, surface_string=stamp_surface, location_type="figure")]
    dis_by_key["sign_date_iso"] = occ_list(dd["signature"])
    dis_by_key["start_date_iso"] = occ_list(dd["project_start"])
    dis_by_key["version_dates_iso"] = sum([occ_list(x) for x in dd["versions"]], [])
    dis_by_key["total_project_cost_fi"] = occ_list(fi_p(m["total_project_cost"]), [st["key"]])
    dis_by_key["own_contribution_fi"] = occ_list(fi_p(m["own_contribution"]), [st["key"]])
    dis_by_key["carry_funding_fi"] = occ_list(fi_p(m["carry"]["funding"]), [st["S5t"]])
    dis_by_key["carry_funding_k"] = occ_list(kf_p(m["carry"]["funding"]), pages_of("C"))
    tc = []
    for k in pids:
        if k in ("P1", "P2", "P3", "P4", "P5"):
            tc += occ_list(fi_p(m["costs"][k]["total"]), [st["S5t"]])
        else:
            tc += occ_list(kf_p(m["costs"][k]["total"]), pages_of("C"))
    dis_by_key["total_costs_all"] = tc
    dis_by_key["subcontract_p4_fi"] = occ_list(fi_p(m["subcontract_p4"]), [st["S5t"]])
    dis_by_key["trl_other"] = occ_list(f"TRL {rd['trl_other']}")
    dis_by_key["trl_checkpoint"] = occ_list(f"TRL {rd['trl_checkpoint']}")
    dis_by_key["mcrl_checkpoint"] = occ_list(f"MCRL {rd['mcrl_checkpoint']}")
    dis_by_key["mcrl_other"] = occ_list(f"MCRL {rd['mcrl_other']}")
    v = d["p3_variant_use"]
    dis_by_key["p3_var_wp"] = occ_list(v["work_package_description"])
    dis_by_key["p3_var_sig"] = occ_list(v["signature_page"], pages_of("H"))
    dgp = pages_of("D")[0]
    dis_by_key["p3_var_gantt"] = [dict(page=dgp, bbox=(P.images(dgp)[0]["bbox"] if P.images(dgp) else None),
                                       surface_string=v["gantt_image"], location_type="figure")]
    dis_by_key["p5_p7_short"] = occ_list(d["partners"]["P5"]["short"], [st["S5t"]]) + \
        occ_list(d["partners"]["P7"]["short"], pages_of("C"))

    dis_records = []
    for x in d["distractors"]:
        recs = dis_by_key.get(x["key"], [])
        for r in recs:
            r = dict(r)
            r["id"] = x["id"]
            r["kind"] = x["kind"]
            r.setdefault("location_type", x["location"])
            dis_records.append((x, r))
    for t in targets:
        f = t["field"]
        for x, r in dis_records:
            fld = x["field"]
            hit = False
            if fld == f:
                hit = True
            elif fld == "partner_amount" and re.match(r"partner\.P\d\.requested_amount", f):
                hit = True
            elif fld == "P4.requested_amount" and f == "partner.P4.requested_amount":
                hit = True
            elif fld == "partner_name" and re.match(r"partner\.P\d\.name", f):
                if x["id"] in ("X15", "X16", "X17"):
                    hit = f == "partner.P3.name"
                elif x["id"] == "X18":
                    hit = f in ("partner.P5.name", "partner.P7.name")
            if hit:
                # a distractor must not be the target value itself
                if r["surface_string"] == t["surface_string"]:
                    continue
                t["distractors"].append(dict(id=r["id"], kind=r["kind"], page=r["page"], bbox=r["bbox"],
                                             surface_string=r["surface_string"], location_type=r["location_type"]))

    # ---------------------------------------------------------- checks
    # 1 text layer check
    miss = [t["field"] for t in targets if t["text_layer_present"] is False and t["location_type"] != "figure"]
    miss += [t["field"] for t in targets if t["location_type"] != "figure" and t["page"] is None]
    chk("1 Text layer: every text or table target found on its page", not miss, f"missing: {miss}" if miss else
        f"{sum(1 for t in targets if t['location_type'] != 'figure')} text and table targets found")
    amb = {t["field"]: t.get("occurrences_in_document") for t in targets
           if t["location_type"] != "figure" and t["field"] not in ("call_identifier",) and (t.get("occurrences_in_document") or 0) != 1
           and not t["field"].endswith(".name") and t["field"] != "stated_total_requested_amount"}
    chk("1b Text layer: target surface strings are unique in the document (apart from partner names and the stated total)",
        not amb, f"non unique: {amb}" if amb else "all unique")
    # 2 image value check
    txt_all = " ".join(" ".join(w["text"] for w in P.sorted_words(i)) for i in range(1, P.n + 1))
    mcrl_label = f"MCRL {rd['mcrl_target']}"
    chk("2a Image value: MCRL target not in text layer", mcrl_label not in txt_all, mcrl_label)
    chk("2b Image value: stamp date not in text layer", stamp_surface not in txt_all, stamp_surface)
    chk("2c Image value: bounding boxes of the radar chart and the stamp exist",
        all(t["bbox"] for t in targets if t["location_type"] == "figure") and stamp_img is not None)
    # 3 bounding box check
    bad = []
    for t in targets:
        if t["location_type"] == "figure" or t["bbox"] is None:
            continue
        got = norm(P.text_in(t["page"], t["bbox"]))
        if norm(t["surface_string"]).rstrip(".,;:") not in got:
            bad.append((t["field"], t["surface_string"], got[:60]))
    chk("3 Bounding box: each text layer bbox contains its surface string", not bad, str(bad) if bad else "all contain")
    # 4 page count and placement
    chk("4a Page count between 70 and 80", 70 <= P.n <= 80, f"{P.n} pages")
    s5p = pages_of("S5a") + pages_of("S5t") + pages_of("S5c")
    land_ok = all(P.page(i).width > P.page(i).height for i in s5p)
    chk("4b Pages of Section 5 (Table 5.1 part 1) are landscape", land_ok, f"pages {s5p}")
    land_all = [i for i in range(1, P.n + 1) if P.page(i).width > P.page(i).height]
    chk("4b2 Landscape pages as planned", set(land_all) == land, f"landscape pages {land_all}")
    last_t51 = st["S5t"]
    chk("4c Annex C starts at least twenty pages after the last page of Table 5.1 part 1", st["C"] - last_t51 >= 20,
        f"part 1 on page {last_t51}, Annex C starts on page {st['C']}, gap {st['C'] - last_t51}")
    # column analysis
    colseq = []
    for i in range(1, P.n + 1):
        pg = P.page(i)
        if pg.width > pg.height:
            colseq.append("L")
            continue
        ws = P.sorted_words(i)
        body = [w for w in ws if 60 < w["top"] < 760]
        if len(body) < 30:
            colseq.append("x")
            continue
        mid = pg.width / 2
        cross = sum(1 for w in body if w["x0"] < mid + 6 and w["x1"] > mid - 6)
        left = sum(1 for w in body if w["x1"] <= mid - 6)
        right = sum(1 for w in body if w["x0"] >= mid + 6)
        if left > 0.3 * len(body) and right > 0.3 * len(body) and cross < 0.02 * len(body):
            colseq.append("2")
        else:
            colseq.append("1")
    runs = []
    for i, c in enumerate(colseq, start=1):
        if c in ("1", "2"):
            if runs and runs[-1][0] == c:
                runs[-1][2] = i
            else:
                runs.append([c, i, i])
    switches = len(runs) - 1
    chk("4d Layout switches between one and two columns at least four times", switches >= 4,
        f"{switches} switches; runs " + ", ".join(f"{'two' if r[0] == '2' else 'one'} column pages {r[1]} to {r[2]}" for r in runs))
    # 5 consistency
    parsed = {}
    for k in pids:
        ta = partner_entries[k][1]
        txt = P.text_in(ta["page"], ta["bbox"])
        if k in ("P1", "P2", "P3", "P4", "P5"):
            parsed[k] = parse_fi(txt)
        else:
            tokens = txt.split()
            val = None
            for tk in tokens:
                if NUM_K.match(tk):
                    val = int(round(float(tk.replace(",", "")) * 100000))
            parsed[k] = val
    derived_pdf = sum(v for v in parsed.values() if v is not None)
    chk("5a Partner amounts parsed back from the PDF equal the data file",
        all(parsed[k] == m["funding"][k] for k in pids), str(parsed))
    # carried forward and brought forward rows
    cf_words = [w for w in P.sorted_words(st["S5t"]) if w["text"] == "Carried"]
    carry_ok = False
    cf_vals = []
    if cf_words:
        top = cf_words[0]["top"]
        line = " ".join(w["text"] for w in P.sorted_words(st["S5t"]) if abs(w["top"] - top) < 4)
        cf_vals = [parse_fi(x + " €") for x in NUM_FI.findall(line)]
        # numeric table rows: lines with >= 5 numbers
        rows = {}
        for w in P.sorted_words(st["S5t"]):
            rows.setdefault(round(w["top"] / 3), []).append(w)
        numlines = []
        for key in sorted(rows):
            ln = " ".join(w["text"] for w in sorted(rows[key], key=lambda w: w["x0"]))
            nums = NUM_FI.findall(ln)
            if len(nums) >= 5 and "Carried" not in ln:
                numlines.append([parse_fi(x + " €") for x in nums])
        cols5 = [sum(r[i] for r in numlines[:5]) for i in range(5)]
        funding_sum = sum(parsed[k] for k in ("P1", "P2", "P3", "P4", "P5"))
        carry_ok = len(cf_vals) == 6 and cf_vals[:5] == cols5 and cf_vals[5] == funding_sum
    chk("5b Carried forward row equals the sum of P1 to P5 (all columns)", carry_ok, f"carried forward row {cf_vals}")
    bf_words = [w for w in P.sorted_words(st["C"]) if w["text"] == "Brought"]
    bf_ok = False
    bf_vals = []
    if bf_words:
        top = bf_words[0]["top"]
        line = [w["text"] for w in P.sorted_words(st["C"]) if abs(w["top"] - top) < 4]
        bf_vals = [float(x.replace(",", "")) for x in line if NUM_K.match(x)]
        bf_ok = len(bf_vals) == 6 and all(abs(a * 1000 - b / 100.0) < 50.01 for a, b in zip(
            bf_vals, [m["carry"][c] for c in ("personnel", "equipment", "other", "indirect", "total", "funding")]))
        bf_ok = bf_ok and cf_vals and all(abs(a * 1000 - b / 100.0) < 50.01 for a, b in zip(bf_vals, cf_vals))
    chk("5c Brought forward row equals the carried forward row", bf_ok, f"brought forward row {bf_vals}")
    ratio = m["stated_total"] / derived_pdf
    chk("5d Stated total is between 1% and 3% higher than the derived total", 1.01 <= ratio <= 1.03,
        f"stated {m['stated_total'] / 100:.2f}, derived {derived_pdf / 100:.2f}, stated is {100 * (ratio - 1):.3f}% higher")
    p5, p7 = parsed["P5"], parsed["P7"]
    chk("5e Amounts of P5 and P7 differ by at least 20%", abs(p5 - p7) / max(p5, p7) >= 0.20,
        f"P5 {p5 / 100:.2f}, P7 {p7 / 100:.2f}, difference {100 * abs(p5 - p7) / max(p5, p7):.1f}% of the larger")
    chk("5f Total project cost is higher than the stated total", m["total_project_cost"] > m["stated_total"])
    chk("5g Derived total between 3,000,000 and 5,000,000 euro", 300000000 <= derived_pdf <= 500000000, f"{derived_pdf / 100:.2f}")
    chk("5h Data file derived total equals sum of partner amounts", m["derived_total"] == sum(m["funding"].values()))
    # 6 variant check
    var_bad = []
    for variant in d["partners"]["P3"]["variants"]:
        for pg in pages_of("S2") + [st["S5t"]] + pages_of("C"):
            if P.find(variant, [pg]):
                var_bad.append((variant, pg))
    chk("6a P3 spelling variants never appear in the consortium list or in Table 5.1", not var_bad, str(var_bad))
    var_found = {x: [o["page"] for o in P.find(x)] for x in d["partners"]["P3"]["variants"]}
    chk("6b P3 variants appear in a work package description and on the signature page", bool(var_found.get(v["work_package_description"])) and bool(P.find(v["signature_page"], pages_of("H"))), str(var_found))
    pat = [r"\b[A-Z][A-Z0-9]{2,}(?:-[A-Z0-9]+){2,}\b", r"\bDIGITAL[-_ ]", r"\bHORIZON[-_ ]", r"(?i)\bcall (id|identifier|number|reference)\b",
           r"(?i)\btopic (id|identifier)\b"]
    hits = []
    for pt in pat:
        for mm in re.finditer(pt, txt_all):
            hits.append(mm.group(0))
    calls = [i for i in range(1, P.n + 1) if re.search(r"\bCall\b", " ".join(w["text"] for w in P.sorted_words(i)))]
    chk("6c No call identifier pattern in the text layer", not hits and calls == [1], f"patterns found: {hits}; pages with the word 'Call': {calls}")
    # 7 filler check
    viol, nb = run_prose_check(d)
    chk("7 Filler: no number, date, organisation name or acronym in bank paragraphs and text blocks outside placeholders",
        not viol, f"{nb} bank paragraphs and all text blocks scanned; " + ("violations: " + "; ".join(viol[:6]) if viol else "none"))
    # extra checks
    foot = ident["footer"]
    nofoot = [i for i in range(1, P.n + 1) if norm(foot) not in norm(" ".join(w["text"] for w in P.sorted_words(i)))]
    chk("8 Footer text present on every page", not nofoot, f"missing on pages {nofoot}" if nofoot else f"present on all {P.n} pages")
    outside = []
    for i in range(1, P.n + 1):
        pg = P.page(i)
        for w in P.sorted_words(i):
            if w["x1"] > pg.width + 0.5 or w["bottom"] > pg.height + 0.5 or w["x0"] < -0.5 or w["top"] < -0.5:
                outside.append((i, w["text"]))
                break
    chk("9 No text outside the page area", not outside, str(outside[:5]))
    one_page = {b: len(pages_of(b)) == blocks[b]["pages"] for b in ("cover", "toc", "key")}
    chk("10 Cover, table of contents and key facts are one page each", all(one_page.values()), str(one_page))
    import pypdf
    md = pypdf.PdfReader(str(PDF)).metadata
    chk("11 PDF metadata carries the ID and the word synthetic",
        all("SP05" in (md.get(k) or "") and "synthetic" in (md.get(k) or "").lower() for k in ("/Title", "/Subject")) and "synthetic" in (md.get("/Author") or "").lower(),
        f"title={md.get('/Title')}; author={md.get('/Author')}; subject={md.get('/Subject')}")
    # placements
    pl = {t["field"]: t["page"] for t in targets}
    for x, r in dis_records:
        pl.setdefault(f"distractor.{x['id']}", []).append(r["page"]) if isinstance(pl.get(f"distractor.{x['id']}"), list) else pl.__setitem__(f"distractor.{x['id']}", [r["page"]])
    d_old = d.get("placements") or {}
    if not d_old or "--record" in sys.argv:
        d["placements"] = {k: v for k, v in pl.items()}
        import SP05_build as B
        DATA.write_text(yaml.dump(d, Dumper=B._dumper(), sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
        chk("12 Placements recorded in the data file", True, "recorded in this run")
    else:
        diff = {k: (d_old.get(k), v) for k, v in pl.items() if d_old.get(k) != v}
        chk("12 Placements match the pages recorded in the data file", not diff, str(diff) if diff else "all match")

    # ---------------------------------------------------------- write answer key
    mism = dict(
        declared=True,
        stated_total_cents=m["stated_total"], derived_total_cents=derived_pdf,
        difference_cents=m["stated_total"] - derived_pdf,
        stated_exceeds_derived_percent=round(100 * (m["stated_total"] / derived_pdf - 1), 3),
        expected_pipeline_behaviour="Flag the mismatch. Do not correct either value.",
        stated_matches_sum_of_partners=0)
    header = OrderedDict(
        document_id="SP05", version="1.0", status="build candidate, not frozen (human steps open)",
        seed=d["meta"]["seed"],
        conventions=dict(amounts="integers in euro cents", dates="ISO 8601", booleans="0 or 1", missing="null",
                         page_numbers="physical page index starting at 1", bbox="[x0, top, x1, bottom] in PDF points, origin top left of the page as displayed",
                         page_size_pt=dict(portrait=[595.28, 841.89], landscape=[841.89, 595.28])),
        authority_rules=[
            "Table 5.1 (part 1 and its continuation in Annex C) is authoritative for partner amounts.",
            "For P4, only the first amount in the merged cell counts; the subcontracting amount never does.",
            "The key facts box and section 5.2 are authoritative for the stated total requested amount. The derived total is recorded separately and is never substituted for the stated total.",
            "The Carried forward and Brought forward rows are never partner amounts.",
            "The partner name is the legal name from the consortium list in section 2.1. Spelling variants of P3 are aliases, not separate partners.",
            "The submission date is the printed text on the cover, not the date inside the stamp.",
            "The call identifier is null.",
            "The footer text is a non target string."],
        non_target_strings=[foot],
    )
    partners_out = []
    for k in pids:
        p = d["partners"][k]
        partners_out.append(dict(id=k, legal_name=p["legal"], short_name=p["short"], acronym=p["acronym"], category=p["category"],
                                 role=p["role"], aliases=[p["short"]] + list(p["variants"]),
                                 requested_amount_cents=m["funding"][k], total_costs_cents=m["costs"][k]["total"]))
    key = OrderedDict(header=header, target_values=targets, partners=partners_out,
                      derived_total_cents=derived_pdf, stated_total_cents=m["stated_total"],
                      total_project_cost_cents=m["total_project_cost"], own_contribution_cents=m["own_contribution"],
                      declared_mismatch=mism)
    (ROOT / "SP05_answer_key.json").write_text(json.dumps(key, indent=2, ensure_ascii=False), encoding="utf-8")

    # ---------------------------------------------------------- manifest
    def pgs(*keys):
        out = []
        for k in keys:
            for x, r in dis_records:
                if x["id"] == k:
                    out.append(r["page"])
        return out

    def tpage(f):
        return next(t["page"] for t in targets if t["field"] == f)

    two = [r for r in runs if r[0] == "2"]
    manifest = [
        ("#1", "V, D, K, M", "; ".join(f"{a} to {b}" if a != b else str(a) for a, b in [(min(land_all), max(land_all))] + []) + f" (landscape pages {', '.join(map(str, land_all))}); two column pages " + ", ".join(f"{r[1]} to {r[2]}" for r in two),
         "all", "Portrait and landscape pages are mixed, sections switch between one and two columns, Table 5.1 part 1 sits on landscape pages.",
         "Wrong reading order across columns; rotated or sideways table text misread; page orientation ignored."),
        ("#3", "K, M", f"{st['S5t']}; {st['C']}", "partner.P1 to P8 requested_amount",
         f"Table 5.1 part 1 ends on page {st['S5t']} and is continued in Annex C on page {st['C']}, {st['C'] - st['S5t']} pages later.",
         "Partners P6 to P8 missed, or the continuation not linked to the first part."),
        ("#10 and #11", "T, V, D", f"{st['S5t']}; {st['C']}", "partner requested_amount",
         "Grouped header (Costs spanning four columns, then Total costs, then Requested funding); each partner row wraps onto two lines; the header is repeated in Annex C with the wording Funding requested.",
         "Wrong column assigned (for example total costs read as requested funding); partner name matched to the wrong numbers."),
        ("Nested table", "V, D", str(tpage("trl_start")), "trl_start",
         "The Current status cell of Table 1.1 contains a nested table with three rows; the TRL start value is in the technology readiness row.",
         "TRL start null or read from the wrong row."),
        ("#14 and #21", "T, K, V", f"1; {st['key']}; {st['S5t']}; {st['S5c']}; {st['C']}; {', '.join(map(str, sorted(set(pgs('X02', 'X03', 'X04')))))}",
         "stated_total_requested_amount; partner requested_amount; submission_date",
         "Finnish format with euro and thousand separators in Table 5.1 part 1 and the key facts box; EUR thousand with one decimal in Annex C, stated in the header only; international format in section 5.2; dates as dd.mm.yyyy on the cover and as ISO dates in the annexes.",
         "Annex C amounts read as euro instead of thousand euro; decimal comma misread as thousands separator; dates not normalised."),
        ("#15 and #16", "V, T, K", f"{st['key']}; {st['S5t']}; {st['C']}", "stated_total_requested_amount; partner requested_amount",
         "The key facts box shows total project cost, own contribution and stated total requested amount side by side; subtotal rows are not partners; total costs sit next to requested funding.",
         "Total project cost or own contribution taken as the stated total; subtotal rows or total costs taken as partner amounts."),
        ("#18 and #20", "T, M, K", f"{pages_of('S2')[0]}; {st['S5t']}; {st['C']}", "partner.P1 to P8 name",
         "Table 5.1 identifies partners by short name only; the legal names appear only in the consortium list.",
         "Short name returned as the partner name; table rows not linked to the consortium list."),
        ("#20 and #30", "K, M", ", ".join(map(str, sorted(set(pgs("X15", "X16", "X17"))))), "partner.P3.name",
         "P3 appears under spelling variants in one work package description, in the Gantt chart image and on the signature page.",
         "Duplicate partner created for P3."),
        ("#30", "M", f"{st['S5t']}; {st['C']}", "partner.P5.requested_amount; partner.P7.requested_amount",
         "P5 and P7 have similar legal names, short names and acronyms, and are on different table parts; amounts differ by more than 20%.",
         "P5 and P7 merged or their amounts swapped."),
        ("#22", "V, D", str(st["S5t"]), "partner.P4.requested_amount",
         "P4 requested funding cell is merged across two rows and holds the amount followed by a smaller subcontracting amount.",
         "Subcontracting amount returned as the requested amount, or the two amounts added."),
        ("#23", "D", "1", "submission_date",
         "The RECEIVED stamp image partly overlaps the printed submission date and carries a different date inside the image.",
         "Stamp date returned as the submission date, or the date not found."),
        ("#24 and #29", "M", "1", "call_identifier",
         "The cover reads Call: to be confirmed and no identifier appears anywhere in the document.",
         "Invented or copied call identifier instead of null."),
        ("#8 and #26", "M, K", str(tpage("mcrl_target")), "mcrl_target",
         "The MCRL target appears only inside the radar chart image (Figure 4.1).",
         "MCRL target null, taken from a checkpoint in the text, or guessed."),
        ("#24", "K, V, D", f"{pages_of('S2')[0]}; {st['C']}", "partner.P6.requested_amount",
         "P6 is an associated partner with 0.0 requested funding in Table 5.1 continued.",
         "P6 omitted or amount returned as null instead of zero."),
        ("Validation mismatch", "none (SP05 design)", f"{st['key']}; {st['S5c']}; {st['S5t']}; {st['C']}", "stated_total_requested_amount",
         f"The stated total is {mism['stated_exceeds_derived_percent']} percent higher than the sum of the partner amounts and Table 5.1 has no grand total row.",
         "Stated total silently replaced by the derived total, or the mismatch not flagged."),
        ("#31", "D", "all", "all target fields",
         "Every target value has one recorded page and bounding box in the answer key.",
         "Value returned without a verifiable location."),
    ]
    with open(ROOT / "SP05_manifest.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["issue_number", "source_papers", "page", "affected_field", "description", "expected_failure_mode"])
        for row in manifest:
            w.writerow(row)

    # ---------------------------------------------------------- partner register
    with open(ROOT / "SP05_partner_register.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["legal_name", "aliases_and_spelling_variants", "acronym", "category"])
        for k in pids:
            p = d["partners"][k]
            w.writerow([p["legal"], "; ".join([p["short"]] + list(p["variants"])), p["acronym"], p["category"]])

    # ---------------------------------------------------------- human steps
    write_human_steps(d, targets, key, P, st, pages_of, checks)
    # ---------------------------------------------------------- check report
    ok_all = all(c["ok"] for c in checks)
    (ROOT / "SP05_check_report.json").write_text(json.dumps(checks, indent=2, ensure_ascii=False), encoding="utf-8")
    lines = ["# SP05 automatic check report", "", f"Pages: {P.n}. Result: {'ALL AUTOMATIC CHECKS PASSED' if ok_all else 'SOME CHECKS FAILED'}.", ""]
    for c in checks:
        lines.append(f"* {'PASS' if c['ok'] else 'FAIL'}: {c['name']}. {c['detail']}")
    (ROOT / "SP05_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return ok_all


def write_human_steps(d, targets, key, P, st, pages_of, checks):
    ident = d["identity"]
    L = []
    L.append("# SP05 human steps (open)\n")
    L.append("Nothing in this file has been done. Each step needs a person. The automatic checks are in SP05_check_report.md.\n")
    L.append("## Step 8. Fairness check\n")
    L.append("A person confirms that every target value can be found and read by a careful human reader. Page numbers are physical page numbers of SP05.pdf. Tick each line.\n")
    L.append("| Done | Field | Where to look | Location type |\n|---|---|---|---|")
    for t in targets:
        where = f"page {t['page']}"
        if t["field"] == "submission_date":
            where += ", cover, next to the stamp (check the date is readable where the stamp overlaps it)"
        if t["field"] == "mcrl_target":
            where += ", Figure 4.1 (the radar chart), check the label and the scale are legible"
        if t["field"] == "trl_start":
            where += ", Table 1.1, nested table, technology readiness row"
        if t["field"] == "partner.P4.requested_amount":
            where += ", merged cell, first amount only"
        if t["field"] == "call_identifier":
            where = "page 1, placeholder only; confirm no identifier appears anywhere else"
        if t["field"].startswith("partner.P") and t["field"].endswith("requested_amount") and int(t["field"][9]) >= 6:
            where += ", Annex C, values in EUR thousand"
        L.append(f"| [ ] | {t['field']} | {where} | {t['location_type']} |")
    L.append("\nAlso confirm: the landscape pages 41 to 43 can be read without strain, and the Gantt chart on page 67 is legible. Any value a human cannot read must be made legible and the document rebuilt as a new version.\n")
    L.append("## Step 9. Blind second extraction\n")
    L.append("A second person fills in the form below from SP05.pdf without seeing SP05_answer_key.json. Compare with the key. Every disagreement leads to a fix of the design or the key until agreement is complete. Record the initial agreement rate here: ______ of ______ fields.\n")
    L.append("| Field | Value extracted by the second person | Page | Notes |\n|---|---|---|---|")
    fields = ["Proposal acronym", "Proposal title", "Call identifier", "Funding programme", "Submission date (ISO)", "Stated total requested amount (euro cents)",
              "TRL start", "TRL target", "MCRL start", "MCRL target"]
    for f in fields:
        L.append(f"| {f} | | | |")
    for k in d["partners"]:
        L.append(f"| Partner {k}: name as written in the consortium list | | | |")
        L.append(f"| Partner {k}: requested amount (euro cents) | | | |")
    L.append("| Derived total (sum of the partner amounts, euro cents) | | | |")
    L.append("| Stated total matches the sum of partners (yes or no) | | | |")
    L.append("\n## Step 10. Realism review\n")
    L.append("A person familiar with real proposals answers yes or no for each item and adds comments. The document only has to look plausible to a reader skimming it.\n")
    for q in ["The cover looks like a plausible proposal cover.",
              "The table of contents and the section structure look plausible.",
              "The key facts box looks plausible.",
              "The consortium list and the roles look plausible.",
              "The work plan, tasks and deliverables look plausible.",
              "The budget table layout looks like budget tables in real proposals.",
              "The landscape budget pages and the table continued in an annex look plausible.",
              "The annexes (Gantt chart, work package tables, deliverables, risk register, signature page) look plausible.",
              "The filler text reads like neutral proposal prose and contains nothing that looks like a real fact.",
              "Anything that makes the document look obviously artificial (apart from the footer) is noted below."]:
        L.append(f"* [ ] {q}")
    L.append("\nComments: ______________________________\n")
    L.append("## Step 11. Name check (YTJ and web search)\n")
    L.append("Check every name below against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced, and the document rebuilt as a new version. Record the result per line.\n")
    L.append("| Done | Name | Kind | YTJ result | Web search result |\n|---|---|---|---|---|")
    names = [(ident["acronym"], "proposal acronym"), (ident["title"], "proposal title")]
    for k, p in d["partners"].items():
        names.append((p["legal"], f"{k} legal name"))
        names.append((p["short"], f"{k} short name"))
        names.append((p["acronym"], f"{k} acronym"))
        for v in p["variants"]:
            names.append((v, f"{k} spelling variant"))
    for n, kind in names:
        L.append(f"| [ ] | {n} | {kind} | | |")
    L.append("\nAlso check: the names of the management bodies and the project title are not real project names.\n")
    L.append("## Step 12. Freeze\n")
    L.append("Not done. After all automatic and human checks pass: tag version 1.0, regenerate SP05_checksums.txt, and do not edit the files again. The document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.\n")
    (ROOT / "SP05_human_steps.md").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    sys.path.insert(0, str(ROOT))
    ok = run()
    sys.exit(0 if ok else 1)
