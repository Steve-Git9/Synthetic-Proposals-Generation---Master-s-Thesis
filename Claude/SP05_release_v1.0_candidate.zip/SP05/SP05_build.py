#!/usr/bin/env python3
"""SP05 build script. One command rebuilds everything from stored files.

    python3 SP05_build.py              build the PDF and run all checks
    python3 SP05_build.py --calibrate  find the filler counts that give the planned page map,
                                       write them into SP05_data.yaml, then build

The script reads only stored files (SP05_data.yaml, template/, SP05_paragraph_bank.md)
and never calls a language model.
"""
import calendar
import datetime as dt
import math
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import jinja2
import yaml

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "SP05_data.yaml"
BANK = ROOT / "SP05_paragraph_bank.md"
TEMPLATE_DIR = ROOT / "template"
OUT = ROOT / "build_out"
EPOCH = calendar.timegm(dt.datetime(2026, 10, 26, 0, 0, 0).timetuple())

PORTRAIT_H = 841.89
LAND_W, LAND_H = 841.89, 595.276


class TeX(str):
    """String that is already LaTeX and must not be escaped again."""


_ESC = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
        "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}


def tex(s):
    if isinstance(s, TeX):
        return s
    return TeX("".join(_ESC.get(c, c) for c in str(s)))


def finalize(v):
    if isinstance(v, TeX) or not isinstance(v, str):
        return v
    return tex(v)


def fi(c):
    """Finnish number format, full euro: 1 234 567,50 EUR sign."""
    neg = c < 0
    c = abs(int(c))
    euros, cents = divmod(c, 100)
    s = f"{euros:,}".replace(",", "~")
    return TeX(("-" if neg else "") + f"{s},{cents:02d}~\u20ac")


def intl(c):
    euros, cents = divmod(int(c), 100)
    return f"EUR {euros:,}.{cents:02d}"


def kf(c):
    """EUR thousand, one decimal, international format; input must be a multiple of 100 euro."""
    assert int(c) % 10000 == 0, c
    tenths = int(c) // 10000
    return TeX(f"{tenths // 10:,}.{tenths % 10}")


def kf_plain(c):
    tenths = int(c) // 10000
    return f"{tenths // 10:,}.{tenths % 10}"


def dfi(iso):
    y, m, d = iso.split("-")
    return f"{d}.{m}.{y}"


def fi_plain(c):
    return str(fi(c)).replace("~", " ")


def load_bank():
    paras = []
    for blk in re.split(r"\n\s*\n", BANK.read_text(encoding="utf-8")):
        blk = blk.strip()
        m = re.match(r"^\[(B\d+)\]\s+(.*)$", blk, re.S)
        if m:
            paras.append((m.group(1), " ".join(m.group(2).split())))
    return paras


class Ctx:
    def __init__(self, d):
        self.d = d
        self.bank = load_bank()
        assert len(self.bank) == d["layout"]["bank_size"], (len(self.bank), d["layout"]["bank_size"])
        self.blocks = {b["id"]: b for b in d["layout"]["blocks"]}
        self.counts = d["layout"]["filler_counts"]
        self.seqs = d["layout"]["filler_sequences"]
        self.prev_orient = "portrait"
        self.text_blocks = yaml.safe_load((TEMPLATE_DIR / "SP05_text_blocks.yaml").read_text(encoding="utf-8"))
        self.p = d["partners"]
        m = d["money_cents"]
        r = d["readiness"]
        self.f = dict(
            submission_fi=dfi(d["dates"]["submission"]),
            stated_total_fi=fi(m["stated_total"]),
            stated_total_intl=intl(m["stated_total"]),
            total_project_cost_fi=fi(m["total_project_cost"]),
            own_contribution_fi=fi(m["own_contribution"]),
        )
        self.var = dict(wp_p3=d["p3_variant_use"]["work_package_description"])
        self.sig_name = {k: v["legal"] for k, v in d["partners"].items()}
        self.sig_name["P3"] = d["p3_variant_use"]["signature_page"]
        self.jenv_text = jinja2.Environment(undefined=jinja2.StrictUndefined, keep_trailing_newline=False)

    # --- helpers used by the template
    def blk(self, bid):
        b = self.blocks[bid]
        o = b["orient"]
        if bid == "cover":
            self.prev_orient = o
            return TeX(rf"\label{{blk:{bid}}}")
        out = r"\clearpage"
        if o == "landscape" and self.prev_orient == "portrait":
            out = r"\gotolandscape"
        elif o == "portrait" and self.prev_orient == "landscape":
            out = r"\gotoportrait"
        self.prev_orient = o
        return TeX(out + rf"\label{{blk:{bid}}}")

    def fill(self, sec, part, nparts):
        n = int(self.counts.get(sec, 0))
        a = n * part // nparts
        b = n * (part + 1) // nparts
        seq = self.seqs[sec][a:b]
        paras = [tex(self.bank[i][1]) for i in seq]
        return TeX("\n\n".join(paras) + ("\n\n" if paras else ""))

    def tb(self, key):
        node = self.text_blocks
        for part in key.split("."):
            node = node[part]
        txt = self.jenv_text.from_string(node).render(p=self.p, f=self.f_plain(), r=self.d["readiness"],
                                                      d=self.d, var=self.var)
        txt = txt.strip()
        return TeX("\n\n".join(tex(" ".join(par.split())) for par in re.split(r"\n\s*\n", txt)))

    def f_plain(self):
        m = self.d["money_cents"]
        return dict(stated_total_intl=intl(m["stated_total"]), stated_total_fi=fi_plain(m["stated_total"]))


def render_tex(d, ctx):
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(TEMPLATE_DIR)),
        block_start_string="<%", block_end_string="%>",
        variable_start_string="<<", variable_end_string=">>",
        comment_start_string="<#", comment_end_string="#>",
        undefined=jinja2.StrictUndefined, finalize=finalize, trim_blocks=True, lstrip_blocks=True,
        keep_trailing_newline=True)
    tpl = env.get_template("main.tex.j2")
    pids = list(d["partners"].keys())
    return tpl.render(
        d=d, p=d["partners"], f=ctx.f, r=d["readiness"], m=d["money_cents"], pids=pids,
        part1=pids[:5], part2=pids[5:], sig_name=ctx.sig_name,
        tex=tex, fi=fi, kf=kf, blk=ctx.blk, fill=ctx.fill, tb=ctx.tb)


def run_cmd(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    return r


def run_latex(passes=3):
    env = dict(os.environ, SOURCE_DATE_EPOCH=str(EPOCH), FORCE_SOURCE_DATE="1", TZ="UTC", LC_ALL="C.UTF-8")
    for i in range(passes):
        r = subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", "SP05.tex"],
                           cwd=OUT, capture_output=True, text=True, env=env)
        if r.returncode != 0:
            log = (OUT / "SP05.log").read_text(errors="replace") if (OUT / "SP05.log").exists() else r.stdout
            idx = log.find("\n!")
            print(log[idx: idx + 1500] if idx >= 0 else log[-1500:])
            raise SystemExit("xelatex failed")


def read_labels():
    aux = (OUT / "SP05.aux").read_text(errors="replace")
    starts = {}
    for m in re.finditer(r"\\newlabel\{blk:(\w+)\}\{\{[^}]*\}\{(\d+)\}", aux):
        starts[m.group(1)] = int(m.group(2))
    return starts


def block_pages(d, starts):
    order = [b["id"] for b in d["layout"]["blocks"]]
    total = starts["END"]
    res = {}
    for i, bid in enumerate(order):
        nxt = starts[order[i + 1]] if i + 1 < len(order) else total + 1
        res[bid] = nxt - starts[bid]
    return res, total


def produce(d, passes=3):
    OUT.mkdir(exist_ok=True)
    ctx = Ctx(d)
    src = render_tex(d, ctx)
    (OUT / "SP05.tex").write_text(src, encoding="utf-8")
    run_latex(passes)
    starts = read_labels()
    return starts


def charts():
    r = run_cmd([sys.executable, str(ROOT / "SP05_charts.py"), str(DATA), str(OUT / "img")])
    if r.returncode:
        print(r.stdout, r.stderr)
        raise SystemExit("charts failed")


def calibrate(d):
    blocks = d["layout"]["blocks"]
    targets = {b["id"]: b["pages"] for b in blocks if b["filler"]}
    counts = d["layout"]["filler_counts"]
    guess = dict(S1=100, S2=55, S3=80, S4=28, S5a=2, S5c=4, S6=25, S7=18, S8=26, A=18, B=6, C=18, E=10, F=10, G=10)
    for k in targets:
        counts[k] = guess.get(k, 6)
    lo = {k: 0 for k in targets}
    hi = {k: None for k in targets}
    probed = {}
    for it in range(24):
        d["layout"]["filler_counts"] = counts
        starts = produce(d, passes=2)
        pages, total = block_pages(d, starts)
        done = True
        for k, tgt in targets.items():
            n = counts[k]
            pg = pages[k]
            if pg <= tgt:
                lo[k] = max(lo[k], n)
            else:
                hi[k] = n if hi[k] is None else min(hi[k], n)
        for k, tgt in targets.items():
            if hi[k] is not None and hi[k] - lo[k] <= 1:
                counts[k] = lo[k]
                continue
            done = False
            if hi[k] is None:
                pg = max(pages[k], 1)
                if pages[k] < tgt:
                    nxt = max(lo[k] + 1, int(math.ceil(counts[k] * tgt / pg * 1.02)))
                else:
                    nxt = lo[k] + max(1, int(lo[k] * 0.12))
                counts[k] = min(nxt, 690)
            else:
                counts[k] = (lo[k] + hi[k]) // 2
        print(f"iteration {it}: pages {pages} total {total}")
        print("   counts", {k: counts[k] for k in targets})
        if done:
            break
    else:
        raise SystemExit("calibration did not converge")
    d["layout"]["filler_counts"] = counts
    # final confirmation run
    starts = produce(d, passes=3)
    pages, total = block_pages(d, starts)
    bad = {b["id"]: (pages[b["id"]], b["pages"]) for b in blocks if pages[b["id"]] != b["pages"]}
    if bad:
        raise SystemExit(f"calibration mismatch after convergence: {bad}")
    d["layout"]["calibrated"] = True
    d["layout"]["block_start_pages"] = {k: v for k, v in starts.items() if k != "END"}
    d["layout"]["total_pages"] = total
    return d


def postprocess_pdf(d, starts):
    import pypdf
    from pypdf import PdfReader, PdfWriter, Transformation
    from pypdf.generic import RectangleObject
    order = [b["id"] for b in d["layout"]["blocks"]]
    total = starts["END"]
    land_pages = set()
    for i, bid in enumerate(order):
        b = d["layout"]["blocks"][i]
        if b["orient"] == "landscape":
            nxt = starts[order[i + 1]] if i + 1 < len(order) else total + 1
            land_pages.update(range(starts[bid], nxt))
    r = PdfReader(str(OUT / "SP05.pdf"))
    assert len(r.pages) == total, (len(r.pages), total)
    w = PdfWriter()
    for i, page in enumerate(r.pages, start=1):
        if i in land_pages:
            H = float(page.mediabox.height)
            page.add_transformation(Transformation().translate(0, -(H - LAND_H)))
            box = RectangleObject([0, 0, LAND_W, LAND_H])
            page.mediabox = box
            page.cropbox = box
            page.trimbox = box
            page.bleedbox = box
            page.artbox = box
        w.add_page(page)
    w.add_metadata({
        "/Title": "SP05 synthetic test document (synthetic proposal, ID SP05)",
        "/Author": "SP05 synthetic document generator (synthetic, no real author)",
        "/Subject": "Synthetic document ID SP05, version 1.0, for research purposes only",
        "/Keywords": "synthetic, SP05, test document",
        "/Creator": "SP05_build.py with XeTeX",
        "/Producer": "SP05_build.py with XeTeX and pypdf",
        "/CreationDate": "D:20261026000000Z",
        "/ModDate": "D:20261026000000Z",
    })
    with open(ROOT / "SP05.pdf", "wb") as fh:
        w.write(fh)
    return sorted(land_pages)


def main():
    d = yaml.safe_load(DATA.read_text(encoding="utf-8"))
    OUT.mkdir(exist_ok=True)
    charts()
    if "--calibrate" in sys.argv:
        d = calibrate(d)
        DATA.write_text(yaml.dump(d, Dumper=_dumper(), sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
        print("calibration written to", DATA)
        d = yaml.safe_load(DATA.read_text(encoding="utf-8"))
    starts = produce(d, passes=3)
    pages, total = block_pages(d, starts)
    if d["layout"]["calibrated"]:
        bad = {b["id"]: (pages[b["id"]], b["pages"]) for b in d["layout"]["blocks"] if pages[b["id"]] != b["pages"]}
        if bad:
            raise SystemExit(f"page map differs from plan: {bad}")
        exp = {k: v for k, v in starts.items() if k != "END"}
        if exp != d["layout"]["block_start_pages"]:
            raise SystemExit("block start pages differ from the stored plan")
    land = postprocess_pdf(d, starts)
    print(f"built SP05.pdf: {total} pages, landscape pages {land}")
    (OUT / "starts.yaml").write_text(yaml.safe_dump({"starts": starts, "landscape": land, "total": total}))
    if "--no-verify" not in sys.argv and d["layout"]["calibrated"]:
        import SP05_verify
        SP05_verify.run()


def _dumper():
    class Dumper(yaml.SafeDumper):
        pass

    def _repr_list(dumper, seq):
        flow = all(isinstance(x, (int, float)) for x in seq) and len(seq) > 6
        return dumper.represent_sequence("tag:yaml.org,2002:seq", seq, flow_style=flow)

    Dumper.add_representer(list, _repr_list)
    return Dumper


if __name__ == "__main__":
    main()
