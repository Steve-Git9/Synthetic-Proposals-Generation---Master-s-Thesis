"""Write SP05_gold.json from SP05_answer_key.json (no manual transcription).
Structure follows the ByggMap gold set example. Run after SP05_verify.py."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
key = json.loads((root / "SP05_answer_key.json").read_text(encoding="utf-8"))
tv = {t["field"]: t["value"] for t in key["target_values"]}

gold = {
    "proposal": {
        "proposal_acronym": tv["proposal_acronym"],
        "proposal_title": tv["proposal_title"],
        "call_identifier": tv["call_identifier"],
        "submission_date": tv["submission_date"],
    },
    "proposal_facts": {
        "requested_total_cents": tv["stated_total_requested_amount"],
        "trl_start": tv["trl_start"],
        "trl_target": tv["trl_target"],
        "mcrl_start": tv["mcrl_start"],
        "mcrl_target": tv["mcrl_target"],
    },
    "partners": [
        {
            "partner_name": tv[f"partner.{p['id']}.name"],
            "requested_cents": tv[f"partner.{p['id']}.requested_amount"],
        }
        for p in key["partners"]
    ],
    "metadata": {"extraction_timestamp": None, "source_file": "SP05.pdf"},
}

assert gold["proposal_facts"]["requested_total_cents"] == key["stated_total_cents"]
assert sum(p["requested_cents"] for p in gold["partners"]) == key["derived_total_cents"]
assert len(gold["partners"]) == 8
(root / "SP05_gold.json").write_text(json.dumps(gold, indent=4, ensure_ascii=False) + "\n", encoding="utf-8")
print("SP05_gold.json written")
