#!/usr/bin/env python3
"""Write the answer key, manifest, partner register and name check list from SP03_data.yaml.

Usage: python3 -I SP03_make_keys.py SP03_data.yaml outdir
"""
import csv
import json
import sys
from pathlib import Path

import yaml

AUTHORITY_RULES = [
    "The budget grid is authoritative for partner amounts, except where a cell refers to section E.2 (partner C) and where a handwritten correction is present (partner D).",
    "For partner D, the handwritten corrected amount is authoritative, and the struck printed amount is never used.",
    "The box Total funding requested is authoritative for the stated total requested amount.",
    "The letter of support, the subtotal row and the research unit budget box are never authoritative for any target field.",
    "The submission date is null. No other date may be used in its place.",
    "The ground truth is identical for SP03A and SP03B. Page numbers are identical in both versions.",
    "The footer text is a non target string.",
]


def build_key(d):
    fields = []
    for t in d["targets"]:
        f = dict(t)
        if "value_cents" in f:
            f["value"] = f.pop("value_cents")
            f["unit"] = "euro cents"
        f.setdefault("distractors", [])
        order = ["field", "value", "unit", "page", "location_type", "surface", "authority_rule",
                 "distractors", "equivalent_representations"]
        fields.append({k: f[k] for k in order if k in f})
    partners = []
    for pt in d["partner_targets"]:
        nm, am = dict(pt["name"]), dict(pt["requested_amount"])
        am["value"] = am.pop("value_cents")
        am["unit"] = "euro cents"
        partners.append({
            "partner": pt["partner"], "short_name": pt["short_name"],
            "organisation_name": {k: nm[k] for k in ["value", "page", "location_type", "surface", "authority_rule", "distractors"]},
            "requested_amount": {k: am[k] for k in ["value", "unit", "page", "location_type", "surface", "authority_rule", "distractors"]},
        })
    partner_sum = sum(p["requested_amount"]["value"] for p in partners)
    stated = next(f for f in fields if f["field"] == "stated_total_requested_amount")["value"]
    struck_cents = None
    for dd in partners[3]["requested_amount"]["distractors"]:
        if "struck" in dd["meaning"]:
            struck_cents = round(float(dd["surface"].replace(" ", "").replace(",", ".")) * 1000 * 100)
    return {
        "document_id": d["meta"]["document_id"],
        "version": d["meta"]["version"],
        "applies_to": ["SP03A", "SP03B"],
        "formats": {"amounts": "integers in euro cents", "dates": "ISO 8601",
                    "booleans": "0 or 1", "missing_field": "null"},
        "authority_rules": AUTHORITY_RULES,
        "non_target_strings": d["non_target_strings"],
        "fields": fields,
        "partners": partners,
        "derived": {
            "requested_total_cents": partner_sum,
            "equals_stated_total": partner_sum == stated,
            "sum_if_struck_value_were_used_cents": partner_sum - partners[3]["requested_amount"]["value"] + struck_cents,
            "note": "Derived total is the sum of the partner amounts, using the handwritten value for partner D and the E.2 value for partner C. Partner F counts as zero.",
        },
    }


def build_gold(d):
    """Gold set in the structure of the extraction schema (same key order as the reference example)."""
    pr = d["project"]
    return {
        "proposal": {
            "proposal_acronym": pr["acronym"],
            "proposal_title": pr["title"],
            "call_identifier": pr["call_id"],
            "submission_date": pr["submission_date"],
        },
        "proposal_facts": {
            "requested_total_cents": d["totals"]["derived_total_cents"],
            "trl_start": pr["trl_start"],
            "trl_target": pr["trl_target"],
            "mcrl_start": pr["mcrl_start"],
            "mcrl_target": pr["mcrl_target"],
        },
        "partners": [{"partner_name": x["org_name"], "requested_cents": x["requested_cents"]} for x in d["partners"]],
        "metadata": {"extraction_timestamp": None, "source_file": None},
    }


def write_csvs(d, out):
    with open(out / "SP03_manifest.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["issue number", "source papers", "page", "affected field", "description",
                    "expected failure mode", "version"])
        for x in d["difficulties"]:
            w.writerow([x["issue"], x["sources"], x["page"], x["field"], x["description"],
                        x["failure"], x["version"]])
    with open(out / "SP03_partner_register.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["legal name", "aliases used in the document", "acronym", "category"])
        for p in d["partners"]:
            aliases = [p["short_name"]]
            if p["key"] == "E":
                aliases.append(d["letter"]["company_name_variant"])
            w.writerow([p["org_name"], "; ".join(aliases), p["short_name"], p["type"]])


def write_name_check(d, out):
    lines = [
        "# SP03 name check list (HUMAN STEP)",
        "",
        "Check every name below against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced in SP03_draw_data.py, followed by a rebuild and a new version.",
        "",
        "## Organisation names",
        "",
    ]
    for p in d["partners"]:
        names = [p["org_name"], p["short_name"]]
        if p["key"] == "E":
            names.append(d["letter"]["company_name_variant"])
        lines.append(f"* Partner {p['key']}: " + "; ".join(names))
    lines += ["", "## Other names", "",
              f"* Project acronym: {d['project']['acronym']}",
              f"* Project title: {d['project']['title']}",
              "* Funders listed in Part A, besides the real public funder: "
              + "; ".join(f for f in d["project"]["funders_listed"] if f != d["project"]["funding_programme"]),
              "* Stamp text: COORDINATING OFFICE, VERIFIED, SEAL",
              "", "## Call identifier", "",
              f"* {d['project']['call_id']} (syntax RCF[year]/[four digits], must not exist)",
              "", "## Checklist", "",
              "* YTJ search done for each organisation name: open",
              "* Web search done for each organisation name and the acronym: open",
              "* Web search done for the call identifier: open",
              "* Result recorded here, with date and name of the person who checked: open", ""]
    (out / "SP03_name_check_list.md").write_text("\n".join(lines), encoding="utf-8")


def write_human_forms(d, out):
    key = build_key(d)
    deg = d["degradation"]
    # ---- legibility record, contains the values, for the person checking SP03B only
    L = ["# SP03 legibility record for SP03B (HUMAN STEP 11.6)", "",
         "Open SP03B.pdf and confirm for each value below that a person can still read it. A value that no human can read makes the test unfair, so the degradation must then be reduced in the data file and the document rebuilt as a new version. Record the outcome per value.", "",
         "Special attention:", "",
         f"* Page {deg['rotate_180_pages'][0]} is rotated by 180 degrees. Turn the page and confirm that the readiness level boxes can be read.",
         "* Page 21: the handwritten corrected amount of partner D and its initials, next to the struck printed amount.",
         "* Light blur was applied to pages " + ", ".join(str(x) for x in deg["blur_pages"]) + ". Confirm that nothing on these pages is unreadable.",
         "", "## Values", ""]
    for f in key["fields"]:
        if f["surface"] is None:
            L.append(f"* {f['field']}: null, the Date of submission box on page 3 is empty. Readable as empty: yes / no. Note:")
        else:
            L.append(f"* {f['field']}: {f['surface']}, page {f['page']}. Readable: yes / no. Note:")
    for pt in key["partners"]:
        nm, am = pt["organisation_name"], pt["requested_amount"]
        L.append(f"* Partner {pt['partner']} organisation name: {nm['value']}, page {nm['page']}. Readable: yes / no. Note:")
        L.append(f"* Partner {pt['partner']} requested amount: {am['surface']}, page {am['page']}, {am['location_type']}. Readable: yes / no. Note:")
    L += ["", "## Outcome", "", "* All values readable: yes / no", "* Degradation reduced and document rebuilt as a new version: yes / no", "* Checked by and date:", ""]
    (out / "SP03_legibility_record.md").write_text("\n".join(L), encoding="utf-8")

    # ---- blank extraction form, no values
    B = ["# SP03 blind extraction form (HUMAN STEP 11.7, blank)", "",
         "Instructions for the second person. Extract the values below from SP03A.pdf only. Do not open the answer key, the data file, the manifest or SP03B.pdf before you have finished. Write amounts as integers in euro cents, dates in ISO 8601, and write null for a field that is not stated in the document.", "",
         "## Single fields", "",
         "1. Proposal acronym:", "2. Proposal title:", "3. Call identifier:", "4. Funding programme:",
         "5. Submission date:", "6. Stated total requested amount:", "7. TRL start:", "8. TRL target:",
         "9. MCRL start:", "10. MCRL target:", "", "## Partners", "",
         "List every partner of the consortium. For each, write the name as written in the Organisation name box of its Part B form and its requested amount.", ""]
    for i in range(1, 9):
        B.append(f"* Partner slot {i}. Name: ________  Requested amount: ________")
    B += ["", "## Notes of the second person", "",
          "Write down anything that was ambiguous or that you had to decide yourself, with the page number.", "", "",
          "## Comparison with the answer key (filled in by the researcher afterwards)", "",
          "Every disagreement leads to a fix of the design or of the answer key until agreement is complete.", "",
          "* Disagreement 1. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____",
          "* Disagreement 2. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____",
          "* Disagreement 3. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____",
          "", "Initial agreement rate: ____ of 22 values (10 single fields, 6 partner names, 6 partner amounts)",
          "Final agreement rate after fixes: ____ of 22 values", "Extractor and date:", ""]
    (out / "SP03_blind_extraction_form.md").write_text("\n".join(B), encoding="utf-8")

    # ---- checklist for all human steps
    C = ["# SP03 human steps still open", "",
         "The build prepared the material for each step below. None of these steps has been done.", "",
         "## 11.6 Human legibility check of SP03B", "",
         "Use SP03_legibility_record.md. Status: open.", "",
         "## 11.7 Blind second extraction", "",
         "Give a second person SP03A.pdf and SP03_blind_extraction_form.md only. Record the initial agreement rate in the form. Status: open.", "",
         "## 11.8 Realism review", "",
         "Ask a person familiar with real application forms to answer the questions below for SP03A.pdf.", "",
         "* Does the structure with parts, section codes, numbered boxes and form numbers look like a funder application form? Answer:",
         "* Do the labels and the guidance texts sound natural? Answer:",
         "* Is the budget grid plausible, with merged headers, a subtotal row, a total row and the scale stated in the header? Answer:",
         "* Is a handwritten correction with initials next to a struck printed figure plausible in a submitted form? Answer:",
         "* Is a letter of support attached in front of the form plausible? Answer:",
         "* Are the page count and the annex forms plausible? Answer:",
         "* Is there anything that makes the document look like something other than an application? Answer:",
         "", "Status: open.", "",
         "## 11.9 Name check", "",
         "Use SP03_name_check_list.md for the search in the Finnish Trade Register (YTJ) and on the web. Any match with a real entity must be replaced. Status: open.", "",
         "## 11.10 Freeze", "",
         "Only after all steps above are complete and every fix has been rebuilt and verified:", "",
         "* Tag version 1.0 in the repository.",
         "* Run the build with the option checksums only to write SP03_checksums.txt.",
         "* Do not edit the files again. Any later change creates a new version recorded in CHANGELOG.md.",
         "* Freeze both versions before any extraction prompt is developed. Never open them during prompt tuning.",
         "", "Status: open.", ""]
    (out / "SP03_human_steps_checklist.md").write_text("\n".join(C), encoding="utf-8")


def main(data_path, out_dir):
    d = yaml.safe_load(Path(data_path).read_text(encoding="utf-8"))
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    key = build_key(d)
    (out / "SP03_answer_key.json").write_text(json.dumps(key, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (out / "SP03_gold.json").write_text(json.dumps(build_gold(d), indent=4, ensure_ascii=False) + "\n", encoding="utf-8")
    write_csvs(d, out)
    write_name_check(d, out)
    write_human_forms(d, out)
    return key


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
