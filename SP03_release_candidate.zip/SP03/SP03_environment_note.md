# SP03 environment note

This note records the environment in which SP03 version 1.0 was built. The pinned Python libraries are in requirements.lock.

## System

* Operating system: Ubuntu 24.04.5 LTS, Linux kernel 6.18.44.
* Python: 3.13.17, run in isolated mode.
* Typesetting: XeTeX from TeX Live 2023 (Debian packages), run once per document with the environment variables SOURCE_DATE_EPOCH and FORCE_SOURCE_DATE set from the release date in the data file.
* PDF tools: poppler 24.02.0 (pdftoppm for rasterising at 150 dpi, pdftotext, pdfimages and pdffonts for the checks).
* Python libraries: Pillow, NumPy, PyYAML, Jinja2, pypdf and ReportLab at the versions in requirements.lock.

## Fonts

* Carlito, version 1.104, SIL Open Font License 1.1. Used for all text of the form and of the letter of support.
* DejaVu Sans Bold, version 2.37, Bitstream Vera licence with DejaVu changes in the public domain. Used for the text inside the stamp image.
* Caveat Bold, from the fontsource package for Caveat, version 5.3.0, SIL Open Font License 1.1. This is the open licence handwriting font used for the handwritten correction. The font file and its licence text are in the fonts folder.

## Reproducibility

* One command rebuilds both versions and all generated files: ./build
* Two builds in two different folders on this system gave identical SHA 256 checksums for SP03A.pdf, SP03B.pdf, the degradation log, the answer key, the manifest and the partner register. Other versions of the tools may give different bytes.
* The build reads only SP03_data.yaml, SP03_paragraph_bank.md, the template folder and the fonts folder. It never calls a language model.
* Operations on SP03B, in this order: rotation by 180 degrees (page 15 only), rotation by a seeded small angle, light blur on three seeded pages, seeded Gaussian noise, seeded JPEG compression. All parameters are in SP03_data.yaml and in SP03_degradation_log.csv.
