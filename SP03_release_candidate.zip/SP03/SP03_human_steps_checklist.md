# SP03 human steps still open

The build prepared the material for each step below. None of these steps has been done.

## 11.6 Human legibility check of SP03B

Use SP03_legibility_record.md. Status: open.

## 11.7 Blind second extraction

Give a second person SP03A.pdf and SP03_blind_extraction_form.md only. Record the initial agreement rate in the form. Status: open.

## 11.8 Realism review

Ask a person familiar with real application forms to answer the questions below for SP03A.pdf.

* Does the structure with parts, section codes, numbered boxes and form numbers look like a funder application form? Answer:
* Do the labels and the guidance texts sound natural? Answer:
* Is the budget grid plausible, with merged headers, a subtotal row, a total row and the scale stated in the header? Answer:
* Is a handwritten correction with initials next to a struck printed figure plausible in a submitted form? Answer:
* Is a letter of support attached in front of the form plausible? Answer:
* Are the page count and the annex forms plausible? Answer:
* Is there anything that makes the document look like something other than an application? Answer:

Status: open.

## 11.9 Name check

Use SP03_name_check_list.md for the search in the Finnish Trade Register (YTJ) and on the web. Any match with a real entity must be replaced. Status: open.

## 11.10 Freeze

Only after all steps above are complete and every fix has been rebuilt and verified:

* Tag version 1.0 in the repository.
* Run the build with the option checksums only to write SP03_checksums.txt.
* Do not edit the files again. Any later change creates a new version recorded in CHANGELOG.md.
* Freeze both versions before any extraction prompt is developed. Never open them during prompt tuning.

Status: open.
