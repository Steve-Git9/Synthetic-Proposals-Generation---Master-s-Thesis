# SP03 generation log

Every use of a language model for SP03 is listed here. The build was produced in one agentic session. The calls of the model within that session are grouped by the output they produced. The prompt of each call is the task text stored in SP03_generation_prompt.md (SHA 256 1af90605b80c2f586f98183b92dade52459d1a072bae5ccf5e756f074e9a78e3), together with the project instructions of the thesis project (role, writing rules and scope guardrails) and the tool results of the session, which are not stored separately. Outputs are given as file names with SHA 256 checksums. The time is the time at which the first listed output file was last written, taken from the file system.

The build script, the answer key generation and all checks never call a language model.

## Entry 1. Paragraph bank

* Date and time of the output: 25 October 2026, 19:45 UTC
* Purpose of the call: Write the paragraph bank of 52 neutral filler paragraphs about research aims, methods, consortium work, dissemination, management, risk and a letter of support. No numbers, dates, organisation names or acronyms. Variable content only through the placeholders acronym and pA to pF.
* Full prompt: see SP03_generation_prompt.md
* Full output, as file names with SHA 256 checksums:
  * SP03_paragraph_bank.md: 2b8cdee9589f69469573406acd04d3efa7e08985ca2584718d5880b4480608dd
* Where the output is used: Free text boxes of the form (Parts A to F and the annexes) and the body of the letter of support. The selection and order of paragraphs per box was drawn with a seed by SP03_draw_data.py and is stored in SP03_data.yaml under boxes and letter.
* Model and interface details: (to be filled in by the researcher)

## Entry 2. Short texts that are not facts

* Date and time of the output: 25 October 2026, 19:54 UTC
* Purpose of the call: Write the short phrases of the annex forms (work package titles, deliverable titles, risk descriptions and mitigations), the labels, guidance texts and declarations of the form, the fixed sentences of the letter of support, and the descriptions of the difficulties and failure modes for the manifest.
* Full prompt: see SP03_generation_prompt.md
* Full output, as file names with SHA 256 checksums:
  * SP03_draw_data.py: 8ca0751de2b5e2764203a88e2cb5fe0fefd1a46f09d955573f072cb39f9c909d
  * SP03_template/form.tex.j2: 849913216b1e56ed2b1d8777f041ae5039ed2e91504a32dc8cbed94f679bb9f1
  * SP03_template/letter.tex.j2: 9e59f4a6a738296d19c17f35dbea6f86477b3563ed81030a55a9cfa623d1482c
* Where the output is used: Annex forms, form labels and guidance, letter of support, SP03_manifest.csv. The prose check scans the annex phrases and fails the build on any number, date, organisation name, acronym or dash.
* Model and interface details: (to be filled in by the researcher)

## Entry 3. Scripts and templates

* Date and time of the output: 25 October 2026, 19:54 UTC
* Purpose of the call: Write the code that draws the values from a seed, renders the form and the letter, generates the images, degrades SP03A into SP03B, writes the answer key, manifest, partner register and human step material, writes the gold set in the extraction schema, verifies the outputs and rebuilds everything with one command.
* Full prompt: see SP03_generation_prompt.md
* Full output, as file names with SHA 256 checksums:
  * SP03_draw_data.py: 8ca0751de2b5e2764203a88e2cb5fe0fefd1a46f09d955573f072cb39f9c909d
  * SP03_images.py: 59d4612eff591e70abc1077a866acae2f75421a7b18812d73bc0274ed748e13c
  * SP03_degrade.py: 5474277f87da62ff6f242346da3eb5d7bfe38ce492bce13122d5defdc4296d51
  * SP03_make_keys.py: 9f37f89a36afcce719cf2d08ec7888751856015ad95cd4d2a419e8708acd7377
  * SP03_verify.py: b005870e1e605cfe6095b4454ca59f931ab66884c39ba7a1856970a218c6b98b
  * build.py: 0ffb84e51c133039af46eb38a84e133ab2d466ac5cfa2aacc87e7a35f3e9d3de
  * build: c30df5b77ed403e04ffe4c026e69e291eb1bc9736d874b13ea53bc6315aaf094
  * SP03_template/preamble.tex: 9dacece5ba4f2b1feaaa8f3726bfa92fdc6993ce7e6a67b5480802328c9bd111
* Where the output is used: The build. None of this code calls a language model.
* Model and interface details: (to be filled in by the researcher)

## Entry 4. Documentation

* Date and time of the output: 26 October 2026, 08:14 UTC
* Purpose of the call: Write the datasheet, the changelog and the environment note.
* Full prompt: see SP03_generation_prompt.md
* Full output, as file names with SHA 256 checksums:
  * SP03_datasheet.md: 195fc36c268a3fcb825400bdcc07b19e94a63cf4c1d8fe920b492e6a6c6bf41d
  * CHANGELOG.md: bad5acb49a92f1647ce58b9dd96b70e380dab3df8f05a2556b76529e3431ed2d
  * SP03_environment_note.md: 7e371f45774a682747ab4179e70e606519a2779b2996f3f7f79c42ae799ce861
* Where the output is used: Documentation delivered with SP03.
* Model and interface details: (to be filled in by the researcher)
