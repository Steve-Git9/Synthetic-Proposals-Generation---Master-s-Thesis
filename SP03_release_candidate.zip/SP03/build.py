#!/usr/bin/env python3
"""One command rebuilds SP03A and SP03B and every generated file.

    ./build                      rebuild into this folder
    ./build --out DIR            rebuild into another folder
    ./build --check-determinism  build twice and compare checksums
    ./build --checksums-only     rewrite SP03_checksums.txt only

The build reads only stored files: SP03_data.yaml, SP03_template/, SP03_paragraph_bank.md
and fonts/. It never calls a language model.
"""
import argparse
import datetime
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import jinja2
import yaml
from pypdf import PdfWriter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import SP03_degrade  # noqa: E402
import SP03_images  # noqa: E402
import SP03_make_keys  # noqa: E402
import SP03_verify  # noqa: E402

TEX_MAP = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_",
           "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}

GENERATED = ["SP03A.pdf", "SP03B.pdf", "SP03_degradation_log.csv", "SP03_answer_key.json", "SP03_gold.json",
             "SP03_manifest.csv", "SP03_partner_register.csv", "SP03_name_check_list.md",
             "SP03_legibility_record.md", "SP03_blind_extraction_form.md", "SP03_human_steps_checklist.md",
             "SP03_verification_report.txt"]
STORED = ["SP03_data.yaml", "SP03_paragraph_bank.md", "SP03_draw_data.py", "SP03_images.py",
          "SP03_degrade.py", "SP03_make_keys.py", "SP03_verify.py", "build.py", "build",
          "SP03_template/preamble.tex", "SP03_template/form.tex.j2", "SP03_template/letter.tex.j2",
          "fonts/caveat-latin-700-normal.woff", "fonts/Caveat_OFL_LICENSE.txt",
          "SP03_generation_log.md", "SP03_generation_prompt.md", "requirements.lock",
          "SP03_environment_note.md", "CHANGELOG.md", "SP03_datasheet.md"]


def tex(s):
    return "".join(TEX_MAP.get(c, c) for c in str(s))


def num(s):
    return tex(s).replace(" ", "~")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sh(cmd, cwd, env=None):
    proc = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout[-4000:] + proc.stderr[-2000:])
        raise SystemExit(f"command failed: {' '.join(cmd)}")
    return proc


def render(env, name, data, para):
    tpl = env.get_template(name)
    return tpl.render(d=data, para=para)


def build(out, verify=True):
    out = Path(out)
    work = out / "work"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    data_path = HERE / "SP03_data.yaml"
    data = yaml.safe_load(data_path.read_text(encoding="utf-8"))
    bank_path = HERE / "SP03_paragraph_bank.md"

    # 1. prose check, fails the build
    probs, n = SP03_verify.check_prose(bank_path, data)
    if probs:
        raise SystemExit("prose check failed:\n  " + "\n  ".join(probs))
    print(f"prose check passed ({n} paragraphs)")

    # 2. images
    SP03_images.main(data_path, work / "images")

    # 3. render the templates
    bank = SP03_verify.load_bank(bank_path)
    subs = {"acronym": data["project"]["acronym"], **{f"p{p['key']}": p["short_name"] for p in data["partners"]}}

    def para(pid):
        text = re.sub(r"\{\{(\w+)\}\}", lambda m: subs[m.group(1)], bank[pid][1])
        return tex(text)

    jenv = jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(HERE / "SP03_template")),
        block_start_string="<%", block_end_string="%>",
        variable_start_string="<<", variable_end_string=">>",
        comment_start_string="<#", comment_end_string="#>",
        trim_blocks=True, lstrip_blocks=True, keep_trailing_newline=True,
        undefined=jinja2.StrictUndefined, extensions=["jinja2.ext.do"])
    jenv.filters["tex"] = tex
    jenv.filters["num"] = num
    shutil.copy(HERE / "SP03_template" / "preamble.tex", work / "preamble.tex")
    (work / "form.tex").write_text(render(jenv, "form.tex.j2", data, para), encoding="utf-8")
    (work / "letter.tex").write_text(render(jenv, "letter.tex.j2", data, para), encoding="utf-8")

    # 4. compile, with fixed dates so that a rebuild gives identical files
    epoch = int(datetime.datetime.fromisoformat(data["meta"]["release_date_iso"]).replace(tzinfo=datetime.timezone.utc).timestamp())
    env = dict(os.environ, SOURCE_DATE_EPOCH=str(epoch), FORCE_SOURCE_DATE="1")
    for name in ("letter", "form"):
        sh(["xelatex", "-interaction=nonstopmode", "-halt-on-error", f"{name}.tex"], work, env)

    # 5. merge the letter in front of the form, set metadata, write SP03A
    w = PdfWriter()
    w.append(str(work / "letter.pdf"))
    w.append(str(work / "form.pdf"))
    md = data["meta"]["pdf_metadata"]["A"]
    stamp = "D:" + data["meta"]["release_date_iso"].replace("-", "") + "000000Z"
    w.add_metadata({"/Title": md["title"], "/Author": md["author"], "/Subject": md["subject"],
                    "/Creator": "SP03 build script", "/Producer": "SP03 build script (xelatex, pypdf)",
                    "/CreationDate": stamp, "/ModDate": stamp})
    with open(out / "SP03A.pdf", "wb") as fh:
        w.write(fh)
    print("SP03A.pdf written, pages:", len(w.pages))

    # 6. SP03B from SP03A
    SP03_degrade.run(out / "SP03A.pdf", data_path, out / "SP03B.pdf", out / "SP03_degradation_log.csv", work)
    print("SP03B.pdf written")

    # 7. answer key, manifest, partner register, name check list
    SP03_make_keys.main(data_path, out)

    # 8. verification
    ok = True
    if verify:
        results = SP03_verify.run_all(out / "SP03A.pdf", out / "SP03B.pdf", data_path, out / "SP03_answer_key.json",
                                      out / "SP03_degradation_log.csv", bank_path, work)
        lines = ["SP03 automatic verification report", ""]
        for cid, name, status, detail in results:
            lines.append(f"[{status}] {cid} {name}")
            lines.append(f"        {detail}")
        ok = all(r[2] == "PASS" for r in results)
        lines += ["", "Overall: " + ("all automatic checks passed" if ok else "at least one automatic check failed"), ""]
        (out / "SP03_verification_report.txt").write_text("\n".join(lines), encoding="utf-8")
        print("\n".join(lines))
    return ok


def write_checksums(out):
    out = Path(out)
    names = [n for n in GENERATED + STORED if (out / n).exists() and n != "SP03_checksums.txt"]
    lines = [f"{sha256(out / n)}  {n}" for n in sorted(names)]
    (out / "SP03_checksums.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(HERE))
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--check-determinism", action="store_true")
    ap.add_argument("--checksums-only", action="store_true")
    a = ap.parse_args()
    if a.checksums_only:
        print(write_checksums(a.out), "checksums written")
        return
    if a.check_determinism:
        base = Path(tempfile.mkdtemp(prefix="sp03_det_"))
        sums = []
        for i in (1, 2):
            build(base / f"run{i}", verify=False)
            sums.append({n: sha256(base / f"run{i}" / n) for n in GENERATED if n != "SP03_verification_report.txt"
                         and (base / f"run{i}" / n).exists()})
        same = sums[0] == sums[1]
        for n in sums[0]:
            print(("same   " if sums[0][n] == sums[1][n] else "DIFFERS"), n, sums[0][n][:16])
        shutil.rmtree(base, ignore_errors=True)
        raise SystemExit(0 if same else 1)
    ok = build(a.out, verify=not a.no_verify)
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
