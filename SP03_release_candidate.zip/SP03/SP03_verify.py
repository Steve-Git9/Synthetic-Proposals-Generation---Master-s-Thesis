#!/usr/bin/env python3
"""Automatic verification of SP03 before release (section 11 of the task).

Checks:
  V1  text layer of SP03A holds every expected target value and distractor on the stated page,
      and the handwritten value is absent from the text layer
  V2  SP03B has no extractable text on any page
  V3  pairing: same page count, each SP03B page derives from the same SP03A page
  V4  consistency: partner amounts sum to the stated total, the struck value breaks the sum
  V5  filler: no paragraph or annex phrase contains a number, date, organisation name or acronym
  plus structure guards (headers, footers, page numbers, images, metadata, empty submission box)

Usage: python3 -I SP03_verify.py SP03A.pdf SP03B.pdf SP03_data.yaml SP03_answer_key.json SP03_degradation_log.csv bank.md workdir
"""
import csv
import json
import re
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml
from PIL import Image
from pypdf import PdfReader

MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august",
          "september", "october", "november", "december"]
NUMBER_WORDS = ["zero", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
                "eighteen", "nineteen", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
                "eighty", "ninety", "hundred", "thousand", "million", "first", "third", "fourth", "fifth"]
GENERIC = {"university", "institute", "research", "solutions", "systems", "sensor", "process",
           "regional", "development", "agency", "services", "applied", "sciences", "innovation",
           "for", "and", "of", "the"}


# ------------------------------------------------------------------ bank and prose
def load_bank(path):
    text = Path(path).read_text(encoding="utf-8")
    bank = {}
    for m in re.finditer(r"^## (P\d+) (\w+)\n(.+?)(?=\n## |\Z)", text, re.S | re.M):
        bank[m.group(1)] = (m.group(2), m.group(3).strip())
    return bank


def forbidden_tokens(data):
    toks = set()
    for p in data["partners"]:
        toks.add(p["org_name"].lower())
        toks.add(p["short_name"].lower())
        for w in re.findall(r"[A-Za-z]+", p["org_name"]):
            if w.lower() not in GENERIC and len(w) > 3 and w.lower() != "oy":
                toks.add(w.lower())
    toks.add(data["letter"]["company_name_variant"].lower())
    toks.add(data["project"]["acronym"].lower())
    toks.add(data["project"]["funding_programme"].lower())
    toks.update(f.lower() for f in data["project"]["funders_listed"])
    toks.update({"finland", "council", "rcf"})
    return toks


def prose_problems(label, text, toks):
    """Return a list of problems found in one piece of model written text."""
    probs = []
    body = re.sub(r"\{\{\w+\}\}", " ", text)
    if re.search(r"\d", body):
        probs.append(f"{label}: contains a digit")
    low = body.lower()
    for mth in MONTHS:
        if re.search(rf"\b{mth}\b", low) and mth != "may":
            probs.append(f"{label}: month name {mth}")
    for w in NUMBER_WORDS:
        if re.search(rf"\b{w}\b", low):
            probs.append(f"{label}: number word {w}")
    for m in re.finditer(r"\b[A-Z]{2,}\b", body):
        probs.append(f"{label}: acronym {m.group(0)}")
    for t in toks:
        if re.search(rf"\b{re.escape(t)}\b", low):
            probs.append(f"{label}: name from the data file {t}")
    if re.search(r"[-–—]", body):
        probs.append(f"{label}: contains a dash")
    return probs


def check_prose(bank_path, data):
    bank = load_bank(bank_path)
    toks = forbidden_tokens(data)
    probs = []
    if not 40 <= len(bank) <= 60:
        probs.append(f"paragraph bank has {len(bank)} paragraphs, expected 40 to 60")
    valid = {"acronym", "pA", "pB", "pC", "pD", "pE", "pF"}
    for pid, (cat, text) in bank.items():
        probs += prose_problems(pid, text, toks)
        for ph in re.findall(r"\{\{(\w+)\}\}", text):
            if ph not in valid:
                probs.append(f"{pid}: unknown placeholder {ph}")
    annex = data["annex"]
    for wp in annex["work_packages"]:
        probs += prose_problems(f"work package title {wp['number']}", wp["title"], toks)
    for dl in annex["deliverables"]:
        probs += prose_problems(f"deliverable {dl['id']}", dl["title"], toks)
    for rk in annex["risks"]:
        probs += prose_problems(f"risk {rk['id']} description", rk["description"], toks)
        probs += prose_problems(f"risk {rk['id']} mitigation", rk["mitigation"], toks)
    # every selected paragraph must exist in the bank
    for pg, bxs in data["boxes"].items():
        for b in bxs:
            for pid in b["paras"]:
                if pid not in bank:
                    probs.append(f"page {pg} box {b['code']}: unknown paragraph {pid}")
    for pid in data["letter"]["paras_page1"] + data["letter"]["paras_page2"]:
        if pid not in bank:
            probs.append(f"letter: unknown paragraph {pid}")
    return probs, len(bank)


# ------------------------------------------------------------------ pdf helpers
def norm(s):
    s = s.replace(" ", " ").replace(" ", " ").replace(" ", " ")
    return re.sub(r"\s+", " ", s).strip()


def pages_text(pdf):
    out = subprocess.run(["pdftotext", "-raw", str(pdf), "-"], capture_output=True, check=True).stdout.decode("utf-8", "replace")
    pages = out.split("\f")
    if pages and pages[-1].strip() == "":
        pages = pages[:-1]
    return [norm(p) for p in pages]


def image_counts(pdf):
    out = subprocess.run(["pdfimages", "-list", str(pdf)], capture_output=True, check=True).stdout.decode()
    counts = {}
    for line in out.splitlines()[2:]:
        parts = line.split()
        if parts and parts[0].isdigit():
            counts[int(parts[0])] = counts.get(int(parts[0]), 0) + 1
    return counts


def font_count(pdf):
    out = subprocess.run(["pdffonts", str(pdf)], capture_output=True, check=True).stdout.decode()
    return max(0, len(out.strip().splitlines()) - 2)


def eur_to_cents(s):
    digits = re.sub(r"[^\d]", "", s)
    return int(digits) * 100


# ------------------------------------------------------------------ the checks
def run_all(pdf_a, pdf_b, data_path, key_path, log_path, bank_path, workdir):
    d = yaml.safe_load(Path(data_path).read_text(encoding="utf-8"))
    key = json.loads(Path(key_path).read_text(encoding="utf-8"))
    results = []

    def rec(cid, name, ok, detail=""):
        results.append((cid, name, "PASS" if ok else "FAIL", detail))

    total = d["meta"]["total_pages"]
    footer = norm(d["meta"]["footer_text"])
    ta = pages_text(pdf_a)
    tb = pages_text(pdf_b)

    # ---- V5 filler
    probs, n_par = check_prose(bank_path, d)
    rec("V5", f"Filler check, {n_par} paragraphs and annex phrases scanned", not probs,
        "; ".join(probs[:8]) if probs else "no number, date, organisation name, acronym or dash found")

    # ---- structure guards
    rec("S1", "SP03A page count", len(ta) == total, f"{len(ta)} pages, expected {total}")
    hc = d["header_codes"]
    pm = d["page_map"]
    exp_code = {}
    for part, code in [("part_A", "A"), ("part_B", "B"), ("part_C", "C"), ("part_D", "D"), ("part_E", "E"), ("part_F", "F")]:
        for p in pm[part]:
            exp_code[p] = code
    for p in pm["annex_work_packages"] + pm["annex_deliverables"] + pm["annex_risks"]:
        exp_code[p] = "G"
    bad = []
    for p in range(3, total + 1):
        t = ta[p - 1] if p - 1 < len(ta) else ""
        code = exp_code[p]
        if hc[code][0] not in t or hc[code][1] not in t:
            bad.append(f"page {p} header")
        if f"Page {p} of {total}" not in t:
            bad.append(f"page {p} number")
        if footer not in t:
            bad.append(f"page {p} footer")
    for p in (1, 2):
        t = ta[p - 1] if p - 1 < len(ta) else ""
        if footer not in t or d["letter"]["numbering"][p - 1] not in t:
            bad.append(f"letter page {p} footer or numbering")
        if d["letter"]["company_name_variant"] not in t:
            bad.append(f"letter page {p} company name")
    rec("S2", "Headers, footers and page numbers on every page of SP03A", not bad, "; ".join(bad[:8]) or "all pages carry the expected header, footer and number")
    imgs = image_counts(pdf_a)
    ok_img = imgs.get(21, 0) >= 1 and imgs.get(2, 0) >= 1 and imgs.get(30, 0) >= 2
    rec("S3", "Images present in SP03A (correction p21, signature p2, signature and stamp p30)", ok_img, str({k: imgs.get(k, 0) for k in (2, 21, 30)}))
    sub_ok = bool(re.search(r"A\.7 Date of submission Entered at submission\.", ta[2])) if len(ta) > 2 else False
    rec("S4", "Date of submission box is empty on page 3", sub_ok, "label is followed directly by its guidance text" if sub_ok else "unexpected text in the box")

    meta_ok, meta_detail = True, []
    for letter, pdf in (("A", pdf_a), ("B", pdf_b)):
        md = PdfReader(str(pdf)).metadata
        fields = [str(md.get("/Title", "")), str(md.get("/Author", "")), str(md.get("/Subject", ""))]
        blob = " ".join(fields).lower()
        ok = "sp03" in blob and f"version letter {letter.lower()}" in blob and "synthetic" in blob
        for f in fields[:1]:
            ok = ok and f"SP03{letter}" in f
        meta_ok &= ok
        meta_detail.append(f"SP03{letter}: " + ("ok" if ok else "missing"))
    rec("S5", "PDF metadata states ID, version letter and the word synthetic", meta_ok, "; ".join(meta_detail))

    # ---- V1 text layer SP03A
    miss, checked = [], 0

    def has(page, surface):
        return page is not None and page - 1 < len(ta) and norm(surface) in ta[page - 1]

    for f in key["fields"]:
        if f["surface"] is None:
            for dd in f["distractors"]:
                checked += 1
                if not has(dd["page"], dd["surface"]):
                    miss.append(f"{f['field']} distractor {dd['surface']} p{dd['page']}")
            continue
        if f["field"] in ("trl_start", "trl_target", "mcrl_start", "mcrl_target"):
            continue
        checked += 1
        if not has(f["page"], f["surface"]):
            miss.append(f"{f['field']} p{f['page']} {f['surface']}")
        for dd in f["distractors"]:
            checked += 1
            if not has(dd["page"], dd["surface"]):
                miss.append(f"{f['field']} distractor {dd['surface']} p{dd['page']}")
    labels = {"trl_start": r"C\.17\.1 Technology readiness level \(TRL\) at project start (\d+)",
              "trl_target": r"C\.17\.2 Technology readiness level \(TRL\) at project end \(target\) (\d+)",
              "mcrl_start": r"C\.19\.1 MCRL at project start (\d+)",
              "mcrl_target": r"C\.19\.2 MCRL at project end \(target\) (\d+)"}
    for f in key["fields"]:
        if f["field"] in labels:
            checked += 1
            m = re.search(labels[f["field"]], ta[f["page"] - 1])
            if not m or int(m.group(1)) != f["value"]:
                miss.append(f"{f['field']} p{f['page']}")
    for pt in key["partners"]:
        nm, am = pt["organisation_name"], pt["requested_amount"]
        checked += 1
        if not has(nm["page"], nm["value"]):
            miss.append(f"partner {pt['partner']} name p{nm['page']}")
        for dd in nm["distractors"]:
            checked += 1
            if not has(dd["page"], dd["surface"]):
                miss.append(f"partner {pt['partner']} name distractor {dd['surface']}")
        if am["location_type"] != "handwriting":
            checked += 1
            if not has(am["page"], am["surface"]):
                miss.append(f"partner {pt['partner']} amount {am['surface']} p{am['page']}")
        for dd in am["distractors"]:
            checked += 1
            if not has(dd["page"], dd["surface"]):
                miss.append(f"partner {pt['partner']} amount distractor {dd['surface']} p{dd['page']}")
    rec("V1a", f"Text layer of SP03A holds all {checked} expected strings on their pages", not miss, "; ".join(miss[:8]) or "all found")
    hw = next(pt for pt in key["partners"] if pt["partner"] == "D")["requested_amount"]["surface"]
    where = [i + 1 for i, t in enumerate(ta) if re.search(rf"(?<![\d,]){re.escape(hw)}(?![\d])", t)]
    rec("V1b", "Handwritten value is absent from the text layer of SP03A", not where, f"value {hw}; found on pages {where}" if where else f"value {hw} not found on any page")

    # ---- V2 SP03B has no text
    nonempty = [i + 1 for i, t in enumerate(tb) if t.strip()]
    pypdf_text = [i + 1 for i, pg in enumerate(PdfReader(str(pdf_b)).pages) if (pg.extract_text() or "").strip()]
    rec("V2", "SP03B contains no extractable text on any page", not nonempty and not pypdf_text and font_count(pdf_b) == 0,
        f"pdftotext pages with text {nonempty}; pypdf pages with text {pypdf_text}; fonts {font_count(pdf_b)}")

    # ---- V3 pairing
    from SP03_degrade import rasterise
    import hashlib
    wd = Path(workdir)
    ra = rasterise(pdf_a, wd / "verify_raster_A")
    rb = rasterise(pdf_b, wd / "verify_raster_B")
    rows = list(csv.DictReader(open(log_path, encoding="utf-8")))
    probs3 = []
    if len(PdfReader(str(pdf_a)).pages) != len(PdfReader(str(pdf_b)).pages):
        probs3.append("page counts differ")
    margins = []

    def small(img):
        return np.asarray(img.convert("L").resize((155, 219), Image.BILINEAR), dtype=float)

    def corr(x, y):
        x, y = x - x.mean(), y - y.mean()
        den = np.sqrt((x * x).sum() * (y * y).sum())
        return float((x * y).sum() / den) if den else 0.0

    for i, row in enumerate(rows):
        if hashlib.sha256(ra[i].read_bytes()).hexdigest() != row["source_page_raster_sha256"]:
            probs3.append(f"page {i + 1} source hash differs")
        ang = float(row["rotation_angle_deg"]) * (1 if row["rotation_direction"] == "counterclockwise" else -1)
        b = Image.open(rb[i]).convert("RGB").rotate(-ang, resample=Image.BICUBIC, fillcolor=(255, 255, 255))
        if row["rotated_180"] == "yes":
            b = b.transpose(Image.ROTATE_180)
        sb = small(b)
        own = corr(small(Image.open(ra[i])), sb)
        others = [corr(small(Image.open(ra[j])), sb) for j in (i - 1, i + 1) if 0 <= j < len(ra)]
        margins.append(own - max(others))
        if own < 0.80 or own <= max(others):
            probs3.append(f"page {i + 1} correlation {own:.3f} not above neighbours {max(others):.3f}")
    rec("V3", "Pairing: same page count, each SP03B page derives from the same SP03A page", not probs3 and len(rows) == total,
        "; ".join(probs3[:6]) or f"hashes match; smallest margin over neighbouring pages {min(margins):.4f}")

    # ---- V4 consistency
    stated_txt = re.search(r"D\.2 Total funding requested (EUR [\d ]+\d)", ta[pm["grid_page"] - 1])
    e2_txt = re.search(r"For \w+, the requested funding amounts to (EUR [\d ]+\d) for the whole", ta[pm["e2_page"] - 1])
    ok4 = bool(stated_txt and e2_txt)
    detail4 = "could not parse the total or E.2 from the text layer"
    if ok4:
        stated = eur_to_cents(stated_txt.group(1))
        e2 = eur_to_cents(e2_txt.group(1))
        vals = {pt["partner"]: pt["requested_amount"]["value"] for pt in key["partners"]}
        struck = next(dd for dd in next(pt for pt in key["partners"] if pt["partner"] == "D")["requested_amount"]["distractors"]
                      if "struck" in dd["meaning"])["surface"]
        struck_c = round(float(struck.replace(" ", "").replace(",", ".")) * 100000)
        s_ok = sum(vals.values()) == stated and vals["C"] == e2
        s_bad = sum(vals.values()) - vals["D"] + struck_c != stated
        ok4 = s_ok and s_bad
        detail4 = (f"stated total {stated}; sum of partners {sum(vals.values())}; E.2 amount {e2} equals the amount of partner C: {vals['C'] == e2}; "
                   f"sum with the struck value {sum(vals.values()) - vals['D'] + struck_c} differs from the stated total: {s_bad}")
    rec("V4", "Consistency: partner amounts sum to the stated total and the struck value breaks the sum", ok4, detail4)
    # ---- G1 gold set
    gold_path = Path(key_path).parent / "SP03_gold.json"
    gold = json.loads(gold_path.read_text(encoding="utf-8"))
    fmap = {f["field"]: f for f in key["fields"]}
    g_probs = []
    if list(gold) != ["proposal", "proposal_facts", "partners", "metadata"]:
        g_probs.append("top level keys differ from the schema")
    if list(gold["proposal"]) != ["proposal_acronym", "proposal_title", "call_identifier", "submission_date"]:
        g_probs.append("proposal keys differ")
    if list(gold["proposal_facts"]) != ["requested_total_cents", "trl_start", "trl_target", "mcrl_start", "mcrl_target"]:
        g_probs.append("proposal_facts keys differ")
    pairs = [(gold["proposal"]["proposal_acronym"], fmap["proposal_acronym"]["value"]),
             (gold["proposal"]["proposal_title"], fmap["proposal_title"]["value"]),
             (gold["proposal"]["call_identifier"], fmap["call_identifier"]["value"]),
             (gold["proposal"]["submission_date"], fmap["submission_date"]["value"]),
             (gold["proposal_facts"]["requested_total_cents"], fmap["stated_total_requested_amount"]["value"]),
             (gold["proposal_facts"]["trl_start"], fmap["trl_start"]["value"]),
             (gold["proposal_facts"]["trl_target"], fmap["trl_target"]["value"]),
             (gold["proposal_facts"]["mcrl_start"], fmap["mcrl_start"]["value"]),
             (gold["proposal_facts"]["mcrl_target"], fmap["mcrl_target"]["value"])]
    g_probs += [f"value mismatch {a!r} vs {b!r}" for a, b in pairs if a != b]
    kp = [(x["organisation_name"]["value"], x["requested_amount"]["value"]) for x in key["partners"]]
    gp = [(x["partner_name"], x["requested_cents"]) for x in gold["partners"]]
    if kp != gp:
        g_probs.append("partner list differs from the answer key")
    if sum(x["requested_cents"] for x in gold["partners"]) != gold["proposal_facts"]["requested_total_cents"]:
        g_probs.append("partner amounts do not sum to the total")
    if not all(isinstance(x["requested_cents"], int) for x in gold["partners"]):
        g_probs.append("amount not an integer")
    rec("G1", "Gold set has the schema structure and agrees with the answer key", not g_probs,
        "; ".join(g_probs) or f"{len(gold['partners'])} partners, total {gold['proposal_facts']['requested_total_cents']} cents, submission date null")
    return results


if __name__ == "__main__":
    a, b, dp, kp, lp, bp, wd = sys.argv[1:8]
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    res = run_all(a, b, dp, kp, lp, bp, wd)
    for cid, name, status, detail in res:
        print(f"[{status}] {cid} {name}\n        {detail}")
    sys.exit(0 if all(r[2] == "PASS" for r in res) else 1)
