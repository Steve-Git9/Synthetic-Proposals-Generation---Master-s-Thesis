#!/usr/bin/env python3
"""Draw every SP03 value with a fixed seed and write SP03_data.yaml.

Run once to author the data file. The build script never calls this script
and never calls a language model: it reads only SP03_data.yaml, the template
and the paragraph bank.

Usage: python3 -I SP03_draw_data.py
"""
import random
import re
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
SEED = 20270315
rng = random.Random(SEED)
TOTAL_PAGES = 45
FOOTER = "Synthetic document for research purposes, ID SP03, version 1.0"


# ---------------------------------------------------------------- helpers
def group(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def fmt_k(eur: int) -> str:
    assert eur % 100 == 0
    k, rest = divmod(eur, 1000)
    return f"{group(k)},{rest // 100}"


def fmt_eur(eur: int) -> str:
    return group(eur)


def r100(x: float) -> int:
    return int(round(x / 100.0)) * 100


def parse_bank():
    text = (HERE / "SP03_paragraph_bank.md").read_text(encoding="utf-8")
    bank = {}
    for m in re.finditer(r"^## (P\d+) (\w+)\n(.+?)(?=\n## |\Z)", text, re.S | re.M):
        bank[m.group(1)] = (m.group(2), m.group(3).strip())
    return bank


BANK = parse_bank()
assert 40 <= len(BANK) <= 60, len(BANK)


def pool(*cats):
    return [i for i, (c, _) in BANK.items() if c in cats]


def pick(cats, n):
    return rng.sample(pool(*cats), n)


# ---------------------------------------------------------------- project
project = {
    "acronym": "RESENSE",
    "title": "Adaptive Sensor Networks for Resource Efficient Process Monitoring",
    "call_id": f"RCF2027/{rng.randrange(1000, 9999):04d}",
    "funding_programme": "Research Council of Finland",
    "funders_listed": [
        "Aurora Technology Foundation",
        "Research Council of Finland",
        "Polar Industry Cooperation Fund",
    ],
    "start_date_printed": "15.3.2027",
    "start_date_iso": "2027-03-15",
    "end_date_printed": "2029-03-14",
    "end_date_iso": "2029-03-14",
    "duration_months": 24,
    "submission_date": None,
    "letter_date_printed": "2 February 2027",
    "letter_date_iso": "2027-02-02",
    "signature_date_printed": "2 February 2027",
    "signature_date_iso": "2027-02-02",
}
trl_start = rng.choice([2, 3, 4])
trl_target = trl_start + rng.choice([2, 3])
mcrl_start = rng.choice([1, 2, 3])
mcrl_target = mcrl_start + rng.choice([2, 3])
project.update(trl_start=trl_start, trl_target=trl_target,
               mcrl_start=mcrl_start, mcrl_target=mcrl_target)

# ---------------------------------------------------------------- partners
partner_defs = [
    ("A", "university", "Torvenmaa University", "TMU",
     ["Campus Lane 5", "99010 Northhaven", "Finland"], "Principal investigator"),
    ("B", "university",
     "Haldeberg University of Applied Sciences and Regional Innovation Services",
     "HBU", ["Research Avenue 12", "99120 Eastbridge", "Finland"], "Project manager"),
    ("C", "research organisation", "Kestrel Institute for Process Research", "KPRI",
     ["Laboratory Road 8", "99230 Kestrelby", "Finland"], "Research coordinator"),
    ("D", "company", "Ormenfield Process Systems Oy", "OPS",
     ["Industry Street 21", "99340 Ormenfield", "Finland"], "Head of development"),
    ("E", "company", "Vantora Sensor Solutions Oy", "VSS",
     ["Technology Park 3", "99510 Vantoraville", "Finland"], "Business development manager"),
    ("F", "public body", "Ostermark Regional Development Agency", "ORDEA",
     ["Harbour Square 9", "99650 Ostermark", "Finland"], "Programme coordinator"),
]
LETTER_VARIANT_E = "Vantora Sensor Solutions Ltd"

# requested funding of the five funded partners, in whole euro
total_target = r100(rng.uniform(650_000, 1_300_000))
weights = [rng.uniform(0.8, 1.6) for _ in range(5)]
req = [max(90_000, r100(total_target * w / sum(weights))) for w in weights]
# partner C must not be a multiple of 1000 so that full euro text carries information
if req[2] % 1000 == 0:
    req[2] += 700
req_by = dict(zip("ABCDE", req))
req_by["F"] = 0

rate = {"university": (0.70, 0.85), "research organisation": (0.70, 0.85),
        "company": (0.35, 0.55)}
costs_by, own_by = {}, {}
for key, ptype, *_ in partner_defs:
    if key == "F":
        costs_by[key] = r100(rng.uniform(20_000, 60_000))
        own_by[key] = costs_by[key]
    else:
        lo, hi = rate[ptype]
        c = r100(req_by[key] / rng.uniform(lo, hi))
        if c <= req_by[key]:
            c = req_by[key] + 10_000
        costs_by[key] = c
        own_by[key] = c - req_by[key]
    assert req_by[key] < costs_by[key] or key == "F"

total_req = sum(req_by.values())
assert 500_000 <= total_req <= 1_500_000, total_req

# partner D: printed (struck) amount versus handwritten corrected amount
delta = r100(rng.uniform(8_000, 25_000))
struck = req_by["D"] + (delta if rng.random() < 0.5 else -delta)
assert struck > 0 and struck != req_by["D"]
corrected_str = fmt_k(req_by["D"])
struck_str = fmt_k(struck)

research_unit_budget = rng.randrange(8_000_000, 40_000_000, 50_000)
in_kind = rng.randrange(15_000, 60_000, 500)

partners = []
for key, ptype, org, short, addr, role in partner_defs:
    partners.append({
        "key": key, "type": ptype, "org_name": org, "short_name": short,
        "address": addr, "contact_role": role,
        "requests_funding": key != "F",
        "costs_cents": costs_by[key] * 100,
        "own_cents": own_by[key] * 100,
        "requested_cents": req_by[key] * 100,
    })

# ---------------------------------------------------------------- grid
def cell(key):
    return {"costs": fmt_k(costs_by[key]), "own": fmt_k(own_by[key])}

grid_rows = []
for key in "ABC":
    c = cell(key)
    c["req"] = "see E.2" if key == "C" else fmt_k(req_by[key])
    c["partner"] = key
    grid_rows.append(c)
sub = {
    "costs": fmt_k(sum(costs_by[k] for k in "ABC")),
    "own": fmt_k(sum(own_by[k] for k in "ABC")),
    "req": fmt_k(sum(req_by[k] for k in "ABC")),
}
tot = {
    "costs": fmt_k(sum(costs_by.values())),
    "own": fmt_k(sum(own_by.values())),
    "req": fmt_k(total_req),
}
grid = {
    "header_scale": "(1 000 EUR)",
    "type_groups": [
        {"label": "Universities", "partners": ["A", "B"]},
        {"label": "Research organisation", "partners": ["C"]},
        {"label": "Companies", "partners": ["D", "E"]},
        {"label": "Public body", "partners": ["F"]},
    ],
    "rows": {},
    "subtotal_label": "Subtotal, research partners",
    "subtotal": sub,
    "total_label": "Total",
    "total": tot,
}
for key in "ABCDEF":
    c = cell(key)
    if key == "C":
        c["req"] = "see E.2"
    elif key == "D":
        c["req_struck"] = struck_str
        c["req_handwritten"] = corrected_str
    else:
        c["req"] = fmt_k(req_by[key])
    grid["rows"][key] = c

# the handwritten value must not be printed anywhere in the text layer
printed = []
for key, c in grid["rows"].items():
    printed += [c["costs"], c["own"], c.get("req", ""), c.get("req_struck", "")]
printed += [sub["costs"], sub["own"], sub["req"], tot["costs"], tot["own"], tot["req"]]
assert corrected_str not in printed, "handwritten value collides with a printed value"
assert printed.count(struck_str) == 1

# ---------------------------------------------------------------- filler boxes
PARTNER_PARA = {"A": "P19", "B": "P20", "C": "P21", "D": "P22", "E": "P23", "F": "P24"}
boxes = {}

def add(page, code, title, paras):
    boxes.setdefault(page, []).append({"code": code, "title": title, "paras": paras})

for i, key in enumerate("ABCDEF"):
    page = 4 + i
    add(page, "B.7", "Role of the organisation in the project",
        [PARTNER_PARA[key]] + pick(["consortium", "management"], 1))
    add(page, "B.8", "Experience and resources",
        pick(["consortium", "management", "methods"], 2))

add(10, "C.1", "Summary of the project", pick(["aims"], 3))
add(10, "C.2", "Background and need", pick(["aims"], 3))
add(10, "C.3", "Objectives", pick(["aims"], 3))
add(11, "C.4", "Methodology", pick(["methods"], 3))
add(11, "C.5", "Structure of the work plan", ["P46"] + pick(["methods"], 2))
add(11, "C.6", "Evaluation approach", pick(["methods"], 3))
add(12, "C.7", "Consortium and division of roles", pick(["consortium"], 3))
add(12, "C.8", "Project management", pick(["management"], 3))
add(12, "C.9", "Quality assurance", pick(["methods", "management"], 3))
add(13, "C.10", "Expected impact", pick(["aims"], 3))
add(13, "C.11", "Dissemination of results", pick(["dissemination"], 3))
add(13, "C.12", "Exploitation of results", pick(["dissemination"], 3))
add(14, "C.13", "Risk assessment", pick(["risk"], 3))
add(14, "C.14", "Ethical and legal aspects", ["P17"] + pick(["risk", "management"], 2))
add(14, "C.15", "Data management", pick(["methods", "dissemination"], 3))
add(15, "C.16", "Starting point of the technology", pick(["methods", "aims"], 3))
add(16, "C.18", "Market context", pick(["aims"], 3))
add(17, "C.20", "Involvement of users", ["P14"] + pick(["methods", "management"], 2))
add(17, "C.21", "Open science practices", pick(["dissemination"], 3))
add(17, "C.22", "Sustainability of the results", pick(["aims", "dissemination"], 3))
add(18, "C.23", "Training and teaching", pick(["dissemination"], 3))
add(18, "C.24", "Cooperation with networks", pick(["dissemination", "consortium"], 3))
add(18, "C.25", "Contingency planning", pick(["risk"], 3))
add(19, "C.26", "Technical risks", pick(["risk"], 3))
add(19, "C.27", "Organisational risks", pick(["risk", "management"], 3))
add(19, "C.28", "Legal and contractual risks", pick(["risk"], 3))
add(20, "C.29", "Summary of expected results", pick(["aims", "methods"], 3))
add(20, "C.30", "Plans after the project period", pick(["dissemination"], 3))
add(20, "C.31", "Additional information", pick(["aims", "methods", "management"], 3))

add(22, "D.4", "Notes on the budget", pick(["management"], 3))
add(22, "D.5", "Principles of cost sharing", pick(["management", "consortium"], 3))
add(23, "D.6", "Personnel costs", pick(["management", "methods"], 3))
add(23, "D.7", "Equipment and consumables", pick(["methods"], 3))
add(23, "D.8", "Travel and dissemination costs", pick(["dissemination"], 3))
add(24, "D.9", "Subcontracting and purchased services", pick(["methods"], 3))
add(24, "D.10", "Other costs", pick(["methods", "management"], 2))
add(24, "D.11", "Comments on the financing plan", pick(["management"], 3))

add(25, "E.1", "General justification of costs", pick(["management"], 3))
add(25, "E.1.1", "Justification of personnel costs", pick(["methods", "management"], 3))
add(25, "E.1.2", "Justification of equipment costs", pick(["methods"], 3))
add(26, "E.2.1", "Justification of subcontracting", pick(["methods"], 3))
add(26, "E.2.2", "Justification of travel", pick(["dissemination"], 3))
add(27, "E.3.1", "Value for money", pick(["management", "aims"], 3))
add(27, "E.3.2", "Cost monitoring", pick(["management"], 3))
add(27, "E.3.3", "Cost risks", pick(["risk"], 3))
add(28, "E.4.1", "Other justifications", pick(["management", "methods"], 3))
add(28, "E.4.2", "Contribution of partners from outside the funded group", pick(["consortium"], 3))
add(28, "E.4.3", "Additional remarks", pick(["management"], 3))

# annex content
wp_titles = ["Project management and coordination", "Requirements and use cases",
             "Sensor unit design", "Data processing and analysis", "System integration",
             "Laboratory validation", "Field demonstration", "Dissemination and exploitation"]
short_names = [p["short_name"] for p in partners]
wps = []
for i, title in enumerate(wp_titles, start=1):
    if i in (1, 8):
        s, e = 1, 24
    else:
        s = rng.randint(1, 14)
        e = rng.randint(s + 5, 24)
    lead = short_names[0] if i == 1 else rng.choice(short_names)
    others = rng.sample([n for n in short_names if n != lead], rng.randint(2, 4))
    wps.append({"number": i, "title": title, "start_month": s, "end_month": e,
                "lead": lead, "participants": [lead] + others})
    pg = 30 + i
    add(pg, f"W{i}.1", "Objectives", pick(["aims", "methods"], 2))
    add(pg, f"W{i}.2", "Description of the work", pick(["methods"], 3))
    add(pg, f"W{i}.3", "Expected results", pick(["dissemination", "aims"], 2))

deliv_titles = [
    ("Management plan and reporting templates", 1, "Report"),
    ("Consortium agreement summary", 1, "Report"),
    ("Use case catalogue", 2, "Report"),
    ("Requirements specification", 2, "Report"),
    ("Interface specification", 3, "Report"),
    ("Sensor unit design report", 3, "Report"),
    ("Prototype sensor unit", 3, "Prototype"),
    ("Data processing toolkit", 4, "Software"),
    ("Description of analysis methods", 4, "Report"),
    ("Integrated prototype", 5, "Prototype"),
    ("Installation guide", 5, "Report"),
    ("Evaluation framework", 6, "Report"),
    ("Laboratory validation report", 6, "Report"),
    ("Field demonstration plan", 7, "Report"),
    ("Field demonstration report", 7, "Report"),
    ("Open dataset description", 7, "Dataset"),
    ("Training material", 8, "Other"),
    ("Guide for practitioners", 8, "Report"),
    ("Exploitation plan", 8, "Report"),
    ("Final project report", 8, "Report"),
]
counter = {}
deliverables = []
for title, wpn, dtype in deliv_titles:
    counter[wpn] = counter.get(wpn, 0) + 1
    wp = wps[wpn - 1]
    due = rng.randint(max(wp["start_month"] + 3, 4), wp["end_month"])
    deliverables.append({
        "id": f"D{wpn}.{counter[wpn]}", "title": title, "wp": wpn, "type": dtype,
        "lead": wp["lead"], "level": rng.choice(["Public", "Public", "Confidential"]),
        "due_month": due,
    })
for i in range(4):
    add(39 + i, f"L{i + 1}", "Notes on the deliverables", pick(["management"], 2))

risk_defs = [
    ("Delay in the delivery of components", "Early ordering and alternative suppliers"),
    ("Limited access to production sites", "Laboratory work planned to proceed independently"),
    ("Loss of key personnel", "Documentation, shared responsibilities and deputies"),
    ("Poor quality of measurement data", "Validation checks at the point of collection"),
    ("Incompatible interfaces between components", "Early agreement on open interfaces"),
    ("Low adoption of the results by users", "Users involved throughout the work"),
    ("Gradual drift in the scope of work", "Review of changes in the steering group"),
    ("Equipment failure in the field", "Redundant units and spare parts"),
    ("Slow agreement on ownership of results", "Consortium agreement concluded at an early stage"),
]
levels = ["Low", "Medium", "High"]
risks = []
for i, (desc, mit) in enumerate(risk_defs, start=1):
    risks.append({"id": f"R{i}", "description": desc, "likelihood": rng.choice(levels),
                  "impact": rng.choice(levels), "mitigation": mit,
                  "owner": rng.choice(short_names)})
for i in range(3):
    add(43 + i, f"K{i + 1}", "Notes on the risk register", pick(["risk"], 2))

# extra filler boxes for pages 3 and 29, drawn with a separate generator so that
# all other draws stay unchanged
rng2 = random.Random(SEED + 3)
boxes.setdefault(3, []).append({"code": "A.8", "title": "Short description of the project",
                                "paras": rng2.sample(pool("aims"), 3)})
boxes.setdefault(29, []).append({"code": "F.5", "title": "Additional declarations",
                                 "paras": rng2.sample(pool("management", "risk"), 3)})

boxes[15] += [{"code": "C.16.1", "title": "Previous development work", "paras": rng2.sample(pool("methods", "aims"), 3)},
              {"code": "C.16.2", "title": "Ownership of background knowledge", "paras": rng2.sample(pool("consortium", "management"), 3)}]
boxes[16] += [{"code": "C.18.1", "title": "Needs of customers", "paras": rng2.sample(pool("aims"), 3)},
              {"code": "C.18.2", "title": "Existing solutions", "paras": rng2.sample(pool("aims", "methods"), 3)}]

letter = {
    "company_name_variant": LETTER_VARIANT_E,
    "address": ["Technology Park 3", "99510 Vantoraville", "Finland"],
    "recipient": "The coordinating research unit",
    "subject_label": "Letter of support for the project",
    "role": "Authorised signatory",
    "in_kind_eur": in_kind,
    "in_kind_printed": f"EUR {fmt_eur(in_kind)}",
    "paras_page1": ["P47", "P48", "P49"],
    "paras_page2": ["P50", "P51", "P52"],
    "numbering": ["1/2", "2/2"],
}

# ---------------------------------------------------------------- images
def scribble(n_points, amplitude):
    pts, y = [], 0.5
    for i in range(n_points):
        x = 0.03 + 0.94 * i / (n_points - 1) + rng.uniform(-0.015, 0.015)
        y = min(0.85, max(0.15, y + rng.uniform(-amplitude, amplitude)))
        pts.append([round(x, 4), round(y, 4)])
    flourish = [[0.08, round(rng.uniform(0.82, 0.9), 4)],
                [0.35, round(rng.uniform(0.8, 0.9), 4)],
                [0.65, round(rng.uniform(0.78, 0.88), 4)],
                [0.96, round(rng.uniform(0.72, 0.84), 4)]]
    return {"points": pts, "flourish": flourish,
            "width_px": round(rng.uniform(4.0, 6.0), 2),
            "tilt_deg": round(rng.uniform(-4, 4), 2)}


def hw_chars(text, base):
    out = []
    for ch in text:
        out.append({"ch": ch,
                    "dx": round(rng.uniform(-3, 3), 2), "dy": round(rng.uniform(-4, 4), 2),
                    "scale": round(rng.uniform(0.92, 1.08), 3),
                    "rot_deg": round(rng.uniform(-5, 5), 2),
                    "stroke_px": rng.choice([0, 0, 1])})
    return {"text": text, "base_px": base, "chars": out}


images = {
    "seed": SEED,
    "handwriting_font": {
        "name": "Caveat Bold",
        "file": "fonts/caveat-latin-700-normal.woff",
        "source": "npm package @fontsource/caveat version 5.3.0",
        "licence": "SIL Open Font License 1.1",
        "licence_file": "fonts/Caveat_OFL_LICENSE.txt",
    },
    "stamp_font": {"name": "DejaVu Sans Bold",
                   "licence": "Bitstream Vera licence with DejaVu changes, free to use"},
    "correction": {
        "ink_rgb": [18, 40, 140],
        "value": hw_chars(corrected_str, 110),
        "initials": hw_chars("x.k.", 56),
        "initials_offset_px": [round(rng.uniform(8, 20), 1), round(rng.uniform(-6, 6), 1)],
        "line_tilt_deg": round(rng.uniform(-3, 3), 2),
        "underline": True,
    },
    "signature_letter": scribble(16, 0.30),
    "signature_form": scribble(14, 0.28),
    "stamp": {
        "size_px": 420,
        "rgb": [150, 30, 70],
        "rotation_deg": round(rng.uniform(-18, -8), 2),
        "top_text": "COORDINATING OFFICE",
        "bottom_text": "VERIFIED",
        "centre_text": "SEAL",
        "ring_px": [round(rng.uniform(7, 9), 1), round(rng.uniform(3, 4), 1)],
        "ink_dropout": round(rng.uniform(0.04, 0.08), 3),
        "dropout_seed": rng.randrange(2 ** 31),
    },
}

# ---------------------------------------------------------------- degradation
blur_pages = sorted(rng.sample(range(1, TOTAL_PAGES + 1), 3))
degradation = {
    "dpi": 150,
    "order_of_operations": ["rotate_180_if_flagged", "rotate_small_angle", "blur_if_selected",
                            "gaussian_noise", "jpeg_compression"],
    "blur_radius_px": 0.7,
    "blur_pages": blur_pages,
    "rotate_180_pages": [15],
    "pages": {},
}
for p in range(1, TOTAL_PAGES + 1):
    degradation["pages"][p] = {
        "angle_deg": round(rng.uniform(0.5, 2.0) * rng.choice([-1, 1]), 3),
        "noise_sigma": round(rng.uniform(4.0, 9.0), 2),
        "noise_seed": rng.randrange(2 ** 31),
        "jpeg_quality": rng.randint(60, 75),
        "blur": p in blur_pages,
        "rotate_180": p == 15,
    }

# ---------------------------------------------------------------- page map
page_map = {
    "letter": [1, 2], "part_A": [3], "part_B": list(range(4, 10)),
    "part_C": list(range(10, 21)), "part_D": [21, 22, 23, 24],
    "part_E": [25, 26, 27, 28], "part_F": [29, 30],
    "annex_work_packages": list(range(31, 39)),
    "annex_deliverables": list(range(39, 43)),
    "annex_risks": list(range(43, 46)),
    "partner_pages": {"A": 4, "B": 5, "C": 6, "D": 7, "E": 8, "F": 9},
    "trl_page": 15, "mcrl_page": 16, "grid_page": 21, "unit_budget_page": 22,
    "e2_page": 26, "signature_page": 30,
}
header_codes = {
    "A": ("Form 7A", "Part A, General information"),
    "B": ("Form 7B", "Part B, Partner information"),
    "C": ("Form 7C", "Part C, Project description"),
    "D": ("Form 7D", "Part D, Budget"),
    "E": ("Form 7E", "Part E, Justification of costs"),
    "F": ("Form 7F", "Part F, Declarations and signature"),
    "G": ("Form 7G", "Annexes"),
}

# ---------------------------------------------------------------- targets (answer key source)
E2_TEXT_AMOUNT = f"EUR {fmt_eur(req_by['C'])}"
partner_targets = []
for p in partners:
    key = p["key"]
    pg = page_map["partner_pages"][key]
    row = grid["rows"][key]
    if key == "C":
        amt = {"page": page_map["e2_page"], "location_type": "text",
               "surface": E2_TEXT_AMOUNT,
               "authority_rule": "Grid cell refers to section E.2, so the amount stated in text in E.2 is authoritative"}
    elif key == "D":
        amt = {"page": page_map["grid_page"], "location_type": "handwriting",
               "surface": corrected_str,
               "authority_rule": "Handwritten correction is authoritative, the struck printed amount is never used"}
    else:
        amt = {"page": page_map["grid_page"], "location_type": "table",
               "surface": row["req"],
               "authority_rule": "Budget grid is authoritative for partner amounts"}
    dist = [
        {"page": page_map["grid_page"], "surface": row["costs"], "meaning": "total costs of the partner"},
        {"page": page_map["grid_page"], "surface": row["own"], "meaning": "own contribution of the partner"},
    ]
    if key == "D":
        dist.insert(0, {"page": page_map["grid_page"], "surface": struck_str,
                        "meaning": "printed requested amount that is struck through"})
    if key == "E":
        dist.append({"page": 2, "surface": letter["in_kind_printed"],
                     "meaning": "in kind support stated in the letter of support"})
    if key == "C":
        dist.append({"page": page_map["grid_page"], "surface": "see E.2",
                     "meaning": "reference text in the grid cell, not a value"})
    partner_targets.append({
        "partner": key,
        "short_name": p["short_name"],
        "name": {"value": p["org_name"], "page": pg, "location_type": "text",
                 "surface": p["org_name"],
                 "authority_rule": "Name as written in the Organisation name box of the Part B form",
                 "distractors": [
                     {"page": pg, "surface": p["short_name"], "meaning": "short name box"},
                     {"page": page_map["grid_page"], "surface": p["short_name"], "meaning": "short name in the budget grid"},
                 ] + ([{"page": 1, "surface": LETTER_VARIANT_E,
                        "meaning": "third name variant in the letter of support"}] if key == "E" else [])},
        "requested_amount": {"value_cents": req_by[key] * 100, **amt, "distractors": dist},
    })

distractor_dates = [
    {"page": 1, "surface": project["letter_date_printed"], "meaning": "date of the letter of support"},
    {"page": page_map["signature_page"], "surface": project["signature_date_printed"], "meaning": "date of signature box"},
    {"page": 3, "surface": project["start_date_printed"], "meaning": "project start date"},
    {"page": 3, "surface": project["end_date_printed"], "meaning": "project end date"},
]
targets = [
    {"field": "proposal_acronym", "value": project["acronym"], "page": 3, "location_type": "text",
     "surface": project["acronym"], "authority_rule": "Part A box A.1", "distractors": []},
    {"field": "proposal_title", "value": project["title"], "page": 3, "location_type": "text",
     "surface": project["title"], "authority_rule": "Part A box A.2, the title wraps onto two lines and is recorded as one string",
     "distractors": []},
    {"field": "call_identifier", "value": project["call_id"], "page": 3, "location_type": "text",
     "surface": project["call_id"], "authority_rule": "Part A box A.3", "distractors": []},
    {"field": "funding_programme", "value": project["funding_programme"], "page": 3, "location_type": "text",
     "surface": project["funding_programme"],
     "authority_rule": "The ticked entry of the funder list in Part A box A.4",
     "distractors": [
         {"page": 3, "surface": project["funders_listed"][0], "meaning": "funder listed but not ticked"},
         {"page": 3, "surface": project["funders_listed"][2], "meaning": "funder listed but not ticked"}]},
    {"field": "submission_date", "value": None, "page": None, "location_type": None, "surface": None,
     "authority_rule": "The Date of submission box is empty, so the value is null and no other date may be used",
     "distractors": distractor_dates},
    {"field": "stated_total_requested_amount", "value_cents": total_req * 100, "page": page_map["grid_page"],
     "location_type": "text", "surface": f"EUR {fmt_eur(total_req)}",
     "authority_rule": "The box Total funding requested is authoritative for the stated total",
     "distractors": [
         {"page": page_map["grid_page"], "surface": sub["req"], "meaning": "requested funding in the subtotal row for research partners"},
         {"page": page_map["unit_budget_page"], "surface": f"EUR {fmt_eur(research_unit_budget)}", "meaning": "annual budget of the coordinating research unit"},
         {"page": 2, "surface": letter["in_kind_printed"], "meaning": "in kind support in the letter of support"},
         {"page": page_map["grid_page"], "surface": tot["costs"], "meaning": "total costs in the total row"},
         {"page": page_map["grid_page"], "surface": tot["own"], "meaning": "own contribution in the total row"}],
     "equivalent_representations": [
         {"page": page_map["grid_page"], "surface": tot["req"],
          "meaning": "requested funding in the total row of the grid, in thousand euro"}]},
    {"field": "trl_start", "value": trl_start, "page": 15, "location_type": "text", "surface": str(trl_start),
     "authority_rule": "Part C labelled box on page 15", "distractors": []},
    {"field": "trl_target", "value": trl_target, "page": 15, "location_type": "text", "surface": str(trl_target),
     "authority_rule": "Part C labelled box on page 15", "distractors": []},
    {"field": "mcrl_start", "value": mcrl_start, "page": 16, "location_type": "text", "surface": str(mcrl_start),
     "authority_rule": "Part C labelled box on page 16", "distractors": []},
    {"field": "mcrl_target", "value": mcrl_target, "page": 16, "location_type": "text", "surface": str(mcrl_target),
     "authority_rule": "Part C labelled box on page 16", "distractors": []},
]

non_target_strings = [
    {"surface": FOOTER, "pages": "1 to 45", "meaning": "footer on every page, known non target string"},
    {"surface": grid["subtotal_label"], "pages": "21", "meaning": "subtotal row of the budget grid, not a partner"},
    {"surface": "Page N of 45", "pages": "3 to 45", "meaning": "page number in the footer of the form pages"},
    {"surface": "1/2 and 2/2", "pages": "1 to 2", "meaning": "own page numbering of the letter of support"},
]

difficulties = [
    {"item": 1, "issue": "#6 and #7", "sources": "K, V, D", "page": "1 to 45, page 15 rotated by 180 degrees",
     "field": "all fields",
     "description": "SP03B is a rasterised copy at 150 dpi without text layer, with seeded rotation, noise, JPEG compression, light blur on three pages and page 15 upside down",
     "failure": "Converter without OCR returns no text; OCR errors on digits and decimal commas; upside down page missed or misread; skewed table lines break cell detection",
     "version": "B"},
    {"item": 2, "issue": "#2", "sources": "V, D", "page": "3 to 45", "field": "all fields",
     "description": "Form style layout with section codes, numbered boxes, form headers and key and value boxes instead of narrative sections",
     "failure": "Labels and values are mismatched; values in boxes are missed because the structure is not narrative",
     "version": "both"},
    {"item": 3, "issue": "#5", "sources": "D", "page": "1 to 2", "field": "partner E requested amount; submission date; partner E name",
     "description": "A letter of support with its own letterhead and own page numbering is merged in front of the form",
     "failure": "Values from the letter (in kind amount, letter date, name variant) are taken as target values; letter page numbers are confused with PDF pages",
     "version": "both"},
    {"item": 4, "issue": "#6 and #26", "sources": "K, V, D, M", "page": "21", "field": "partner D requested amount",
     "description": "The printed amount of partner D is struck through and a handwritten corrected amount with initials is placed next to it as an image",
     "failure": "The struck printed value is reported; the handwriting is not recognised; the value is reported as missing",
     "version": "both"},
    {"item": 5, "issue": "#9 and #11", "sources": "T, V, D", "page": "21", "field": "partner requested amounts; stated total",
     "description": "Budget grid with merged header cells, merged partner type cells, a subtotal row for research partners, a total row and partners shown by short name only",
     "failure": "Wrong column assigned; subtotal read as a partner; values shifted between rows; short name not linked to the official name",
     "version": "both"},
    {"item": 6, "issue": "#14", "sources": "T, K", "page": "21", "field": "partner requested amounts; stated total",
     "description": "The grid header states the scale (1 000 EUR) and the cells show bare numbers with one decimal and a comma as decimal separator",
     "failure": "Amounts reported in thousands instead of euro; decimal comma read as a thousands separator",
     "version": "both"},
    {"item": 7, "issue": "#15 and #16", "sources": "V, T, K", "page": "2, 21, 22", "field": "partner requested amounts; stated total",
     "description": "In kind amount in the letter, total costs and own contribution next to requested funding, and a large unrelated annual budget of the coordinating research unit",
     "failure": "Total costs, own contribution, in kind amount or unit budget reported as requested funding or as total requested",
     "version": "both"},
    {"item": 8, "issue": "#18 and #27", "sources": "T, M", "page": "21, 26", "field": "partner C requested amount",
     "description": "The grid cell for requested funding of partner C reads see E.2 and the amount is stated in full euro in the text of section E.2",
     "failure": "Reported as missing or zero; the reference is not followed; grid scale applied to the amount in E.2",
     "version": "both"},
    {"item": 9, "issue": "#20", "sources": "K", "page": "1, 4 to 9, 21", "field": "partner names",
     "description": "Official name in the Organisation name box, short name in the Short name box and the grid, and a third variant with a different legal form suffix in the letter of support",
     "failure": "Short name or letter variant returned instead of the official name; partners matched wrongly against the register",
     "version": "both"},
    {"item": 10, "issue": "#21", "sources": "K, V", "page": "1, 3, 30", "field": "submission date (distractor dates)",
     "description": "Dates appear in three formats: 15.3.2027, 2029-03-14 and 2 February 2027",
     "failure": "Dates misread across formats; day and month swapped in 15.3.2027; a date reported as the submission date",
     "version": "both"},
    {"item": 11, "issue": "#22", "sources": "V, D", "page": "3, 5", "field": "proposal title; partner B name",
     "description": "The proposal title wraps onto two lines in its box and the official name of partner B wraps onto two lines in its box",
     "failure": "Value truncated at the line break; lines merged with text of a neighbouring box",
     "version": "both"},
    {"item": 12, "issue": "#24 and #29", "sources": "K, V, D, M", "page": "3", "field": "submission date",
     "description": "The Date of submission box is empty, while the letter date, the signature date and the project dates are distractors",
     "failure": "A date from elsewhere is returned instead of null",
     "version": "both"},
    {"item": 13, "issue": "#24", "sources": "K, V, D", "page": "9, 21", "field": "partner F requested amount",
     "description": "Partner F has a Part B form with Requests funding ticked no and appears in the grid with 0,0",
     "failure": "Partner omitted, or reported with null instead of zero",
     "version": "both"},
]

data = {
    "meta": {
        "document_id": "SP03", "version": "1.0", "versions": ["A", "B"],
        "release_date_iso": "2026-10-25", "master_seed": SEED, "total_pages": TOTAL_PAGES,
        "language": "English, European spelling", "footer_text": FOOTER,
        "pdf_metadata": {
            "A": {"title": "SP03A, synthetic form style application, clean version 1.0",
                  "author": "Synthetic document generator for research purposes",
                  "subject": "ID SP03, version letter A, version 1.0, synthetic document for research purposes"},
            "B": {"title": "SP03B, synthetic form style application, scanned copy version 1.0",
                  "author": "Synthetic document generator for research purposes",
                  "subject": "ID SP03, version letter B, version 1.0, synthetic document for research purposes"},
        },
        "notes": "Values drawn with SP03_draw_data.py. The build reads only this file, the template and the paragraph bank.",
    },
    "page_map": page_map,
    "header_codes": {k: list(v) for k, v in header_codes.items()},
    "project": project,
    "partners": partners,
    "letter": letter,
    "grid": grid,
    "e2": {"partner": "C", "text_amount": E2_TEXT_AMOUNT},
    "totals": {"stated_total_eur": total_req, "stated_total_printed": f"EUR {fmt_eur(total_req)}",
               "derived_total_cents": total_req * 100},
    "unit_budget": {"eur": research_unit_budget, "printed": f"EUR {fmt_eur(research_unit_budget)}"},
    "annex": {"work_packages": wps, "deliverables": deliverables, "risks": risks},
    "boxes": boxes,
    "images": images,
    "degradation": degradation,
    "targets": targets,
    "partner_targets": partner_targets,
    "non_target_strings": non_target_strings,
    "difficulties": difficulties,
}

out = HERE / "SP03_data.yaml"
out.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=110),
               encoding="utf-8")
print("wrote", out)
print("call id", project["call_id"], "| total", fmt_eur(total_req), "| struck", struck_str,
      "| corrected", corrected_str, "| C", E2_TEXT_AMOUNT, "| unit budget", fmt_eur(research_unit_budget),
      "| in kind", in_kind)
print("TRL", trl_start, trl_target, "MCRL", mcrl_start, mcrl_target, "| blur pages", blur_pages)
