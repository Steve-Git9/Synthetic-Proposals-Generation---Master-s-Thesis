# SP03 blind extraction form (HUMAN STEP 11.7, blank)

Instructions for the second person. Extract the values below from SP03A.pdf only. Do not open the answer key, the data file, the manifest or SP03B.pdf before you have finished. Write amounts as integers in euro cents, dates in ISO 8601, and write null for a field that is not stated in the document.

## Single fields

1. Proposal acronym:
2. Proposal title:
3. Call identifier:
4. Funding programme:
5. Submission date:
6. Stated total requested amount:
7. TRL start:
8. TRL target:
9. MCRL start:
10. MCRL target:

## Partners

List every partner of the consortium. For each, write the name as written in the Organisation name box of its Part B form and its requested amount.

* Partner slot 1. Name: ________  Requested amount: ________
* Partner slot 2. Name: ________  Requested amount: ________
* Partner slot 3. Name: ________  Requested amount: ________
* Partner slot 4. Name: ________  Requested amount: ________
* Partner slot 5. Name: ________  Requested amount: ________
* Partner slot 6. Name: ________  Requested amount: ________
* Partner slot 7. Name: ________  Requested amount: ________
* Partner slot 8. Name: ________  Requested amount: ________

## Notes of the second person

Write down anything that was ambiguous or that you had to decide yourself, with the page number.


## Comparison with the answer key (filled in by the researcher afterwards)

Every disagreement leads to a fix of the design or of the answer key until agreement is complete.

* Disagreement 1. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____
* Disagreement 2. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____
* Disagreement 3. Field: ____ Extractor value: ____ Key value: ____ Resolution: ____

Initial agreement rate: ____ of 22 values (10 single fields, 6 partner names, 6 partner amounts)
Final agreement rate after fixes: ____ of 22 values
Extractor and date:
