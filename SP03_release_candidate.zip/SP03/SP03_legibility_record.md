# SP03 legibility record for SP03B (HUMAN STEP 11.6)

Open SP03B.pdf and confirm for each value below that a person can still read it. A value that no human can read makes the test unfair, so the degradation must then be reduced in the data file and the document rebuilt as a new version. Record the outcome per value.

Special attention:

* Page 15 is rotated by 180 degrees. Turn the page and confirm that the readiness level boxes can be read.
* Page 21: the handwritten corrected amount of partner D and its initials, next to the struck printed amount.
* Light blur was applied to pages 37, 38, 42. Confirm that nothing on these pages is unreadable.

## Values

* proposal_acronym: RESENSE, page 3. Readable: yes / no. Note:
* proposal_title: Adaptive Sensor Networks for Resource Efficient Process Monitoring, page 3. Readable: yes / no. Note:
* call_identifier: RCF2027/6433, page 3. Readable: yes / no. Note:
* funding_programme: Research Council of Finland, page 3. Readable: yes / no. Note:
* submission_date: null, the Date of submission box on page 3 is empty. Readable as empty: yes / no. Note:
* stated_total_requested_amount: EUR 979 300, page 21. Readable: yes / no. Note:
* trl_start: 3, page 15. Readable: yes / no. Note:
* trl_target: 5, page 15. Readable: yes / no. Note:
* mcrl_start: 1, page 16. Readable: yes / no. Note:
* mcrl_target: 4, page 16. Readable: yes / no. Note:
* Partner A organisation name: Torvenmaa University, page 4. Readable: yes / no. Note:
* Partner A requested amount: 214,8, page 21, table. Readable: yes / no. Note:
* Partner B organisation name: Haldeberg University of Applied Sciences and Regional Innovation Services, page 5. Readable: yes / no. Note:
* Partner B requested amount: 159,8, page 21, table. Readable: yes / no. Note:
* Partner C organisation name: Kestrel Institute for Process Research, page 6. Readable: yes / no. Note:
* Partner C requested amount: EUR 241 200, page 26, text. Readable: yes / no. Note:
* Partner D organisation name: Ormenfield Process Systems Oy, page 7. Readable: yes / no. Note:
* Partner D requested amount: 167,1, page 21, handwriting. Readable: yes / no. Note:
* Partner E organisation name: Vantora Sensor Solutions Oy, page 8. Readable: yes / no. Note:
* Partner E requested amount: 196,4, page 21, table. Readable: yes / no. Note:
* Partner F organisation name: Ostermark Regional Development Agency, page 9. Readable: yes / no. Note:
* Partner F requested amount: 0,0, page 21, table. Readable: yes / no. Note:

## Outcome

* All values readable: yes / no
* Degradation reduced and document rebuilt as a new version: yes / no
* Checked by and date:
