#!/usr/bin/env python3
"""Generate the three kinds of image used in SP03 from SP03_data.yaml.

Outputs (PNG with transparency, text is part of the pixels, not a text layer):
  hw_correction.png   handwritten corrected amount with initials (partner D)
  sig_letter.png      signature scribble for the letter of support
  sig_form.png        signature scribble for Part F
  stamp.png           official looking but fictional stamp

No randomness is drawn here except one numpy generator seeded from the data
file (ink dropout of the stamp). All jitter values are stored in the data file.

Usage: python3 -I SP03_images.py [data.yaml] [output_dir]
"""
import math
import sys
from pathlib import Path

import numpy as np
import yaml
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
STAMP_FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
SS = 3  # supersampling factor


def crop_alpha(img, pad=6):
    bbox = img.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
    if not bbox:
        return img
    l, t, r, b = bbox
    return img.crop((max(0, l - pad), max(0, t - pad), min(img.width, r + pad), min(img.height, b + pad)))


def downsample(img, factor):
    return img.resize((max(1, img.width // factor), max(1, img.height // factor)), Image.LANCZOS)


def draw_jittered_text(canvas, font_path, spec, ink, origin, ss):
    """Draw text char by char with the stored jitter. Returns x end in canvas px."""
    x, y = origin
    base = spec["base_px"] * ss
    for c in spec["chars"]:
        size = max(8, int(base * c["scale"]))
        font = ImageFont.truetype(font_path, size)
        stroke = int(c["stroke_px"] * ss * 0.5)
        tile = Image.new("RGBA", (size * 2, size * 2), (0, 0, 0, 0))
        d = ImageDraw.Draw(tile)
        d.text((size // 2, size // 3), c["ch"], font=font, fill=ink + (255,),
               stroke_width=stroke, stroke_fill=ink + (255,))
        tile = tile.rotate(c["rot_deg"], resample=Image.BICUBIC, expand=False)
        canvas.alpha_composite(tile, (int(x + c["dx"] * ss - size // 2), int(y + c["dy"] * ss - size // 3)))
        x += font.getlength(c["ch"]) * 0.98
    return x


def make_correction(spec, font_path, out):
    ink = tuple(spec["ink_rgb"])
    W, H = 900 * SS // 2, 420 * SS // 2
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    x0, y0 = 40 * SS, 90 * SS
    x_end = draw_jittered_text(canvas, font_path, spec["value"], ink, (x0, y0), SS)
    # initials to the lower right of the value
    ox, oy = spec["initials_offset_px"]
    draw_jittered_text(canvas, font_path, spec["initials"], ink,
                       (x_end + ox * SS, y0 + 70 * SS + oy * SS), SS)
    if spec.get("underline"):
        d = ImageDraw.Draw(canvas)
        pts = []
        n = 40
        for i in range(n + 1):
            t = i / n
            xx = x0 + (x_end - x0) * t
            yy = y0 + 118 * SS + 4 * SS * math.sin(t * 5.0) + t * 6 * SS
            pts.append((xx, yy))
        d.line(pts, fill=ink + (255,), width=int(3.2 * SS), joint="curve")
    canvas = canvas.rotate(spec["line_tilt_deg"], resample=Image.BICUBIC, expand=True)
    img = downsample(crop_alpha(canvas, 8 * SS), SS)
    img.save(out)
    return img.size


def catmull_rom(points, samples_per_seg=18):
    pts = [points[0]] + points + [points[-1]]
    out = []
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = (np.array(pts[j], dtype=float) for j in (i - 1, i, i + 1, i + 2))
        for s in range(samples_per_seg):
            t = s / samples_per_seg
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t ** 2
                              + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    out.append(np.array(points[-1], dtype=float))
    return out


def make_signature(spec, out):
    W, H = 720 * SS, 260 * SS
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)
    ink = (20, 24, 72, 255)
    base = spec["width_px"] * SS * 0.9

    def stroke(points, wscale, loops):
        path = catmull_rom([[px * W, py * H] for px, py in points], samples_per_seg=60)
        n = len(path)
        prev = None
        for i, (x, y) in enumerate(path):
            t = i / n
            if loops:  # deterministic cursive loops
                x += 26 * SS * math.sin(t * 2 * math.pi * 11)
                y += 30 * SS * math.cos(t * 2 * math.pi * 11) - 30 * SS
            w = max(2.0, base * wscale * (0.6 + 0.4 * abs(math.sin(t * math.pi * 3.0))))
            if prev is not None:
                d.line([prev, (x, y)], fill=ink, width=int(w))
            d.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=ink)
            prev = (x, y)

    stroke(spec["points"], 1.0, True)
    stroke(spec["flourish"], 0.8, False)
    canvas = canvas.rotate(spec["tilt_deg"], resample=Image.BICUBIC, expand=True)
    img = downsample(crop_alpha(canvas, 8 * SS), SS)
    img.save(out)
    return img.size


def arc_text(canvas, text, font, centre, radius, start_deg, end_deg, rgb, upright_top):
    """Place characters along an arc. Angles in degrees, 0 = top, clockwise."""
    n = len(text)
    for i, ch in enumerate(text):
        a = start_deg + (end_deg - start_deg) * (i + 0.5) / n
        rad = math.radians(a)
        cx = centre[0] + radius * math.sin(rad)
        cy = centre[1] - radius * math.cos(rad)
        size = int(font.size * 2.2)
        tile = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        ImageDraw.Draw(tile).text((size / 2, size / 2), ch, font=font, fill=rgb + (255,), anchor="mm")
        rot = -a if upright_top else (180 - a)
        tile = tile.rotate(rot, resample=Image.BICUBIC, expand=False)
        canvas.alpha_composite(tile, (int(cx - size / 2), int(cy - size / 2)))


def make_stamp(spec, out):
    S = 2
    size = spec["size_px"] * S
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)
    rgb = tuple(spec["rgb"])
    c = size / 2
    outer = size * 0.46
    r1, r2 = spec["ring_px"]
    d.ellipse([c - outer, c - outer, c + outer, c + outer], outline=rgb + (255,), width=int(r1 * S))
    inner = outer * 0.72
    d.ellipse([c - inner, c - inner, c + inner, c + inner], outline=rgb + (255,), width=int(r2 * S))
    ring_font = ImageFont.truetype(STAMP_FONT, int(size * 0.075))
    mid_r = (outer + inner) / 2 - size * 0.005
    arc_text(canvas, spec["top_text"], ring_font, (c, c), mid_r, -105, 105, rgb, True)
    arc_text(canvas, spec["bottom_text"], ring_font, (c, c), mid_r + size * 0.02, 232, 128, rgb, False)
    # star separators
    for ang in (-118, 118):
        rad = math.radians(ang)
        sx, sy = c + mid_r * math.sin(rad), c - mid_r * math.cos(rad)
        pts = []
        for k in range(10):
            rr = size * (0.022 if k % 2 == 0 else 0.009)
            th = math.pi * k / 5 - math.pi / 2
            pts.append((sx + rr * math.cos(th), sy + rr * math.sin(th)))
        d.polygon(pts, fill=rgb + (255,))
    centre_font = ImageFont.truetype(STAMP_FONT, int(size * 0.12))
    d.text((c, c), spec["centre_text"], font=centre_font, fill=rgb + (255,), anchor="mm")
    d.line([(c - inner * 0.62, c - size * 0.085), (c + inner * 0.62, c - size * 0.085)], fill=rgb + (255,), width=int(2 * S))
    d.line([(c - inner * 0.62, c + size * 0.085), (c + inner * 0.62, c + size * 0.085)], fill=rgb + (255,), width=int(2 * S))
    # ink dropout, seeded
    arr = np.array(canvas)
    gen = np.random.default_rng(spec["dropout_seed"])
    mask = gen.random(arr.shape[:2]) < spec["ink_dropout"]
    arr[..., 3] = np.where(mask, (arr[..., 3] * 0.35).astype(np.uint8), arr[..., 3])
    arr[..., 3] = (arr[..., 3] * 0.88).astype(np.uint8)
    canvas = Image.fromarray(arr, "RGBA")
    canvas = canvas.rotate(spec["rotation_deg"], resample=Image.BICUBIC, expand=True)
    img = downsample(crop_alpha(canvas, 4 * S), S)
    img.save(out)
    return img.size


def main(data_path, out_dir):
    data = yaml.safe_load(Path(data_path).read_text(encoding="utf-8"))
    img = data["images"]
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    font_path = str((HERE / img["handwriting_font"]["file"]).resolve())
    sizes = {
        "hw_correction.png": make_correction(img["correction"], font_path, out_dir / "hw_correction.png"),
        "sig_letter.png": make_signature(img["signature_letter"], out_dir / "sig_letter.png"),
        "sig_form.png": make_signature(img["signature_form"], out_dir / "sig_form.png"),
        "stamp.png": make_stamp(img["stamp"], out_dir / "stamp.png"),
    }
    return sizes


if __name__ == "__main__":
    dp = sys.argv[1] if len(sys.argv) > 1 else str(HERE / "SP03_data.yaml")
    od = sys.argv[2] if len(sys.argv) > 2 else str(HERE / "work" / "images")
    for name, size in main(dp, od).items():
        print(name, size)
