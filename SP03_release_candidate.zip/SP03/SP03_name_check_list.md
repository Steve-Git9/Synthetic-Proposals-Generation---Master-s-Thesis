# SP03 name check list (HUMAN STEP)

Check every name below against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced in SP03_draw_data.py, followed by a rebuild and a new version.

## Organisation names

* Partner A: Torvenmaa University; TMU
* Partner B: Haldeberg University of Applied Sciences and Regional Innovation Services; HBU
* Partner C: Kestrel Institute for Process Research; KPRI
* Partner D: Ormenfield Process Systems Oy; OPS
* Partner E: Vantora Sensor Solutions Oy; VSS; Vantora Sensor Solutions Ltd
* Partner F: Ostermark Regional Development Agency; ORDEA

## Other names

* Project acronym: RESENSE
* Project title: Adaptive Sensor Networks for Resource Efficient Process Monitoring
* Funders listed in Part A, besides the real public funder: Aurora Technology Foundation; Polar Industry Cooperation Fund
* Stamp text: COORDINATING OFFICE, VERIFIED, SEAL

## Call identifier

* RCF2027/6433 (syntax RCF[year]/[four digits], must not exist)

## Checklist

* YTJ search done for each organisation name: open
* Web search done for each organisation name and the acronym: open
* Web search done for the call identifier: open
* Result recorded here, with date and name of the person who checked: open
