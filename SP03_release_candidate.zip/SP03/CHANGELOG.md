# Changelog

All changes after the freeze create a new version that is recorded here.

## Version 1.0, build candidate, 25 October 2026

* First complete build of SP03A (clean, born digital) and SP03B (degraded copy that simulates printing and scanning) with identical ground truth.
* Both versions have 45 pages. SP03A has a text layer. SP03B has none.
* All automatic checks of section 11 passed: text layer check of SP03A, absence of text in SP03B, pairing, consistency of the amounts, filler check. Two builds in different folders gave identical checksums.
* Added SP03_gold.json, the gold set in the structure of the extraction schema (proposal, proposal_facts, partners, metadata). It is written by the build from the data file and checked against the answer key by check G1. The PDFs are unchanged by this addition.
* Status: not frozen. The human steps for legibility of SP03B, blind second extraction, realism review and name check are open. The freeze (step 10 of section 11) follows after them.
