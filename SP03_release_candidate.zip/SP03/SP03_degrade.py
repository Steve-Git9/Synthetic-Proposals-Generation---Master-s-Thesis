#!/usr/bin/env python3
"""Produce SP03B (scanned copy) from SP03A.

Every page of SP03A is rasterised at 150 dpi and then, in this order:
  1. rotated by 180 degrees if flagged (page 15 only),
  2. rotated by a seeded small angle (0.5 to 2 degrees, seeded direction),
  3. blurred lightly if selected (three seeded pages),
  4. given seeded Gaussian noise,
  5. compressed as JPEG with a seeded quality (60 to 75).
The output PDF contains only the JPEG images and has no text layer.

All parameters come from SP03_data.yaml (section degradation) and are written
to SP03_degradation_log.csv, one row per page.

Usage: python3 -I SP03_degrade.py SP03A.pdf SP03_data.yaml SP03B.pdf SP03_degradation_log.csv workdir
"""
import csv
import hashlib
import io
import re
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml
from PIL import Image, ImageFilter
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, NameObject
from reportlab.pdfgen import canvas


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def rasterise(pdf, out_dir, dpi=150):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("*.png"):
        old.unlink()
    subprocess.run(["pdftoppm", "-r", str(dpi), "-png", str(pdf), str(out_dir / "p")], check=True)
    return sorted(out_dir.glob("p-*.png"))


def degrade_page(img, params, blur_radius):
    img = img.convert("RGB")
    if params["rotate_180"]:
        img = img.transpose(Image.ROTATE_180)
    img = img.rotate(params["angle_deg"], resample=Image.BICUBIC, expand=False, fillcolor=(255, 255, 255))
    if params["blur"]:
        img = img.filter(ImageFilter.GaussianBlur(blur_radius))
    arr = np.asarray(img, dtype=np.int16)
    gen = np.random.default_rng(params["noise_seed"])
    noise = gen.normal(0.0, params["noise_sigma"], size=arr.shape[:2])
    arr = np.clip(arr + noise[..., None], 0, 255).astype(np.uint8)
    return Image.fromarray(arr, "RGB")


def strip_font_declarations(src, dst, meta, release_iso):
    """ReportLab declares a default font on every page although no text is drawn.
    Remove the declaration so that the file holds only page images."""
    reader = PdfReader(str(src))
    writer = PdfWriter()
    for page_in in reader.pages:
        page = writer.add_page(page_in)
        data = page.get_contents().get_data()
        data = re.sub(rb"BT\s+/F\d+\s+[\d.]+\s+Tf\s+[\d.]+\s+TL\s+ET\s*", b"", data)
        res = page["/Resources"]
        if "/Font" in res:
            del res["/Font"]
        stream = DecodedStreamObject()
        stream.set_data(data)
        page[NameObject("/Contents")] = writer._add_object(stream)
    stamp = "D:" + release_iso.replace("-", "") + "000000Z"
    writer.add_metadata({"/Title": meta["title"], "/Author": meta["author"], "/Subject": meta["subject"],
                         "/Creator": "SP03 degradation script", "/Producer": "SP03 degradation script (reportlab, pypdf)",
                         "/CreationDate": stamp, "/ModDate": stamp})
    with open(dst, "wb") as fh:
        writer.write(fh)


def run(sp03a, data_path, out_pdf, out_log, workdir):
    data = yaml.safe_load(Path(data_path).read_text(encoding="utf-8"))
    deg = data["degradation"]
    meta = data["meta"]["pdf_metadata"]["B"]
    workdir = Path(workdir)
    rasters = rasterise(sp03a, workdir / "raster_A", deg["dpi"])
    jpeg_dir = workdir / "jpeg_B"
    jpeg_dir.mkdir(parents=True, exist_ok=True)
    assert len(rasters) == data["meta"]["total_pages"], (len(rasters), data["meta"]["total_pages"])

    tmp_pdf = workdir / "SP03B_raw.pdf"
    c = canvas.Canvas(str(tmp_pdf), pagesize=A4, invariant=1)
    c.setTitle(meta["title"])
    c.setAuthor(meta["author"])
    c.setSubject(meta["subject"])
    c.setCreator("SP03 degradation script")
    rows = []
    for i, path in enumerate(rasters, start=1):
        params = deg["pages"][i]
        src_bytes = path.read_bytes()
        img = degrade_page(Image.open(path), params, deg["blur_radius_px"])
        jpg = jpeg_dir / f"page_{i:02d}.jpg"
        img.save(jpg, "JPEG", quality=params["jpeg_quality"])
        c.drawImage(ImageReader(io.BytesIO(jpg.read_bytes())), 0, 0, width=A4[0], height=A4[1])
        c.showPage()
        rows.append({
            "page": i,
            "rotation_angle_deg": f"{abs(params['angle_deg']):.3f}",
            "rotation_direction": "counterclockwise" if params["angle_deg"] > 0 else "clockwise",
            "noise_sigma": params["noise_sigma"],
            "noise_seed": params["noise_seed"],
            "jpeg_quality": params["jpeg_quality"],
            "blur_applied": "yes" if params["blur"] else "no",
            "blur_radius_px": deg["blur_radius_px"] if params["blur"] else 0,
            "rotated_180": "yes" if params["rotate_180"] else "no",
            "source_page_raster_sha256": sha256_bytes(src_bytes),
            "output_jpeg_sha256": sha256_bytes(jpg.read_bytes()),
        })
    c.save()
    strip_font_declarations(tmp_pdf, out_pdf, meta, data["meta"]["release_date_iso"])
    with open(out_log, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    return rows


if __name__ == "__main__":
    a, dp, o, lg, wd = sys.argv[1:6]
    r = run(a, dp, o, lg, wd)
    print("pages", len(r))
