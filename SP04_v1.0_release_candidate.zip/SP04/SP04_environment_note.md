# SP04 environment note

Build environment used for version 1.0.

- Operating system: Ubuntu 24.04.5 LTS (Linux 6.18, x86_64)
- Python 3.13.17, pinned packages in `requirements.lock`
- PDF engine: WeasyPrint 70.0 (HTML and CSS to PDF), fonts embedded and subset
- Figures: matplotlib 3.11.2, PNG at 200 dpi, text rendered inside the image, no text layer
- Verification tools: poppler 24.02.0 (`pdftotext`, `pdfinfo`, `pdffonts`, `pdfimages`)

Fonts

- Document text: Inter (font file version 4.0, /usr/share/fonts/opentype/inter), embedded in the PDF
- Figure text: DejaVu Sans as bundled with matplotlib (version 2.37), rasterised into the figures

Reproducibility

- `SOURCE_DATE_EPOCH` is fixed to 1792972800 (2026-10-26T00:00:00Z) in `build.py`, which fixes the timestamps embedded in font subsets.
- The PDF identifier is derived from the SHA-256 of the HTML. Two consecutive builds gave byte identical PDFs (checked).
- Changing the operating system, fonts or library versions may change line breaks and therefore the page layout. Rebuild and run `./build` (which runs `verify.py`) after any such change.
- The build never calls a language model. It reads only `SP04_data.yaml`, `SP04_prose.yaml`, `SP04_paragraph_bank.md` and `SP04_template/`.
