"""Shared helpers for the SP04 build: data loading, formatting, paragraph bank and prose parsing."""
import re
import yaml
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MINUS = "−"  # true minus sign, used in Table 5.3


def load_data():
    with open(ROOT / "SP04_data.yaml", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_prose():
    with open(ROOT / "SP04_prose.yaml", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_bank():
    """Return list of dicts: id, tag, text."""
    text = (ROOT / "SP04_paragraph_bank.md").read_text(encoding="utf-8")
    out = []
    for m in re.finditer(r"^### (P\d+) \[(\w+)\]\n(.+?)(?=\n### |\Z)", text, flags=re.S | re.M):
        out.append(dict(id=m.group(1), tag=m.group(2), text=" ".join(m.group(3).split())))
    return out


# ------------------------------------------------------------------ formatting
def fmt_full(cents):
    """Full euro with thousands separator, e.g. 3,207,500 (cents must be whole euro)."""
    assert cents % 100 == 0
    return f"{cents // 100:,}"


def fmt_k(cents):
    """EUR thousand with one decimal, e.g. 2,946.1. Value must be a multiple of 100 euro."""
    assert cents % 10000 == 0, cents
    tenths = cents // 10000          # tenths of a thousand euro
    return f"{tenths // 10:,}.{tenths % 10}"


def fmt_k_signed(cents, style):
    """Change value in EUR thousand. Decreases: style 'minus' or 'paren'. Increases: no sign."""
    if cents == 0:
        return "0.0"
    if cents > 0:
        return fmt_k(cents)
    if style == "minus":
        return MINUS + fmt_k(-cents)
    return "(" + fmt_k(-cents) + ")"


def fmt_date_long(iso):
    import datetime
    d = datetime.date.fromisoformat(iso)
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
              "October", "November", "December"]
    return f"{d.day} {months[d.month - 1]} {d.year}"


NUMBER_WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight",
                9: "nine", 10: "ten"}


def partner_map(data):
    return {p["id"]: p for p in data["partners"]}


def derived(data):
    """Derived numbers and consistency values used by the build and the checks."""
    P = partner_map(data)
    cur = [p for p in data["partners"] if p["status"] == "current"]
    revised = {p["id"]: p["revised"]["requested_cents"] for p in cur}
    original = {p["id"]: p["original"]["requested_cents"] for p in data["partners"] if "original" in p}
    return dict(P=P, cur=cur, revised=revised, original=original,
                sum_revised=sum(revised.values()), sum_original=sum(original.values()))


def build_ctx(data):
    """Placeholder context for prose."""
    P = partner_map(data)
    T = data["totals"]
    ctx = dict(
        acronym=data["proposal"]["acronym"], title=data["proposal"]["title"], programme=data["funding_programme"],
        call_current=data["calls"]["current"], call_previous=data["calls"]["previous"],
        date_current=fmt_date_long(data["dates"]["submission_current"]),
        date_previous=fmt_date_long(data["dates"]["submission_previous"]),
        orig_total_full=fmt_full(T["original_total_requested_cents"]),
        rev_total_k=fmt_k(T["revised_total_requested_cents"]), tec_k=fmt_k(T["total_eligible_costs_cents"]),
        tb_k=fmt_k(T["total_budget_cents"]), tpc_k=fmt_k(T["total_project_cost_cents"]),
        n_partners_words=NUMBER_WORDS[len([p for p in data["partners"] if p["status"] == "current"])],
        n_wp_words=NUMBER_WORDS[len(data["work_packages"])],
        n_test_areas_words=NUMBER_WORDS[data["outputs"]["test_areas"]],
        mcrl_start=data["readiness"]["mcrl_start"],
        wp_acr_list=", ".join(w["acronym"] for w in data["work_packages"]),
        b_old_short=P["B"]["former_short_name"], b_old_legal=P["B"]["former_legal_name"], b_legal=P["B"]["legal_name"],
        wp1_acr=data["work_packages"][0]["acronym"],
        wp6_acr=data["work_packages"][5]["acronym"],
        wp6_lead_short=P[data["work_packages"][5]["lead"]]["short_name"],
    )
    for k, p in P.items():
        ctx[f"{k.lower()}_short"] = p["short_name"]
        ctx[f"{k.lower()}_legal"] = p["legal_name"]
    return ctx


class SafeCtx(dict):
    def __missing__(self, key):
        raise KeyError(f"prose placeholder not in data context: {key}")


def fill(template, ctx, **extra):
    c = SafeCtx(ctx)
    c.update(extra)
    return " ".join(template.split()).format_map(c)


def change_table(data):
    """Rows of Table 5.3: list of dicts (id, short_name, change_cents, style, text) and the total row."""
    P = partner_map(data)
    T = data["totals"]
    rows, n_dec = [], 0
    for k in "ABCDEFGH":
        x = P[k]
        rev = x["revised"]["requested_cents"] if x["status"] == "current" else 0
        org = x.get("original", {}).get("requested_cents", 0)
        ch = rev - org
        style = None
        if ch < 0:
            style = "minus" if n_dec % 2 == 0 else "paren"
            n_dec += 1
        rows.append(dict(id=k, short_name=x["short_name"], change_cents=ch, style=style, text=fmt_k_signed(ch, style)))
    tot = T["revised_total_requested_cents"] - T["original_total_requested_cents"]
    tstyle = "minus" if n_dec % 2 == 0 else "paren"
    total = dict(id="TOTAL", short_name="Total", change_cents=tot, style=tstyle, text=fmt_k_signed(tot, tstyle))
    return rows, total
