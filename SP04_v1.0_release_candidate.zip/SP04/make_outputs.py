#!/usr/bin/env python3
"""Generate the answer key, manifest, partner register and human step material from SP04_data.yaml.
Called by build.py. Pages are the planned pages in the data file; verify.py confirms them against the PDF."""
import csv
import json

import common
from common import MINUS, fmt_date_long, fmt_full, fmt_k

OUT = common.ROOT / "out"

AUTHORITY_RULES = [
    "Section 5.2 and Table 5.2 are authoritative for partner amounts and for the stated total requested amount.",
    "For partner H, the authoritative amount is eligible costs multiplied by the funding rate, both from Table 5.2.",
    "Table 5.1, Table 5.3, Figure 5.1, the executive summary and the cover's resubmission line are never authoritative for any target field.",
    "The call identifier and the submission date are those on the cover above the resubmission line.",
    "The partner name is the current legal name from the consortium table in section 2.1, without the 'formerly' part.",
    "Partner G is not a current partner and has no entry in the answer key.",
    "The TRL target is the value in Annex B, Table B2.",
    "The footer text is a non target string.",
]


def answer_key(data):
    L = data["layout"]
    T = data["totals"]
    P = common.partner_map(data)
    cur = [p for p in data["partners"] if p["status"] == "current"]
    ch_rows, ch_total = common.change_table(data)
    chg = {r["id"]: r for r in ch_rows}
    d = lambda round_, page, s, note="": dict(page=page, surface_string=s, round=round_, note=note)

    fields = []
    fields.append(dict(field="proposal_acronym", value=data["proposal"]["acronym"], page=1, location_type="text",
                       surface_string=data["proposal"]["acronym"], authority_rule="Cover page.",
                       distractors=[d("revised", L["sec2_1"], P["C"]["acronym"],
                                      "Acronym of partner C, contained in the proposal acronym. Not the proposal acronym."),
                                    d("revised", L["bridge_wp_description"], "BRIDGE",
                                      "Work package acronym that is also an ordinary English word. Not a partner or proposal acronym.")]))
    fields.append(dict(field="proposal_title", value=data["proposal"]["title"], page=1, location_type="text",
                       surface_string=data["proposal"]["title"], authority_rule="Cover page.", distractors=[]))
    fields.append(dict(field="call_identifier", value=data["calls"]["current"], page=1, location_type="text",
                       surface_string=data["calls"]["current"], authority_rule=AUTHORITY_RULES[3],
                       distractors=[d("original", 1, data["calls"]["previous"], "Previous call in the resubmission line on the cover.")]))
    fields.append(dict(field="funding_programme", value=data["funding_programme"], page=1, location_type="text",
                       surface_string=data["funding_programme"], authority_rule="Cover page.", distractors=[]))
    fields.append(dict(field="submission_date", value=data["dates"]["submission_current"], page=1, location_type="text",
                       surface_string=fmt_date_long(data["dates"]["submission_current"]), authority_rule=AUTHORITY_RULES[3],
                       distractors=[d("original", 1, fmt_date_long(data["dates"]["submission_previous"]),
                                      "Previous submission date in the resubmission line on the cover.")]))
    rt = T["revised_total_requested_cents"]
    fields.append(dict(
        field="stated_total_requested_amount", value=rt, unit="euro cents", page=L["table_5_2"], location_type="table",
        surface_string=fmt_k(rt), also_stated_in_text=f"EUR {fmt_k(rt)} thousand (sentence below Table 5.2)",
        scale_note="Table 5.2 states the scale only in its caption: all amounts in EUR thousand.",
        authority_rule=AUTHORITY_RULES[0],
        distractors=[
            d("original", L["exec_total_sentence"], f"EUR {fmt_full(T['original_total_requested_cents'])}",
              "Executive summary: original total, quoted as a total funding request."),
            d("original", L["table_5_1"], fmt_full(T["original_total_requested_cents"]), "Table 5.1 total, full euro."),
            d("revised", L["table_5_2"], fmt_k(T["total_eligible_costs_cents"]),
              "Total eligible costs in the total row of Table 5.2. Different quantity."),
            d("revised", L["table_5_4"], fmt_k(T["total_eligible_costs_cents"]), "Table 5.4 total eligible costs. Different quantity."),
            d("revised", L["table_5_4"], fmt_k(T["total_budget_cents"]), "Table 5.4 total budget. Different quantity."),
            d("revised", L["table_5_4"], fmt_k(T["total_project_cost_cents"]), "Table 5.4 total project cost. Different quantity."),
            d("revised", L["table_5_3"], ch_total["text"], "Change in the total (revised minus original). Never a target."),
        ]))
    fields.append(dict(field="trl_start", value=data["readiness"]["trl_start"], page=L["fig_1_2"], location_type="figure",
                       surface_string=f"Start of project: TRL {data['readiness']['trl_start']}",
                       authority_rule="Value appears only inside Figure 1.2 (image, no text layer).", distractors=[]))
    fields.append(dict(field="trl_target", value=data["readiness"]["trl_target"], page=L["table_b2"], location_type="table",
                       surface_string=str(data["readiness"]["trl_target"]),
                       row_label="Technology readiness level (TRL) at the end of the project",
                       authority_rule=AUTHORITY_RULES[6],
                       distractors=[d("revised", L["crossref_sentence"], "the target readiness level is given in Annex B, Table B2",
                                      "Cross reference sentence without a value.")]))
    fields.append(dict(field="mcrl_start", value=data["readiness"]["mcrl_start"], page=L["mcrl_start_sentence"], location_type="text",
                       surface_string=f"market and commercial readiness level (MCRL) of the proposed services is {data['readiness']['mcrl_start']}",
                       authority_rule="Section 4.2.", distractors=[]))
    fields.append(dict(field="mcrl_target", value=None, page=None, location_type=None, surface_string=None,
                       authority_rule="Not stated anywhere in the document. The correct extraction is null.", distractors=[]))

    partners = []
    for p in cur:
        r = p["revised"]
        legal_as_written = p["legal_name"] if p["id"] != "B" else f'{p["legal_name"]} (formerly {p["former_legal_name"]})'
        name_d = []
        if p["id"] == "B":
            name_d.append(d("original", L["table_5_1"], p["former_short_name"], "Old short name in Table 5.1."))
            name_d.append(d("original", L["sec2_1"], p["former_legal_name"], "Old legal name, in the formerly clause of the consortium table."))
        name_d.append(d("revised", L["table_5_2"], p["short_name"], "Short name used in Tables 5.2 and 5.3. Not the name as written."))
        amt_d = []
        if "original" in p:
            amt_d.append(d("original", L["table_5_1"], fmt_full(p["original"]["requested_cents"]), "Table 5.1, full euro."))
        amt_d.append(d("revised", L["fig_5_1"], fmt_k(r["requested_cents"]), "Figure 5.1 bar label. Not authoritative."))
        c = chg[p["id"]]
        amt_d.append(d("revised", L["table_5_3"], c["text"], "Change in requested funding (revised minus original). Never a target."))
        amt_d.append(d("revised", L["table_5_2"], fmt_k(r["eligible_costs_cents"]), "Eligible costs column in Table 5.2. Not the requested amount."))
        entry = dict(
            partner_id=p["id"],
            name=dict(field="partner_name", value=p["legal_name"], page=L["sec2_1"], location_type="table",
                      surface_string=legal_as_written, authority_rule=AUTHORITY_RULES[4], distractors=name_d),
            requested_amount=dict(
                field="partner_requested_amount", value=r["requested_cents"], unit="euro cents", page=L["table_5_2"],
                location_type="table",
                surface_string=("calculated at the funding rate" if r["shown_as_formula"] else
                                ("0.0" if p["id"] == "F" else fmt_k(r["requested_cents"]))),
                row_label=p["short_name"], authority_rule=AUTHORITY_RULES[1] if r["shown_as_formula"] else AUTHORITY_RULES[0],
                distractors=amt_d))
        if r["shown_as_formula"]:
            entry["requested_amount"]["computed_from"] = dict(
                formula="eligible_costs_cents * funding_rate_percent / 100",
                eligible_costs_cents=r["eligible_costs_cents"], funding_rate_percent=r["funding_rate_percent"],
                eligible_costs_surface=fmt_k(r["eligible_costs_cents"]), funding_rate_surface=str(r["funding_rate_percent"]))
        partners.append(entry)

    g = P["G"]
    key = dict(
        header=dict(document_id="SP04", version="1.0", note="Synthetic document. Ground truth is correct by construction.",
                    authority_rules=AUTHORITY_RULES,
                    formats="Amounts are integers in euro cents. Dates use ISO 8601. Booleans are 0 or 1. A field not stated in the document is null.",
                    non_target_strings=[data["footer_text"]],
                    excluded_entities=[dict(partner_id="G", legal_name=g["legal_name"], short_name=g["short_name"],
                                            reason="Withdrawn partner. Appears only in the response, Tables 5.1 and 5.3 and Figure 5.1.",
                                            pages=[L["response"], L["table_5_1"], L["fig_5_1"], L["table_5_3"]])],
                    derived_check=dict(sum_of_current_partner_amounts_cents=sum(p["revised"]["requested_cents"] for p in cur),
                                       stated_revised_total_cents=T["revised_total_requested_cents"])),
        fields=fields, partners=partners)
    return key


def gold_set(data):
    """Gold set in the structure of the attached ByggMap.json. Current partners only, in consortium table order."""
    cur = [p for p in data["partners"] if p["status"] == "current"]
    return {
        "proposal": {
            "proposal_acronym": data["proposal"]["acronym"],
            "proposal_title": data["proposal"]["title"],
            "call_identifier": data["calls"]["current"],
            "submission_date": data["dates"]["submission_current"],
        },
        "proposal_facts": {
            "requested_total_cents": data["totals"]["revised_total_requested_cents"],
            "trl_start": data["readiness"]["trl_start"],
            "trl_target": data["readiness"]["trl_target"],
            "mcrl_start": data["readiness"]["mcrl_start"],
            "mcrl_target": data["readiness"]["mcrl_target"],
        },
        "partners": [{"partner_name": p["legal_name"], "requested_cents": p["revised"]["requested_cents"]} for p in cur],
        "metadata": {"extraction_timestamp": None, "source_file": None},
    }


def manifest(data):
    rows = []
    for x in data["difficulties"]:
        rows.append(dict(issue_number=x["issue"], source_papers=x["sources"], page="; ".join(str(p) for p in x["pages"]) or "none",
                         affected_field="; ".join(x["fields"]), description=f'{x["name"]}. {x["description"]}',
                         expected_failure_mode=x["failure"]))
    return rows


def partner_register(data):
    rows = []
    for p in data["partners"]:
        aliases = [p["short_name"], p["acronym"]]
        former = []
        if p.get("former_legal_name"):
            former = [p["former_legal_name"], p["former_short_name"], p["former_acronym"]]
        rows.append({"legal name": p["legal_name"], "all aliases used in the document": "; ".join(aliases),
                     "former names": "; ".join(former), "acronym": p["acronym"], "category": p["category"],
                     "status": p["status"]})
    return rows


def name_check(data):
    lines = ["# SP04 name check list (HUMAN STEP, not done)", "",
             "Check every name below against the Finnish Trade Register (YTJ, https://www.ytj.fi/) and a web search. "
             "Any match with a real entity must be replaced in SP04_data.yaml and the document rebuilt as a new version.", "",
             "| Name | Kind | Status | YTJ result | Web search result | Replace? |", "|---|---|---|---|---|---|"]
    for p in data["partners"]:
        for kind, nm in (("legal name", p["legal_name"]), ("short name", p["short_name"]), ("acronym", p["acronym"]),
                         ("former legal name", p.get("former_legal_name")), ("former short name", p.get("former_short_name")),
                         ("former acronym", p.get("former_acronym"))):
            if nm:
                lines.append(f"| {nm} | {kind} | {p['status']} | | | |")
    for w in data["work_packages"]:
        lines.append(f"| {w['acronym']} | work package acronym | n/a | | | |")
    lines.append(f"| {data['proposal']['acronym']} | proposal acronym | n/a | | | |")
    lines.append(f"| {data['calls']['current']} | current call identifier | n/a | | | |")
    lines.append(f"| {data['calls']['previous']} | previous call identifier | n/a | | | |")
    lines += ["", "Do not edit the frozen files while doing this check. Record results here and decide on a new version if needed."]
    return "\n".join(lines) + "\n"


def blind_form():
    fields = ["proposal_acronym", "proposal_title", "call_identifier", "funding_programme", "submission_date",
              "stated_total_requested_amount (euro cents)", "trl_start", "trl_target", "mcrl_start", "mcrl_target"]
    out = [["field", "value", "page", "note"]] + [[f, "", "", ""] for f in fields]
    out += [["partner name (one row per current partner)", "", "", ""] for _ in range(7)]
    out += [["partner requested amount (euro cents, one row per current partner)", "", "", ""] for _ in range(7)]
    return out


def realism_checklist():
    return """# SP04 realism review checklist (HUMAN STEP, not done)

Reviewer familiar with real proposals. Mark each item yes, no or unsure and add a short comment. Do not edit the frozen PDF.

1. The cover, table of contents and response page look like those of a real resubmission.
2. The executive summary reads like a real executive summary for a regional cooperation project.
3. The consortium table and partner descriptions look plausible for a transnational project.
4. The work package descriptions, Gantt chart and deliverable list look plausible.
5. The budget tables (5.1 to 5.4) look like budget tables in real proposals, including the scale stated only in captions.
6. The presence of an old and a revised budget in the same document is plausible for a resubmission.
7. The filler text is neutral and does not look obviously generated or repetitive to a skimming reader.
8. Anything that makes the document look obviously synthetic apart from the footer:
9. Anything that could be mistaken for a real organisation, person or programme rule:
"""


def main():
    data = common.load_data()
    OUT.mkdir(exist_ok=True)
    (OUT / "SP04_answer_key.json").write_text(json.dumps(answer_key(data), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (OUT / "SP04_gold.json").write_text(json.dumps(gold_set(data), indent=4, ensure_ascii=False) + "\n", encoding="utf-8")
    rows = manifest(data)
    with open(OUT / "SP04_manifest.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    rows = partner_register(data)
    with open(OUT / "SP04_partner_register.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    (OUT / "SP04_name_check_list.md").write_text(name_check(data), encoding="utf-8")
    with open(OUT / "SP04_blind_extraction_form.csv", "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(blind_form())
    (OUT / "SP04_realism_checklist.md").write_text(realism_checklist(), encoding="utf-8")
    print("outputs written")


if __name__ == "__main__":
    main()
