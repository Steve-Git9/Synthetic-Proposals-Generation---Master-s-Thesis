#!/usr/bin/env python3
"""Write SP04_checksums.txt with SHA-256 checksums of all files in the project (except caches and the checksum file)."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
lines = []
for p in sorted(root.rglob("*")):
    if p.is_dir() or "__pycache__" in p.parts or p.name == "SP04_checksums.txt" or p.suffix == ".zip":
        continue
    lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root)}")
(root / "SP04_checksums.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print(len(lines), "files written to SP04_checksums.txt")
