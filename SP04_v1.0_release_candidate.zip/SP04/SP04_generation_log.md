# SP04 generation log

One entry per language model call whose output was used to produce or check SP04. Times are taken from file system timestamps of the outputs and are approximate (UTC, 2026-10-26). The field "model and interface details" is left for the researcher to fill in.

Prompts: the full task prompt is stored in `logs/prompt_01_SP04_task.txt` (SHA-256 72a7cc28d9298b48e0b801f3f62e1648efe009c5a665bcf6c14d342e08e74cdb). The answers to the clarification questions are in `logs/prompt_01b_clarifications.txt` (SHA-256 a55de609a1774243e2ab0abe041be56dbab3f803fe51b7b9396b71386cd8d7cc). Both were part of every call below, together with the project instructions of the thesis project.

## Entry 1, fictional content and structured data

- Date and time: about 07:49 UTC
- Purpose: invent all fictional organisation names, short names, acronyms, the proposal acronym and title, work package titles and acronyms, deliverable titles, risk texts and the plan for difficulty placement (task prompt sections 2, 4 and 8). Numbers are drawn by a seeded script, not by the model.
- Prompt: task prompt sections 2 to 5 and 8 (full text in the file named above).
- Output: `make_data.py` (SHA-256 6851dc3895bb60e8c5d06d890217fc5e58d2029ae6fd233ec075674c90b00519) and the data file it writes, `SP04_data.yaml` (SHA-256 bc88435f131f1e51dfd6800ecec09d67eb860f9f50e845fc92e7941456975e4f).
- Used in: every name, number, date and label in the document and answer key.
- Model and interface details: TO BE FILLED BY THE RESEARCHER

## Entry 2, paragraph bank

- Date and time: about 07:50 UTC
- Purpose: write 54 neutral filler paragraphs about regional cooperation, innovation, consortium work, dissemination, finance and risk (task prompt section 6). Each paragraph was written once in a single pass.
- Prompt: task prompt section 6 and the filler rules in section 11 check 6.
- Output: `SP04_paragraph_bank.md` in its final state (SHA-256 08791eaeb51705d03b72ff412e0a517dd914dcc862a9ae1a4596312b4fee7cbe). The first output was not stored as a separate file; its differences from the final file are listed in entry 3.
- Used in: filler on 50 of the 63 pages, selected by the seed in `build.py`.
- Model and interface details: TO BE FILLED BY THE RESEARCHER

## Entry 3, regeneration of five filler paragraphs after a failed check

- Date and time: about 07:51 UTC
- Purpose: the prose scanner (`scan_prose.py`) failed on the number word "one" in four paragraphs (P02, P12, P15, P17). P16 contained the same word and was reworded in the same pass, before the scanner ran. Each sentence was rewritten once, as allowed by task prompt section 6 when verification fails.
- Prompt: the scanner output (failures P02, P12, P15, P17 for the number word "one") plus the task prompt rules.
- Output, changed passages:
  - P02: "decisions taken on one shore are felt on another" became "decisions taken on a shore are felt across the water".
  - P12: "one of them leads" became "a single partner leads".
  - P15: "understand one another better" became "understand each other better".
  - P16: "read by at least one partner who did not write them" became "read by a colleague from another partner who did not write them".
  - P17: "the outputs of one become the inputs of the next" became "the outputs of a package become the inputs of the next".
- Used in: `SP04_paragraph_bank.md`, final checksum as in entry 2.
- Model and interface details: TO BE FILLED BY THE RESEARCHER

## Entry 4, crafted prose

- Date and time: about 07:53 UTC (revised once at about 07:56 UTC, see below)
- Purpose: write the narrative prose around the target fields, the distractors and the injected difficulties (response page, executive summary, section 1 to 5 sentences, partner descriptions, work package texts, captions). All numbers, dates, names and acronyms enter through placeholders.
- Prompt: task prompt sections 3 to 9.
- Output: `SP04_prose.yaml` in its final state (SHA-256 2122c8a93442ce9edd55dac56142392150a1f34fb4ed0b660159776c55aea8cb).
- Revision at about 07:56 UTC: in `sec5.p53_intro` one sentence was added so that the term "total requested funding" also occurs in section 5.4 (difficulty 4), and the first sentence of `sec5.p54_note` was removed to avoid repeating it.
- Used in: pages 3 to 6, 9, 11, 12, 14, 16, 19, 21 to 24, 27 to 30, 32, 35, 37, 38, 40, 50 to 54 and the annex introductions.
- Model and interface details: TO BE FILLED BY THE RESEARCHER

## Entry 5, scripts, template and charts

- Date and time: about 07:49 to 07:57 UTC
- Purpose: write the build code. No narrative text from this call appears in the document, except structural labels (headings, table headers, row labels) that sit in `build.py` and the data file.
- Prompt: task prompt sections 5, 7, 10 and 11.
- Output: `build.py` (3b9b97833100a9f4774ca28db4d16c70b46d80f9eb51776bdea58cfebcbc2e19), `SP04_charts.py` (6dd7e40876f2f580d40b5f0b628f5de020901a1ef35c62fa8b41cd63424db0b1), `scan_prose.py` (5940e4612b4f1278e8795b3dbfef67eb3f6bc800452bf675615febf1f0fcfa5e), `common.py` (018de5d30f533a97970ac7f8703acc17f15e512d41cc01bfa90017bfc176d88c), `make_outputs.py` (8417d9f40e92cdbd27098a55fd66bd0e57987442568fa8525a848783a5eb9cd8), `verify.py` (e27777865a7a84d773613836c69740e6d287e38a8db599bed404692ed5a50f47), `SP04_template/style.css` (4209c31082a1a608ccb1acda6f2c12df11af8d16709d890fa2e4ef182b82ce06), `SP04_template/doc.html.j2` (7cec16821dd8bc59ffac2b7227fb44a25c757a759cbe5f88fc9c548a2f9db357).
- Used in: building and checking the PDF and the answer key.
- Model and interface details: TO BE FILLED BY THE RESEARCHER

## Entry 6, documentation and human step material

- Date and time: about 07:58 to 08:05 UTC
- Purpose: write the datasheet, README, changelog, environment note, name check list, blind extraction form and realism checklist. None of this text is part of the PDF.
- Prompt: task prompt sections 10 and 11.
- Output: `SP04_datasheet.md`, `SP04_README.md`, `CHANGELOG.md`, `SP04_environment_note.md`, `out/SP04_name_check_list.md`, `out/SP04_blind_extraction_form.csv`, `out/SP04_realism_checklist.md`. The gold set `out/SP04_gold.json` is generated by `make_outputs.py` from the data file (no model text). Checksums are in `SP04_checksums.txt`.
- Used in: documentation only.
- Model and interface details: TO BE FILLED BY THE RESEARCHER
