#!/usr/bin/env python3
"""Automatic verification of SP04 (section 11 checks 1 to 6, plus extras).

    python3 verify.py

Reads out/SP04.pdf (text layer via pdftotext), out/SP04_answer_key.json and SP04_data.yaml.
Writes out/SP04_verification_report.md and exits non zero on any failure.
"""
import json
import re
import subprocess
import sys

import common
import scan_prose
from common import fmt_full, fmt_k

OUT = common.ROOT / "out"
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f": {detail}" if detail else ""))


def page_texts(pdf, mode="-layout"):
    n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout).group(1))
    texts = []
    for i in range(1, n + 1):
        cmd = ["pdftotext", "-f", str(i), "-l", str(i)] + ([mode] if mode else []) + [str(pdf), "-"]
        texts.append(subprocess.run(cmd, capture_output=True, text=True).stdout)
    return texts


def norm(s):
    return " ".join(s.split())


def main():
    data = common.load_data()
    L = data["layout"]
    pdf = OUT / "SP04.pdf"
    key = json.loads((OUT / "SP04_answer_key.json").read_text(encoding="utf-8"))
    pages = page_texts(pdf)
    npages = len(pages)
    ptext = [norm(t) for t in pages]
    ptext_reading = [norm(t) for t in page_texts(pdf, None)]   # reading order mode keeps table cells together

    # ------------------------------------------------ 1. text layer check
    missing = []

    def present(s, page):
        """Exact match in either extraction mode; otherwise ordered words (a table cell that wraps over lines)."""
        if s in ptext[page - 1] or s in ptext_reading[page - 1]:
            return True
        words = [re.escape(w) for w in s.split()]
        if len(words) < 4:
            return False
        rx = re.compile(r".{0,60}?".join(words))
        return any(rx.search(t) for t in (ptext[page - 1], ptext_reading[page - 1]))

    def need(page, s, label):
        if page is None:
            return
        if not present(norm(s), page):
            missing.append(f"{label}: '{s}' not on page {page}")

    for f in key["fields"]:
        if f["field"] in ("trl_start",):
            continue
        if f["value"] is None:
            continue
        need(f["page"], f["surface_string"], f["field"])
    for pe in key["partners"]:
        need(pe["name"]["page"], pe["name"]["surface_string"], f"name {pe['partner_id']}")
        need(pe["requested_amount"]["page"], pe["requested_amount"]["surface_string"], f"amount {pe['partner_id']}")
        need(pe["requested_amount"]["page"], pe["requested_amount"]["row_label"], f"row {pe['partner_id']}")
        cf = pe["requested_amount"].get("computed_from")
        if cf:
            need(pe["requested_amount"]["page"], cf["eligible_costs_surface"], "H eligible costs")
            need(pe["requested_amount"]["page"], cf["funding_rate_surface"], "H funding rate")
    check("1 text layer: every target value present on its stated page", not missing, "; ".join(missing))

    # ------------------------------------------------ 2. image value check
    trl = data["readiness"]["trl_start"]
    pat = re.compile(rf"\bTRL\s*{trl}\b|readiness level\s*{trl}\b|Start of project", re.I)
    hits = [i + 1 for i, t in enumerate(ptext) if pat.search(t)]
    check("2 image value: TRL start not in text layer", not hits, f"pages with a match: {hits}")
    fig_page_has_img = subprocess.run(["pdfimages", "-list", "-f", str(L["fig_1_2"]), "-l", str(L["fig_1_2"]), str(pdf)],
                                      capture_output=True, text=True).stdout
    check("2 image value: Figure 1.2 page carries an embedded image", "image" in fig_page_has_img, "visual legibility is a HUMAN STEP")

    # ------------------------------------------------ 3. page count and placement
    check("3 page count between 55 and 65", 55 <= npages <= 65, f"{npages} pages")

    def starts(page, s):
        return s in ptext[page - 1]

    s51 = next(i + 1 for i, t in enumerate(ptext) if i > 3 and "5.1 Original budget (for reference)" in t)
    s52 = next(i + 1 for i, t in enumerate(ptext) if i > 3 and "5.2 Revised budget" in t)
    check("3 section 5.1 and 5.2 start at least ten pages apart", s52 - s51 >= 10, f"5.1 on page {s51}, 5.2 on page {s52}")
    b2 = next(i + 1 for i, t in enumerate(ptext) if "Table B2" in t and "Targets for the end of the project" in t and i > 55)
    check("3 Table B2 within the last five pages", b2 > npages - 5, f"page {b2} of {npages}")
    headings = {
        L["response"]: "Response to the previous evaluation", L["exec_summary"][0]: "Executive summary",
        L["sec1"][0]: "1 Relevance and objectives", L["sec2"][0]: "2 Consortium", L["sec3"][0]: "3 Work plan",
        L["sec4"][0]: "4 Impact and market uptake", L["sec5_1"][0]: "5 Budget", L["sec5_1_1"]: "5.1.1 Budget principles",
        L["sec5_1_2"]: "5.1.2 Financial management", L["sec5_1_3"]: "5.1.3 Audit approach",
        L["sec5_2"][0]: "5.2 Revised budget", L["sec5_3"]: "5.3 Change justification", L["sec5_4"][0]: "5.4 Budget by cost category",
        L["annex_a_gantt"]: "Annex A Gantt chart and work packages", L["annex_b_deliverables"][0]: "Annex B Deliverables and readiness",
        L["annex_c_risks"][0]: "Annex C Risk register",
    }
    for sec, items in L["subsections"].items():
        for num, title, pg in items:
            headings[pg] = f"{num} {title}"
    bad = [f"{h!r} not on page {pg}" for pg, h in headings.items() if h not in ptext[pg - 1]]
    check("3 all planned headings on their planned pages", not bad, "; ".join(bad))
    placed = {"Table 2.1": L["sec2_1"], "Table 5.1": L["table_5_1"], "Table 5.2": L["table_5_2"], "Table 5.3": L["table_5_3"],
              "Table 5.4": L["table_5_4"], "Figure 1.2": L["fig_1_2"], "Figure 5.1": L["fig_5_1"], "Table B1": L["table_b1"],
              "Table B2": L["table_b2"]}
    bad = [f"{k} not on page {v}" for k, v in placed.items() if k not in ptext[v - 1]]
    check("3 tables and figures on planned pages", not bad, "; ".join(bad))
    foot = data["footer_text"]
    check("3 footer on every page", all(foot in t for t in ptext), "")
    toc_ok = True
    toc_txt = ptext[1]
    for pg, h in headings.items():
        if not re.search(re.escape(h) + r"\s+" + str(pg) + r"\b", toc_txt):
            toc_ok = False
    check("3 table of contents page numbers match", toc_ok)

    # ------------------------------------------------ 4. consistency
    P = common.partner_map(data)
    T = data["totals"]
    cur = [p for p in data["partners"] if p["status"] == "current"]
    h = P["H"]["revised"]
    computed_h = h["eligible_costs_cents"] * h["funding_rate_percent"] // 100
    exact = (h["eligible_costs_cents"] * h["funding_rate_percent"]) % 100 == 0
    check("4 partner H amount is exact in cents", exact and computed_h == h["requested_cents"])
    s_rev = sum(p["revised"]["requested_cents"] for p in cur)
    check("4 current partner amounts sum to stated revised total", s_rev == T["revised_total_requested_cents"],
          f"{s_rev} vs {T['revised_total_requested_cents']}")
    s_org = sum(p["original"]["requested_cents"] for p in data["partners"] if "original" in p)
    check("4 original partner amounts (incl. G) sum to original total in exec summary", s_org == T["original_total_requested_cents"]
          and f"EUR {fmt_full(T['original_total_requested_cents'])}" in ptext[L["exec_total_sentence"] - 1])
    ch_rows, ch_total = common.change_table(data)
    ok = all(r["change_cents"] == (P[r["id"]]["revised"]["requested_cents"] if P[r["id"]]["status"] == "current" else 0)
             - P[r["id"]].get("original", {}).get("requested_cents", 0) for r in ch_rows)
    ok = ok and all(r["text"] in ptext[L["table_5_3"] - 1] for r in ch_rows) and ch_total["text"] in ptext[L["table_5_3"] - 1]
    gch = next(r for r in ch_rows if r["id"] == "G")
    hch = next(r for r in ch_rows if r["id"] == "H")
    ok = ok and gch["change_cents"] == -P["G"]["original"]["requested_cents"] and hch["change_cents"] == h["requested_cents"]
    check("4 Table 5.3 equals revised minus original (G full decrease, H full increase)", ok)
    check("4 Table 5.3 shows both decrease styles and unsigned increases",
          any(r["text"].startswith("−") for r in ch_rows) and any(r["text"].startswith("(") for r in ch_rows)
          and all(not r["text"].startswith(("+", "−", "(")) for r in ch_rows if r["change_cents"] >= 0))
    tec = sum(p["revised"]["eligible_costs_cents"] for p in cur)
    cat = sum(c["cents"] for c in data["cost_categories"])
    check("4 Table 5.4 categories sum to total eligible costs implied by Table 5.2", cat == tec == T["total_eligible_costs_cents"],
          f"{cat} vs {tec}")
    # implied eligible costs: sum of requested / rate must equal eligible for each funded partner
    impl = all(p["revised"]["requested_cents"] * 100 == p["revised"]["eligible_costs_cents"] * p["revised"]["funding_rate_percent"]
               for p in cur if p["funded"])
    check("4 requested amount equals eligible costs times rate for every funded partner", impl)
    ratio_low = (T["original_total_requested_cents"] - T["revised_total_requested_cents"]) / T["original_total_requested_cents"]
    check("4 revised total between 5% and 15% lower than original", 0.05 <= ratio_low <= 0.15, f"{ratio_low:.4f}")
    check("4 original total between 5% and 15% higher than revised",
          0.05 <= T["original_total_requested_cents"] / T["revised_total_requested_cents"] - 1 <= 0.15)
    check("4 revised total between 2,000,000 and 4,000,000 euro", 200_000_000 <= T["revised_total_requested_cents"] <= 400_000_000)
    lower = [p["id"] for p in cur if "original" in p and p["funded"] and p["revised"]["requested_cents"] < p["original"]["requested_cents"]]
    higher = [p["id"] for p in cur if "original" in p and p["funded"] and p["revised"]["requested_cents"] > p["original"]["requested_cents"]]
    check("4 at least two lower and one higher amount among continuing partners", len(lower) >= 2 and len(higher) >= 1,
          f"lower {lower}, higher {higher}")
    rates = [p["revised"]["funding_rate_percent"] for p in cur if p["funded"]]
    check("4 funding rates between 60 and 80 percent", all(60 <= r <= 80 for r in rates), str(rates))
    check("4 stated total on page 50 appears in table and in sentence",
          fmt_k(T["revised_total_requested_cents"]) in ptext[L["table_5_2"] - 1]
          and f"EUR {fmt_k(T['revised_total_requested_cents'])} thousand" in ptext[L["table_5_2"] - 1])

    # ------------------------------------------------ 5. round separation
    sep = []
    auth = [(f["field"], f["page"], f["surface_string"]) for f in key["fields"] if f["value"] is not None and f["page"]]
    auth += [("partner name " + p["partner_id"], p["name"]["page"], p["name"]["value"]) for p in key["partners"]]
    auth += [("partner amount " + p["partner_id"], p["requested_amount"]["page"], p["requested_amount"]["surface_string"]) for p in key["partners"]]
    stale = [fmt_full(T["original_total_requested_cents"]), data["calls"]["previous"], common.fmt_date_long(data["dates"]["submission_previous"]),
             P["G"]["legal_name"], P["G"]["short_name"], P["B"]["former_legal_name"], P["B"]["former_short_name"]]
    for fld, pg, s in auth:
        for st in stale:
            if st in s:
                sep.append(f"{fld}: value or surface string contains stale value {st}")
    nameB = next(p for p in key["partners"] if p["partner_id"] == "B")["name"]
    check("5 round separation: authoritative values carry no stale value", not sep, "; ".join(sep))
    check("5 target name of B is the new legal name only", nameB["value"] == P["B"]["legal_name"] and "formerly" not in nameB["value"])
    check("5 partner G absent from answer key partner entries", all(p["partner_id"] != "G" for p in key["partners"])
          and P["G"]["legal_name"] not in json.dumps([f for f in key["fields"]]).replace("Lindmark", "Lindmark")[:0])
    g_pages = [i + 1 for i, t in enumerate(ptext) if P["G"]["short_name"] in t]
    check("5 partner G appears only on the planned pages", set(g_pages) <= {L["response"], L["table_5_1"], L["fig_5_1"], L["table_5_3"]},
          f"pages {g_pages}")
    check("5 stale values only in non authoritative locations: call id previous only on cover",
          [i + 1 for i, t in enumerate(ptext) if data["calls"]["previous"] in t] == [1])
    check("5 MCRL target not stated", not any(re.search(r"MCRL\s+target|target\s+MCRL|target market", t, re.I) for t in ptext))

    # ------------------------------------------------ 6. filler check
    bank = common.load_bank()
    errs = scan_prose.scan_filler(bank, data) + scan_prose.scan_prose(common.load_prose(), data)
    check("6 filler and prose scan", not errs, "; ".join(map(str, errs[:5])))
    sel = json.loads((OUT / "SP04_filler_selection.json").read_text())
    used = {pid for v in sel.values() for pid in v}
    byid = {b["id"]: b["text"] for b in bank}
    in_pdf = all(norm(byid[pid])[:60] in " ".join(ptext) for pid in used)
    check("6 every selected filler paragraph is present in the PDF", in_pdf, f"{len(used)} distinct paragraphs used")

    # ------------------------------------------------ gold set
    gold = json.loads((OUT / "SP04_gold.json").read_text(encoding="utf-8"))
    kf = {f["field"]: f["value"] for f in key["fields"]}
    gp = {**gold["proposal"], **gold["proposal_facts"]}
    ok = (gp["proposal_acronym"] == kf["proposal_acronym"] and gp["proposal_title"] == kf["proposal_title"]
          and gp["call_identifier"] == kf["call_identifier"] and gp["submission_date"] == kf["submission_date"]
          and gp["requested_total_cents"] == kf["stated_total_requested_amount"] and gp["trl_start"] == kf["trl_start"]
          and gp["trl_target"] == kf["trl_target"] and gp["mcrl_start"] == kf["mcrl_start"] and gp["mcrl_target"] is None)
    ok = ok and [(p["partner_name"], p["requested_cents"]) for p in gold["partners"]] == \
        [(p["name"]["value"], p["requested_amount"]["value"]) for p in key["partners"]]
    ok = ok and sum(p["requested_cents"] for p in gold["partners"]) == gold["proposal_facts"]["requested_total_cents"]
    ok = ok and list(gold) == ["proposal", "proposal_facts", "partners", "metadata"]
    check("gold set matches answer key, sums to total and has the ByggMap structure", ok)

    # ------------------------------------------------ extras
    check("extra: PDF metadata names SP04 and synthetic",
          "SP04" in subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout
          and "synthetic" in subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout.lower())
    fonts = subprocess.run(["pdffonts", str(pdf)], capture_output=True, text=True).stdout
    check("extra: all fonts embedded", all(" yes " in ln for ln in fonts.splitlines()[2:] if ln.strip()))
    check("extra: Figure 5.1 and Figure 1.2 values not duplicated in text layer where image only",
          not re.search(r"Start of project", " ".join(ptext)))

    failed = [r for r in results if not r[1]]
    lines = ["# SP04 automatic verification report", "", f"Result: {'ALL AUTOMATIC CHECKS PASSED' if not failed else 'FAILURES: ' + str(len(failed))}", ""]
    lines += [f"- {'PASS' if ok else 'FAIL'}: {n}" + (f" ({d})" if d else "") for n, ok, d in results]
    (OUT / "SP04_verification_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
