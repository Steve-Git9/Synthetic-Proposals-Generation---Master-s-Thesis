#!/usr/bin/env python3
"""Draw all SP04 values with a fixed seed and write SP04_data.yaml.

This script is run once by the author of the document. The build reads only the
resulting data file. All money is held in euro cents (integers).
"""
import datetime
import random
import yaml

SEED = 40404
rng = random.Random(SEED)


def r100(euro):
    """Round euro to a multiple of 100 euro, return euro."""
    return int(round(euro / 100.0)) * 100


# ---------------------------------------------------------------- partners
partners = [
    dict(id="A", legal_name="Hallvik University", short_name="Hallvik", acronym="HVU",
         category="university", type_label="University (lead partner)", status="current",
         round_in=["original", "revised"], funded=True),
    dict(id="B", legal_name="Orrenfjord Marine Systems Ltd", short_name="Orrenfjord", acronym="OMS",
         category="company", type_label="Company", status="current",
         round_in=["original", "revised"], funded=True,
         former_legal_name="Kellmar Technologies Ltd", former_short_name="Kellmar", former_acronym="KTL"),
    dict(id="C", legal_name="Marovik Research Institute", short_name="Marovik", acronym="MARO",
         category="research organisation", type_label="Research organisation", status="current",
         round_in=["original", "revised"], funded=True),
    dict(id="D", legal_name="Quenmark Sensor Works Ltd", short_name="Quenmark", acronym="QSW",
         category="company", type_label="Company", status="current",
         round_in=["original", "revised"], funded=True),
    dict(id="E", legal_name="Ostrelund Regional Development Agency", short_name="Ostrelund", acronym="ORDA",
         category="public body", type_label="Public body", status="current",
         round_in=["original", "revised"], funded=True),
    dict(id="F", legal_name="Brenvik Port Logistics Ltd", short_name="Brenvik", acronym="BPL",
         category="company", type_label="Company (associated partner)", status="current",
         round_in=["original", "revised"], funded=False),
    dict(id="G", legal_name="Lindmark Coastal Studies Institute", short_name="Lindmark", acronym="LCSI",
         category="research organisation", type_label="Research organisation", status="withdrawn",
         round_in=["original"], funded=True),
    dict(id="H", legal_name="Eskeby Technical University", short_name="Eskeby", acronym="ETU",
         category="university", type_label="University", status="current",
         round_in=["revised"], funded=True),
]
P = {p["id"]: p for p in partners}

# ------------------------------------------------------------- money draws
ELIG_RANGE = {"A": (70, 101), "B": (50, 81), "C": (55, 86), "D": (40, 71), "E": (30, 51), "H": (50, 81)}
attempts = 0
while True:
    attempts += 1
    elig = {k: rng.randrange(*v) * 10000 for k, v in ELIG_RANGE.items()}          # euro
    rate = {k: rng.randint(60, 80) for k in ELIG_RANGE}                          # integer percent
    amt = {k: elig[k] * rate[k] // 100 for k in ELIG_RANGE}                      # euro, exact
    assert all(elig[k] * rate[k] % 100 == 0 for k in ELIG_RANGE)
    R = sum(amt.values())
    if not (2_000_000 <= R <= 4_000_000):
        continue
    orig = {}
    for k in "ABCDE":
        f = rng.uniform(0.88, 1.22)
        orig[k] = r100(amt[k] * f)
    x = rng.uniform(0.06, 0.14)
    O = r100(R * (1 + x))
    orig["G"] = O - sum(orig[k] for k in "ABCDE")
    orig["F"] = 0
    if not (150_000 <= orig["G"] <= 450_000):
        continue
    lower = [k for k in "ABCDE" if amt[k] < orig[k]]
    higher = [k for k in "ABCDE" if amt[k] > orig[k]]
    same = [k for k in "ABCDE" if amt[k] == orig[k]]
    if len(lower) < 2 or len(higher) < 1 or same:
        continue
    if not (0.05 <= (O - R) / O <= 0.15) or not (0.05 <= O / R - 1 <= 0.15):
        continue
    break

TEC = sum(elig.values())                       # total eligible costs, funded partners (euro)
IC = r100(TEC * rng.uniform(0.03, 0.07))       # costs not eligible for support
TB = TEC + IC                                  # total budget
APC = rng.randrange(15, 36) * 10000            # associated partner costs (no funding requested)
TPC = TB + APC                                 # total project cost

staff = r100(TEC * rng.uniform(0.50, 0.58))
office = r100(TEC * rng.uniform(0.07, 0.10))
travel = r100(TEC * rng.uniform(0.05, 0.08))
equipment = r100(TEC * rng.uniform(0.06, 0.10))
external = TEC - staff - office - travel - equipment
assert 0.12 * TEC <= external <= 0.34 * TEC, external
cost_categories = [
    ("Staff costs", staff), ("Office and administration", office), ("Travel and accommodation", travel),
    ("External expertise and services", external), ("Equipment", equipment),
]

# ------------------------------------------------------------- other values
def rand_date(a, b):
    d0, d1 = datetime.date.fromisoformat(a), datetime.date.fromisoformat(b)
    return (d0 + datetime.timedelta(days=rng.randint(0, (d1 - d0).days))).isoformat()

date_current = rand_date("2026-08-03", "2026-09-30")
date_previous = rand_date("2026-02-02", "2026-04-30")
call_previous = "BSR2026C%02d" % rng.randint(21, 39)
call_current = "BSR2026C%02d" % rng.randint(41, 59)
trl_start = rng.choice([2, 3, 4])
trl_target = trl_start + rng.choice([2, 3])
mcrl_start = rng.choice([v for v in (3, 4, 5) if v != trl_start])

# --------------------------------------------------------------- structure
work_packages = [
    dict(id="WP1", acronym="COORD", title="Project coordination and governance", lead="A", start=1, end=36,
         participants="ABCDEFH",
         objective="Keep the consortium aligned, manage risks and secure orderly reporting throughout the project.",
         tasks=[("Consortium management", 1, 36), ("Quality and risk control", 1, 36)],
         deliverables=[("Project handbook", 3), ("Final management report", 36)]),
    dict(id="WP2", acronym="BRIDGE", title="Linking observation data providers across the sea basin", lead="C",
         start=1, end=18, participants="ACDEH",
         objective="Build the technical and organisational links that let existing observation providers share data under common terms.",
         tasks=[("Provider mapping", 1, 6), ("Data sharing agreements", 4, 12), ("Interface specification", 8, 18)],
         deliverables=[("Provider inventory", 6), ("Data sharing agreement template", 12), ("Interface specification", 18)]),
    dict(id="WP3", acronym="SENSE", title="Deployment of coastal sensing nodes", lead="D", start=4, end=24,
         participants="BCDEF",
         objective="Design, install and maintain low cost sensing nodes at selected coastal locations.",
         tasks=[("Node design", 4, 12), ("Installation campaigns", 10, 22), ("Maintenance routines", 14, 24)],
         deliverables=[("Node design report", 12), ("Installation report", 22)]),
    dict(id="WP4", acronym="MODEL", title="Shared data models and services", lead="H", start=6, end=30,
         participants="ABCDH",
         objective="Develop common data models and open services that combine observations from different providers.",
         tasks=[("Data model design", 6, 16), ("Service development", 12, 28), ("Validation", 24, 30)],
         deliverables=[("Common data model", 16), ("Service prototype", 28)]),
    dict(id="WP5", acronym="PILOT", title="Pilot operation in regional test areas", lead="E", start=12, end=33,
         participants="ABDEFH",
         objective="Operate the combined services in regional test areas together with local authorities and port operators.",
         tasks=[("Pilot preparation", 12, 20), ("Pilot operation", 18, 32), ("Evaluation with users", 28, 33)],
         deliverables=[("Pilot plan", 20), ("Pilot evaluation report", 33)]),
    dict(id="WP6", acronym="SPREAD", title="Dissemination, uptake and exploitation", lead="B", start=1, end=36,
         participants="ABCDEFH",
         objective="Make results visible to public authorities, companies and research communities and prepare their use after the project.",
         tasks=[("Communication activities", 1, 36), ("Training and exchange", 14, 34), ("Exploitation planning", 24, 36)],
         deliverables=[("Dissemination plan", 6), ("Exploitation plan", 36)]),
]
risks = [
    ("R1", "Delay in access to observation data", "medium", "high", "Agree access terms early and keep alternative providers on standby."),
    ("R2", "Sensing nodes fail in harsh coastal conditions", "medium", "medium", "Use tested housings and schedule regular maintenance visits."),
    ("R3", "Differences in national data practices slow integration", "high", "medium", "Use a common data model and hold regular alignment meetings."),
    ("R4", "Loss of key staff in a partner organisation", "low", "high", "Document procedures and name deputies for all key roles."),
    ("R5", "Limited participation of local authorities in pilots", "medium", "medium", "Involve authorities from the planning stage and share early results."),
    ("R6", "Data protection concerns about shared records", "low", "high", "Design services around aggregated data and clear access rules."),
    ("R7", "Cost increases for equipment", "medium", "low", "Bundle purchases and keep a flexible equipment plan."),
    ("R8", "Difficulties in keeping services running after the project", "medium", "high", "Prepare an exploitation plan with agreed operators early on."),
]

layout = dict(
    cover=1, toc=2, response=3, exec_summary=[4, 5], exec_total_sentence=4,
    sec1=[6, 18], fig_1_1=7, crossref_sentence=11, bridge_ordinary_sentence_p9=9, fig_1_2=12,
    sec2=[19, 26], sec2_1=19, sec2_2=21,
    sec3=[27, 34], bridge_wp_description=28,
    sec4=[35, 39], sec4_2=37, mcrl_start_sentence=37,
    sec5_1=[40, 41], table_5_1=40,
    sec5_filler=[42, 49], sec5_1_1=42, sec5_1_2=45, sec5_1_3=48,
    sec5_2=[50, 51], table_5_2=50, fig_5_1=51,
    sec5_3=52, table_5_3=52,
    sec5_4=[53, 54], table_5_4=53,
    annex_a_gantt=55, annex_a_wp=[56, 58], annex_b_deliverables=[59, 60], table_b1=59, table_b2=61,
    annex_c_risks=[62, 63], total_pages=63,
    subsections={
        "1": [("1.1", "Context and rationale", 6), ("1.2", "Readiness assessment", 11),
              ("1.3", "Objectives", 14), ("1.4", "Approach", 16)],
        "2": [("2.1", "Consortium overview", 19), ("2.2", "Description of partners", 21),
              ("2.3", "Cooperation and decision making", 24)],
        "3": [("3.1", "Structure of the work plan", 27), ("3.2", "Work package descriptions", 28),
              ("3.3", "Management and coordination", 32)],
        "4": [("4.1", "Expected impact", 35), ("4.2", "Market uptake", 37), ("4.3", "Dissemination and exploitation", 38)],
    },
)

data = dict(
    meta=dict(document_id="SP04", version="1.0", seed=SEED, draw_attempts=attempts, language="en-GB",
              note="All organisations, persons, projects and call identifiers are fictional. Synthetic test document."),
    footer_text="Synthetic document for research purposes, ID SP04, version 1.0",
    pdf_metadata=dict(title="SP04 synthetic project proposal (resubmission)", author="SP04 synthetic document generator",
                      subject="Synthetic document for research purposes, ID SP04", keywords="synthetic, SP04",
                      created="2026-10-26T00:00:00+00:00"),
    funding_programme="Interreg Baltic Sea Region",
    calls=dict(current=call_current, previous=call_previous),
    dates=dict(submission_current=date_current, submission_previous=date_previous),
    proposal=dict(acronym="MAROFLOW", title="Marine Observation Flows for Shared Coastal Planning"),
    readiness=dict(trl_start=trl_start, trl_target=trl_target, mcrl_start=mcrl_start, mcrl_target=None),
    partners=[],
    totals=dict(
        revised_total_requested_cents=R * 100, original_total_requested_cents=O * 100,
        total_eligible_costs_cents=TEC * 100, ineligible_costs_cents=IC * 100, total_budget_cents=TB * 100,
        associated_partner_costs_cents=APC * 100, total_project_cost_cents=TPC * 100,
    ),
    cost_categories=[dict(name=n, cents=v * 100) for n, v in cost_categories],
    work_packages=[dict(wp, tasks=[dict(name=t[0], start=t[1], end=t[2]) for t in wp["tasks"]],
                        deliverables=[dict(title=d[0], month=d[1]) for d in wp["deliverables"]]) for wp in work_packages],
    risks=[dict(id=r[0], title=r[1], likelihood=r[2], impact=r[3], mitigation=r[4]) for r in risks],
    layout=layout,
    outputs=dict(test_areas=4),
)
for p in partners:
    q = dict(p)
    k = p["id"]
    if k in amt:
        q["revised"] = dict(eligible_costs_cents=elig[k] * 100, funding_rate_percent=rate[k],
                            requested_cents=amt[k] * 100, shown_as_formula=(k == "H"),
                            formula="eligible_costs_cents * funding_rate_percent / 100")
    elif k == "F":
        q["revised"] = dict(eligible_costs_cents=0, funding_rate_percent=None, requested_cents=0, shown_as_formula=False)
    if k in orig:
        q["original"] = dict(requested_cents=orig[k] * 100)
    data["partners"].append(q)

# difficulty placements (planned pages; confirmed by verify.py against the PDF text layer)
data["difficulties"] = [
    dict(n=1, issue="#12", sources="D", name="Same figures in several tables", pages=[50, 51, 52, 53],
         fields=["total requested amount", "partner amounts"],
         description="Revised amounts repeat in Table 5.2, as differences in Table 5.3, as eligible cost totals in Table 5.4 and as bar labels in Figure 5.1.",
         failure="Extraction picks a value from the wrong table or figure."),
    dict(n=2, issue="#14", sources="T, K", name="Scale differs between tables", pages=[40, 50, 52],
         fields=["total requested amount", "partner amounts"],
         description="Table 5.1 in full euro; Tables 5.2 and 5.3 in EUR thousand stated only in the caption, bare numbers with one decimal.",
         failure="Amount returned in thousand instead of euro, or full euro value taken from the wrong round."),
    dict(n=3, issue="#15", sources="V, T, K", name="Stale value", pages=[1, 4],
         fields=["call identifier", "submission date", "total requested amount"],
         description="Cover shows previous call identifier and previous submission date; executive summary quotes the original total.",
         failure="Stale call identifier, date or total returned."),
    dict(n=4, issue="#16 and #25", sources="V", name="Overlapping terms", pages=[50, 53, 54],
         fields=["total requested amount"],
         description="Total budget, total eligible costs, total requested funding and total project cost appear close together, each with a different value.",
         failure="Wrong total returned for the requested amount."),
    dict(n=5, issue="#17", sources="T", name="Sign of values", pages=[52],
         fields=["none (change values are never targets)"],
         description="Decreases shown with a minus sign and in accounting parentheses; increases without sign.",
         failure="Change value taken as an amount, or sign misread."),
    dict(n=6, issue="#19", sources="T, M", name="Domain knowledge", pages=[50],
         fields=["requested amount of partner H"],
         description="Partner H requested amount cell reads 'calculated at the funding rate'; eligible costs and rate are in the same row.",
         failure="Amount returned as null or as the eligible costs."),
    dict(n=7, issue="#18 and #20", sources="T, M, K", name="Table plus text, renamed partner", pages=[19, 40, 50],
         fields=["partner names"],
         description="Table 5.2 uses short names only; legal names are in section 2.1; partner B appears as new name (formerly old name); Table 5.1 uses the old name.",
         failure="Short name, old name or the formerly clause returned as the partner name."),
    dict(n=8, issue="#24 and #30", sources="K, V, D, M", name="Withdrawn partner and entity ambiguity", pages=[3, 40, 51, 52],
         fields=["partner list"],
         description="Partner G appears in the response, Table 5.1, Table 5.3 and Figure 5.1 only; G and H have similar research oriented descriptions.",
         failure="Partner G extracted as a current partner."),
    dict(n=9, issue="#20 and #30", sources="K, M", name="Acronym collisions", pages=[1, 9, 28, 56],
         fields=["proposal acronym", "partner names"],
         description="Proposal acronym MAROFLOW contains partner C acronym MARO; work package acronym BRIDGE is also an ordinary English word used in running text.",
         failure="Partner acronym returned as proposal acronym, or work package taken for a partner."),
    dict(n=10, issue="#8 and #26", sources="M, K", name="Value only in an image", pages=[12],
         fields=["TRL start"],
         description="TRL start appears only as a label inside Figure 1.2, rendered as an image without text layer.",
         failure="TRL start returned as null by a text only pipeline."),
    dict(n=11, issue="#27", sources="M", name="Cross reference", pages=[11, 61],
         fields=["TRL target"],
         description="Section 1 refers to Annex B, Table B2, which holds the TRL target in the last five pages.",
         failure="TRL target returned as null or taken from the wrong place."),
    dict(n=12, issue="#24 and #29", sources="M", name="Absent field", pages=[],
         fields=["MCRL target"],
         description="MCRL target is not stated anywhere; the answer key value is null.",
         failure="Hallucinated MCRL target."),
    dict(n=13, issue="#24", sources="K, V, D", name="Zero funded partner", pages=[40, 50],
         fields=["requested amount of partner F"],
         description="Partner F appears with 0 in Table 5.1 and 0.0 in Table 5.2.",
         failure="Partner F dropped or amount returned as null."),
]

with open("SP04_data.yaml", "w", encoding="utf-8") as f:
    f.write("# SP04 data file. Every value in the document comes from here. Money in euro cents.\n")
    yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True, width=120)

print("seed", SEED, "attempts", attempts)
print("revised total EUR", R, "original total EUR", O, "ratio", round(O / R - 1, 4), "lower", round((O - R) / O, 4))
print("elig", elig, "rate", rate, "amt", amt)
print("orig", orig, "TEC", TEC, "IC", IC, "TB", TB, "APC", APC, "TPC", TPC)
print("calls", call_current, call_previous, "dates", date_current, date_previous, "TRL", trl_start, trl_target, "MCRL", mcrl_start)
