#!/usr/bin/env python3
"""Generate all SP04 graphics from SP04_data.yaml. Text inside the images is part of the image (raster PNG).

Outputs (out/figures): fig_1_1.png, fig_1_2.png, fig_5_1.png, fig_a1_gantt.png
Deterministic: fixed seed, fixed fonts, no timestamps in PNG metadata.
"""
import random
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

import common

DPI = 200
NAVY = "#1f3a5f"
TEAL = "#2a9d8f"
GREY = "#8a94a0"
LIGHT = "#dfe6ee"
AMBER = "#d98e04"
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False


def save(fig, path):
    fig.savefig(path, dpi=DPI, metadata={"Software": None}, facecolor="white", bbox_inches="tight", pad_inches=0.15)
    plt.close(fig)


def fig_1_1(out):
    fig, ax = plt.subplots(figsize=(7.2, 2.0))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 2.4)
    ax.axis("off")
    labels = ["Observation\nproviders", "Shared data\nmodel", "Regional\nservices", "Users in\ncoastal planning"]
    xs = [0.2, 2.8, 5.4, 8.0]
    for x, lab in zip(xs, labels):
        ax.add_patch(FancyBboxPatch((x, 0.5), 1.8, 1.4, boxstyle="round,pad=0.03", fc=LIGHT, ec=NAVY, lw=1.2))
        ax.text(x + 0.9, 1.2, lab, ha="center", va="center", fontsize=8.5, color=NAVY)
    for a, b in zip(xs[:-1], xs[1:]):
        ax.annotate("", xy=(b - 0.05, 1.2), xytext=(a + 1.85, 1.2), arrowprops=dict(arrowstyle="->", color=NAVY, lw=1.4))
    save(fig, out / "fig_1_1.png")


def fig_1_2(out, data):
    """Readiness graphic. The TRL start appears only here, as a label inside the image."""
    start = data["readiness"]["trl_start"]
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    ax.set_xlim(0.4, 9.6)
    ax.set_ylim(0, 3.2)
    ax.axis("off")
    caps = {1: "idea", 3: "proof of\nconcept", 5: "validation in\nrelevant setting", 7: "prototype in\noperation", 9: "proven\nsystem"}
    for lvl in range(1, 10):
        done = lvl <= start
        ax.add_patch(Rectangle((lvl - 0.45, 1.0), 0.9, 0.7, fc=(TEAL if done else LIGHT), ec=NAVY, lw=1.0))
        ax.text(lvl, 1.35, str(lvl), ha="center", va="center", fontsize=11, color=("white" if done else NAVY), fontweight="bold")
        if lvl in caps:
            ax.text(lvl, 0.55, caps[lvl], ha="center", va="center", fontsize=7.2, color=GREY)
    ax.annotate(f"Start of project: TRL {start}", xy=(start, 1.75), xytext=(start + 1.6, 2.65),
                fontsize=11, color=NAVY, fontweight="bold", ha="left", va="center",
                arrowprops=dict(arrowstyle="-|>", color=AMBER, lw=1.8))
    ax.text(0.45, 3.05, "Technology readiness level (TRL) scale", fontsize=9, color=GREY, va="center")
    save(fig, out / "fig_1_2.png")


def fig_5_1(out, data):
    P = data["partners"]
    order = ["A", "B", "C", "D", "E", "F", "G", "H"]
    byid = {p["id"]: p for p in P}
    names, orig, rev = [], [], []
    for k in order:
        p = byid[k]
        nm = p["short_name"]
        if k == "B":
            nm = f"{p['short_name']}\n(was {p['former_short_name']})"
        names.append(nm)
        orig.append(p.get("original", {}).get("requested_cents", 0) / 1e5)
        rev.append(p.get("revised", {}).get("requested_cents", 0) / 1e5 if p["status"] == "current" else 0.0)
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    x = list(range(len(order)))
    w = 0.38
    b1 = ax.bar([i - w / 2 for i in x], orig, w, label="Earlier budget", color=GREY)
    b2 = ax.bar([i + w / 2 for i in x], rev, w, label="Revised budget", color=NAVY)
    for bars in (b1, b2):
        for r in bars:
            ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 8, f"{r.get_height():,.1f}", ha="center", va="bottom",
                    fontsize=6.4, rotation=90, color="#222")
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=7.4)
    ax.set_ylabel("EUR thousand", fontsize=8.5)
    ax.set_ylim(0, max(orig + rev) * 1.22)
    ax.legend(frameon=False, fontsize=8, loc="upper right")
    ax.grid(axis="y", color="#e5e9ee", lw=0.8)
    ax.set_axisbelow(True)
    save(fig, out / "fig_5_1.png")


def fig_a1_gantt(out, data):
    wps = data["work_packages"]
    rows = []
    for wp in wps:
        rows.append((f"{wp['id']} {wp['acronym']}", wp["start"], wp["end"], True))
        for t in wp["tasks"]:
            rows.append(("   " + t["name"], t["start"], t["end"], False))
    fig, ax = plt.subplots(figsize=(7.6, 8.4))
    n = len(rows)
    for i, (lab, s, e, head) in enumerate(rows):
        y = n - 1 - i
        ax.barh(y, e - s + 1, left=s - 1, height=0.62, color=(NAVY if head else TEAL), edgecolor="none")
    ax.set_yticks([n - 1 - i for i in range(n)])
    ax.set_yticklabels([r[0] for r in rows], fontsize=7.2)
    for lab, tick in zip(ax.get_yticklabels(), rows):
        if tick[3]:
            lab.set_fontweight("bold")
    ax.set_xlim(0, 36)
    ax.set_xticks([m - 0.5 for m in range(1, 37)])
    ax.set_xticklabels([str(m) for m in range(1, 37)], fontsize=6)
    ax.set_xlabel("Project month", fontsize=8.5)
    ax.grid(axis="x", color="#e5e9ee", lw=0.6)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0)
    save(fig, out / "fig_a1_gantt.png")


def main():
    random.seed(common.load_data()["meta"]["seed"])
    data = common.load_data()
    out = common.ROOT / "out" / "figures"
    out.mkdir(parents=True, exist_ok=True)
    fig_1_1(out)
    fig_1_2(out, data)
    fig_5_1(out, data)
    fig_a1_gantt(out, data)
    print("figures written to", out)


if __name__ == "__main__":
    main()
