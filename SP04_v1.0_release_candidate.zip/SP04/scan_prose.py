#!/usr/bin/env python3
"""Prose scanner. Fails if model written prose contains a number, date, organisation name or acronym
that does not come from the data file.

Two scans:
  1. Filler (paragraph bank): strict. No digits, number words, months, acronyms, capitalised words inside a
     sentence, organisation names, and none of the words original, previous, revised, resubmission.
  2. Crafted prose (SP04_prose.yaml): the literal text outside {placeholders} must contain no digits, months,
     organisation names or unexpected acronyms. Structural labels (Table 5.2, Figure 1.2, Annex B, section 5.1)
     are allowed.
"""
import re
import sys
import common

MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
          "november", "december"]
NUMWORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
            "twelve", "hundred", "thousand", "million", "billion", "twenty", "thirty", "forty", "fifty"]
FORBIDDEN_FILLER = ["original", "previous", "revised", "resubmission", "resubmit"]
ALLOWED_ACRONYMS = {"TRL", "MCRL", "EUR"}
ALLOWED_CAPS = {"Gantt"}
STRUCT = re.compile(r"\b(?:Tables?|Figures?|Annex(?:es)?|Sections?|sections?)\s+[A-Z]?\d*(?:\.\d+)?(?:\s*(?:,|and|or)\s*[A-Z]?\d+(?:\.\d+)?)*|\bAnnex\s+[A-C]\b")


def org_terms(data):
    terms = set()
    for p in data["partners"]:
        for k in ("legal_name", "short_name", "acronym", "former_legal_name", "former_short_name", "former_acronym"):
            if p.get(k):
                terms.add(p[k])
    terms.add(data["proposal"]["acronym"])
    for w in data["work_packages"]:
        terms.add(w["acronym"])
    terms.add(data["funding_programme"])
    terms.add(data["calls"]["current"])
    terms.add(data["calls"]["previous"])
    return terms


def term_hit(term, text):
    """Acronyms (all capitals) match case sensitively as whole words; names match case insensitively."""
    if term.isupper() or re.fullmatch(r"[A-Z0-9]+", term):
        return re.search(rf"\b{re.escape(term)}\b", text) is not None
    return term.lower() in text.lower()


def sentences_start_ok(text):
    """Return capitalised words that are not at the start of a sentence."""
    bad = []
    tokens = re.findall(r"[A-Za-z][A-Za-z]*|[.!?]", text)
    start = True
    for t in tokens:
        if t in ".!?":
            start = True
            continue
        if t[0].isupper() and not start:
            bad.append(t)
        start = False
    return bad


def scan_filler(bank, data):
    errs = []
    terms = org_terms(data)
    for p in bank:
        t = p["text"]
        low = t.lower()
        if re.search(r"\d", t):
            errs.append((p["id"], "digit"))
        for w in NUMWORDS:
            if re.search(rf"\b{w}\b", low):
                errs.append((p["id"], f"number word {w}"))
        for m in MONTHS:
            if m != "may" and re.search(rf"\b{m}\b", low):
                errs.append((p["id"], f"month {m}"))
        if re.search(r"\b[A-Z]{2,}\b", t):
            errs.append((p["id"], "acronym"))
        for w in FORBIDDEN_FILLER:
            if w in low:
                errs.append((p["id"], f"forbidden word {w}"))
        for tm in terms:
            if term_hit(tm, t):
                errs.append((p["id"], f"organisation term {tm}"))
        for w in sentences_start_ok(t):
            errs.append((p["id"], f"capitalised word inside sentence: {w}"))
    return errs


def walk_strings(obj, path=""):
    if isinstance(obj, str):
        yield path, obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk_strings(v, f"{path}.{k}" if path else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk_strings(v, f"{path}[{i}]")


def scan_prose(prose, data):
    errs = []
    terms = org_terms(data)
    ctx = common.build_ctx(data)
    for path, text in walk_strings(prose):
        t = " ".join(text.split())
        # placeholders must be known
        for ph in re.findall(r"\{(\w+)\}", t):
            if ph not in ctx and ph not in {"wp_acr", "wp_title", "lead_short", "objective"}:
                errs.append((path, f"unknown placeholder {ph}"))
        lit = re.sub(r"\{\w+\}", " ", t)
        lit = STRUCT.sub(" ", lit)
        if re.search(r"\d", lit):
            errs.append((path, "digit in literal prose"))
        low = lit.lower()
        for m in MONTHS:
            if m != "may" and re.search(rf"\b{m}\b", low):
                errs.append((path, f"month {m}"))
        for tm in terms:
            if term_hit(tm, lit):
                errs.append((path, f"organisation term {tm}"))
        for a in re.findall(r"\b[A-Z]{2,}\b", lit):
            if a not in ALLOWED_ACRONYMS:
                errs.append((path, f"acronym {a}"))
        # capitalised words inside a sentence (placeholders replaced by a lowercase token)
        probe = re.sub(r"\{\w+\}", "x", STRUCT.sub("x", t))
        for w in sentences_start_ok(probe):
            if path.endswith("_caption"):
                continue  # captions are title like
            if w not in ALLOWED_ACRONYMS and w not in ALLOWED_CAPS and not w.isupper():
                errs.append((path, f"capitalised word inside sentence: {w}"))
    return errs


def main():
    data = common.load_data()
    bank = common.load_bank()
    prose = common.load_prose()
    errs = scan_filler(bank, data) + scan_prose(prose, data)
    print(f"bank paragraphs: {len(bank)}")
    if not (40 <= len(bank) <= 60):
        errs.append(("bank", "paragraph count outside 40 to 60"))
    if errs:
        for e in errs:
            print("FAIL", e)
        sys.exit(1)
    print("prose scan passed")


if __name__ == "__main__":
    main()
