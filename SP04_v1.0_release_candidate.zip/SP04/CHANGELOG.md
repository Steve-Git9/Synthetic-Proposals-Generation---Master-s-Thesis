# Changelog

## 1.0 (release candidate, 2026-10-26)

- First version of SP04, the synthetic revised resubmission with historical budgets.
- 63 pages, born digital PDF, English with European spelling.
- Seed 40404. Values drawn by `make_data.py` into `SP04_data.yaml`.
- Researcher decisions applied: dashes are allowed in generated files (minus signs, ISO 8601 dates); partner G appears in Table 5.3 and Figure 5.1 as a full decrease.
- Added `out/SP04_gold.json`, the gold set in the structure of the ByggMap example (still version 1.0, not frozen).
- Status: not yet frozen. Open before freeze: visual legibility check of Figure 1.2, blind second extraction, realism review and name check (see `SP04_README.md`). If any of these leads to a change, the change is made before the freeze and recorded here; after the freeze any change creates version 1.1.
