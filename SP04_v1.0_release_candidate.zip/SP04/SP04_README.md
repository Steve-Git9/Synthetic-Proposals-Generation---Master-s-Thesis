# SP04, synthetic revised resubmission (version 1.0, release candidate)

Synthetic test document for the thesis on language model assisted extraction from project proposals. All content is fictional. Never submit it to any call.

## Rebuild

```
pip install -r requirements.lock
./build
```

`./build` runs the prose scan, draws the figures, renders `out/SP04.pdf`, writes the answer key, manifest, partner register and filler log, and then runs the automatic checks (`verify.py`). The build never calls a language model. `make_data.py` (seed 40404) is run once to create `SP04_data.yaml`; it is not part of the normal rebuild.

## Where things are

| Deliverable | File |
|---|---|
| Document | `out/SP04.pdf` |
| Data file with seed | `SP04_data.yaml` |
| Template and build | `SP04_template/`, `build`, `build.py`, `common.py`, `scan_prose.py`, `make_outputs.py` |
| Charts | `SP04_charts.py` (figures in `out/figures/`) |
| Answer key | `out/SP04_answer_key.json` |
| Gold set (ByggMap structure) | `out/SP04_gold.json` |
| Manifest of difficulties | `out/SP04_manifest.csv` |
| Partner register | `out/SP04_partner_register.csv` |
| Paragraph bank, crafted prose | `SP04_paragraph_bank.md`, `SP04_prose.yaml` |
| Generation log and prompts | `SP04_generation_log.md`, `logs/` |
| Environment, pinned versions | `SP04_environment_note.md`, `requirements.lock` |
| Checksums | `SP04_checksums.txt` |
| Changelog, datasheet | `CHANGELOG.md`, `SP04_datasheet.md` |
| Automatic check report | `out/SP04_verification_report.md` |
| Human step material | `out/SP04_name_check_list.md`, `out/SP04_blind_extraction_form.csv`, `out/SP04_realism_checklist.md` |

## Status of the checks

All automatic checks pass (`out/SP04_verification_report.md`).

Open human steps, not done:

1. Visual check that the TRL start is legible in Figure 1.2 (page 12).
2. Blind second extraction by another person, without the answer key. Record the initial agreement rate and fix design or key on every disagreement.
3. Realism review by a person familiar with real proposals.
4. Name check of all organisation names and both call identifiers against YTJ and a web search. Any real match must be replaced.
5. Freeze: after steps 1 to 4 pass, tag version 1.0, regenerate `SP04_checksums.txt` with `python3 checksums.py`, and do not edit the files again. The document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.
