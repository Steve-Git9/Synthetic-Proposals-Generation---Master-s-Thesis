#!/usr/bin/env python3
"""One command rebuild of SP04. Reads only stored files: SP04_data.yaml, SP04_prose.yaml,
SP04_paragraph_bank.md and the template folder. Never calls a language model.

    python3 build.py

Steps: prose scan, charts, HTML, PDF, answer key, manifest, partner register, filler selection log.
"""
import hashlib
import html
import os
import json
import random
import subprocess
import sys
from pathlib import Path

import jinja2

import common
import scan_prose
from common import MINUS, fmt_date_long, fmt_full, fmt_k, fmt_k_signed, fill

# fixed timestamp for embedded font subsets and any other library timestamps, so rebuilds are byte identical
os.environ["SOURCE_DATE_EPOCH"] = "1792972800"  # 2026-10-26T00:00:00Z

ROOT = common.ROOT
OUT = ROOT / "out"
FIG = OUT / "figures"
esc = html.escape

POOLS = {
    "rel": ["relevance", "general", "impact"],
    "cons": ["consortium", "general", "workplan"],
    "work": ["workplan", "general", "risk", "consortium"],
    "imp": ["impact", "relevance", "general"],
    "fin": ["finance", "risk", "consortium", "general"],
    "risk": ["risk", "workplan", "general"],
    "gen": ["general", "relevance", "impact", "consortium"],
}


class Filler:
    """Seeded selection of paragraphs from the bank. Least used paragraphs first, order shuffled by the seed."""

    def __init__(self, bank, seed):
        self.bank, self.seed = bank, seed
        self.used = {p["id"]: 0 for p in bank}
        self.log = {}

    def take(self, page, k, pool):
        rng = random.Random(f"{self.seed}:{page}:{pool}")
        tags = set(POOLS[pool])
        cands = [p for p in self.bank if p["tag"] in tags]
        rng.shuffle(cands)
        cands.sort(key=lambda p: self.used[p["id"]])
        chosen = cands[:k]
        rng.shuffle(chosen)
        for p in chosen:
            self.used[p["id"]] += 1
        self.log.setdefault(page, []).extend(p["id"] for p in chosen)
        return "".join(f"<p>{esc(p['text'])}</p>" for p in chosen)


def build_pages(data, prose, bank):
    ctx = common.build_ctx(data)
    L = data["layout"]
    P = common.partner_map(data)
    T = data["totals"]
    WP = data["work_packages"]
    F = Filler(bank, data["meta"]["seed"])
    pages = {}

    def txt(section, key, **extra):
        return fill(prose[section][key], ctx, **extra)

    def p(section, key, **extra):
        return f"<p>{esc(txt(section, key, **extra))}</p>"

    def h1(t):
        return f"<h1>{esc(t)}</h1>"

    def h2(t):
        return f"<h2>{esc(t)}</h2>"

    def h3(t):
        return f"<h3>{esc(t)}</h3>"

    def fig(name, caption, width=None):
        w = f' style="width:{width}"' if width else ""
        return (f'<div class="figure"><img src="figures/{name}"{w} alt=""></div>'
                f'<div class="figcaption">{esc(caption)}</div>')

    def table(head, rows, caption=None, num_cols=(), total_rows=(), sub_rows=()):
        out = []
        if caption:
            out.append(f'<div class="caption">{esc(caption)}</div>')
        out.append("<table><thead><tr>")
        for i, h in enumerate(head):
            out.append(f'<th class="{"num" if i in num_cols else ""}">{esc(h)}</th>')
        out.append("</tr></thead><tbody>")
        for r_i, r in enumerate(rows):
            cls = "total" if r_i in total_rows else ("sub" if r_i in sub_rows else "")
            out.append(f'<tr class="{cls}">')
            for i, c in enumerate(r):
                out.append(f'<td class="{"num" if i in num_cols else ""}">{esc(str(c))}</td>')
            out.append("</tr>")
        out.append("</tbody></table>")
        return "".join(out)

    cur = [x for x in data["partners"] if x["status"] == "current"]
    assert [x["id"] for x in cur] == list("ABCDEFH")

    # ---------------------------------------------------------------- page 1: cover
    pages[1] = (
        '<div class="cover">'
        f'<div class="programme">{esc(data["funding_programme"])}</div>'
        f'<div class="callid">Call identifier: {esc(data["calls"]["current"])}</div>'
        f'<div class="acronym">{esc(data["proposal"]["acronym"])}</div>'
        f'<div class="ptitle">{esc(data["proposal"]["title"])}</div>'
        f'<div class="submission">Date of submission: {esc(fmt_date_long(data["dates"]["submission_current"]))}</div>'
        f'<div class="resub">Resubmission of the proposal submitted to call {esc(data["calls"]["previous"])} on '
        f'{esc(fmt_date_long(data["dates"]["submission_previous"]))}</div>'
        "</div>"
    )

    # ------------------------------------------------------------ page 2: contents
    toc = [(1, "Response to the previous evaluation", L["response"]), (1, "Executive summary", L["exec_summary"][0]),
           (1, "1 Relevance and objectives", L["sec1"][0])]
    for num, title, pg in L["subsections"]["1"]:
        toc.append((2, f"{num} {title}", pg))
    toc.append((1, "2 Consortium", L["sec2"][0]))
    for num, title, pg in L["subsections"]["2"]:
        toc.append((2, f"{num} {title}", pg))
    toc.append((1, "3 Work plan", L["sec3"][0]))
    for num, title, pg in L["subsections"]["3"]:
        toc.append((2, f"{num} {title}", pg))
    toc.append((1, "4 Impact and market uptake", L["sec4"][0]))
    for num, title, pg in L["subsections"]["4"]:
        toc.append((2, f"{num} {title}", pg))
    sec5 = [("5.1", "Original budget (for reference)", L["sec5_1"][0], 2), ("5.1.1", "Budget principles", L["sec5_1_1"], 3),
            ("5.1.2", "Financial management", L["sec5_1_2"], 3), ("5.1.3", "Audit approach", L["sec5_1_3"], 3),
            ("5.2", "Revised budget", L["sec5_2"][0], 2), ("5.3", "Change justification", L["sec5_3"], 2),
            ("5.4", "Budget by cost category", L["sec5_4"][0], 2)]
    toc.append((1, "5 Budget", L["sec5_1"][0]))
    for num, title, pg, lvl in sec5:
        toc.append((lvl, f"{num} {title}", pg))
    toc += [(1, "Annex A Gantt chart and work packages", L["annex_a_gantt"]),
            (1, "Annex B Deliverables and readiness", L["annex_b_deliverables"][0]),
            (1, "Annex C Risk register", L["annex_c_risks"][0])]
    rows = "".join(f'<tr class="l{lvl}"><td>{esc(t)}</td><td class="pg">{pg}</td></tr>' for lvl, t, pg in toc)
    pages[2] = h1("Table of contents") + f'<table class="toc"><tbody>{rows}</tbody></table>'

    # ------------------------------------------------------------ page 3: response
    bl = "".join(f"<li>{esc(fill(b, ctx))}</li>" for b in prose["response"]["bullets"])
    pages[3] = (h1("Response to the previous evaluation") + p("response", "intro") + f"<ul>{bl}</ul>"
                + p("response", "closing"))

    # --------------------------------------------------- pages 4 to 5: executive summary
    pages[4] = (h1("Executive summary") + p("exec_summary", "p4_intro") + F.take(4, 3, "gen")
                + p("exec_summary", "p4_total") + F.take(4, 3, "gen"))
    pages[5] = p("exec_summary", "p5_intro") + F.take(5, 5, "gen") + p("exec_summary", "p5_close")

    # ------------------------------------------------------------ section 1: pages 6 to 18
    pages[6] = h1("1 Relevance and objectives") + h2("1.1 Context and rationale") + p("sec1", "p6_intro") + F.take(6, 5, "rel")
    pages[7] = fig("fig_1_1.png", prose["sec1"]["fig_1_1_caption"]) + F.take(7, 6, "rel")
    pages[8] = F.take(8, 7, "rel")
    pages[9] = p("sec1", "p9_bridge") + F.take(9, 6, "rel")
    pages[10] = F.take(10, 7, "rel")
    pages[11] = h2("1.2 Readiness assessment") + p("sec1", "p11_readiness") + F.take(11, 5, "rel")
    pages[12] = fig("fig_1_2.png", prose["sec1"]["fig_1_2_caption"]) + p("sec1", "p12_figure") + F.take(12, 3, "gen")
    pages[13] = F.take(13, 7, "rel")
    obj = "".join(f"<li>{esc(w['acronym'])}: {esc(w['objective'])}</li>" for w in WP)
    pages[14] = h2("1.3 Objectives") + p("sec1", "p14_objectives_intro") + f"<ul>{obj}</ul>" + F.take(14, 2, "rel")
    pages[15] = F.take(15, 7, "rel")
    pages[16] = h2("1.4 Approach") + p("sec1", "p16_approach") + F.take(16, 5, "rel")
    pages[17] = F.take(17, 7, "gen")
    pages[18] = F.take(18, 7, "rel")

    # ------------------------------------------------------------ section 2: pages 19 to 26
    rows = []
    for x in cur:
        name = x["legal_name"]
        if x["id"] == "B":
            name = f'{x["legal_name"]} (formerly {x["former_legal_name"]})'
        rows.append([name, x["short_name"], x["acronym"], x["type_label"]])
    pages[19] = (h1("2 Consortium") + h2("2.1 Consortium overview") + p("sec2", "p19_intro")
                 + table(["Legal name", "Short name", "Acronym", "Partner type"], rows, caption="Table 2.1 Consortium partners")
                 + p("sec2", "p19_note"))
    pages[20] = F.take(20, 7, "cons")
    d = lambda k: p("sec2", f"descr_{k}")
    pages[21] = h2("2.2 Description of partners") + d("A") + d("B") + d("C") + F.take(21, 2, "cons")
    pages[22] = d("D") + d("E") + d("F") + F.take(22, 3, "cons")
    pages[23] = d("H") + F.take(23, 6, "cons")
    pages[24] = h2("2.3 Cooperation and decision making") + p("sec2", "p24_cooperation") + F.take(24, 6, "cons")
    pages[25] = F.take(25, 7, "cons")
    pages[26] = F.take(26, 7, "cons")

    # ------------------------------------------------------------ section 3: pages 27 to 34
    def wp_par(w, extra=""):
        t = fill(prose["sec3"]["wp_text"], ctx, wp_acr=w["acronym"], wp_title=w["title"],
                 lead_short=P[w["lead"]]["short_name"], objective=w["objective"])
        if extra:
            t += " " + extra
        return f"<p>{esc(t)}</p>"

    bridge_extra = fill(prose["sec3"]["wp_bridge_extra"], ctx)
    pages[27] = h1("3 Work plan") + h2("3.1 Structure of the work plan") + p("sec3", "p27_intro") + F.take(27, 5, "work")
    pages[28] = (h2("3.2 Work package descriptions") + wp_par(WP[0]) + wp_par(WP[1], bridge_extra) + F.take(28, 3, "work"))
    pages[29] = wp_par(WP[2]) + wp_par(WP[3]) + F.take(29, 5, "work")
    pages[30] = wp_par(WP[4]) + wp_par(WP[5]) + F.take(30, 5, "work")
    pages[31] = F.take(31, 7, "work")
    pages[32] = h2("3.3 Management and coordination") + p("sec3", "p32_management", ) + F.take(32, 6, "work")
    pages[33] = F.take(33, 7, "work")
    pages[34] = F.take(34, 7, "work")

    # ------------------------------------------------------------ section 4: pages 35 to 39
    pages[35] = h1("4 Impact and market uptake") + h2("4.1 Expected impact") + p("sec4", "p35_intro") + F.take(35, 5, "imp")
    pages[36] = F.take(36, 7, "imp")
    pages[37] = h2("4.2 Market uptake") + p("sec4", "p37_mcrl") + F.take(37, 5, "imp")
    pages[38] = h2("4.3 Dissemination and exploitation") + p("sec4", "p38_dissem") + F.take(38, 6, "imp")
    pages[39] = F.take(39, 7, "imp")

    # ------------------------------------------------------------ section 5
    rows = []
    for k in "ABCDEFG":
        x = P[k]
        name = x["former_short_name"] if k == "B" else x["short_name"]
        rows.append([name, fmt_full(x["original"]["requested_cents"])])
    rows.append(["Total", fmt_full(T["original_total_requested_cents"])])
    pages[40] = (h1("5 Budget") + p("sec5", "p40_intro") + h2("5.1 Original budget (for reference)")
                 + p("sec5", "p40_table51")
                 + table(["Partner", "Requested amount (EUR)"], rows, caption=prose["sec5"]["tab51_caption"],
                         num_cols=(1,), total_rows=(len(rows) - 1,)))
    pages[41] = F.take(41, 7, "fin")
    pages[42] = h3("5.1.1 Budget principles") + F.take(42, 7, "fin")
    pages[43] = F.take(43, 7, "fin")
    pages[44] = F.take(44, 7, "fin")
    pages[45] = h3("5.1.2 Financial management") + F.take(45, 7, "fin")
    pages[46] = F.take(46, 7, "fin")
    pages[47] = F.take(47, 7, "fin")
    pages[48] = h3("5.1.3 Audit approach") + F.take(48, 7, "fin")
    pages[49] = F.take(49, 7, "fin")

    # 5.2 revised budget (Table 5.2)
    rows = []
    for x in cur:
        r = x["revised"]
        if x["id"] == "F":
            rows.append([x["short_name"], "0.0", "n/a", "0.0"])
        elif r["shown_as_formula"]:
            rows.append([x["short_name"], fmt_k(r["eligible_costs_cents"]), str(r["funding_rate_percent"]),
                         "calculated at the funding rate"])
        else:
            rows.append([x["short_name"], fmt_k(r["eligible_costs_cents"]), str(r["funding_rate_percent"]),
                         fmt_k(r["requested_cents"])])
    rows.append(["Total", fmt_k(T["total_eligible_costs_cents"]), "", fmt_k(T["revised_total_requested_cents"])])
    pages[50] = (h2("5.2 Revised budget") + p("sec5", "p50_intro")
                 + table(["Partner", "Eligible costs", "Funding rate (%)", "Requested funding"], rows,
                         caption=prose["sec5"]["tab52_caption"], num_cols=(1, 2, 3), total_rows=(len(rows) - 1,))
                 + p("sec5", "p50_totals"))
    pages[51] = fig("fig_5_1.png", prose["sec5"]["fig51_caption"]) + p("sec5", "p51_figure") + F.take(51, 2, "fin")

    # 5.3 changes (Table 5.3)
    ch_rows, ch_total = common.change_table(data)
    rows = [[r["short_name"], r["text"]] for r in ch_rows] + [["Total", ch_total["text"]]]
    chg = {r["id"]: r["change_cents"] for r in ch_rows}
    assert chg["E"] > 0 and all(chg[k] < 0 for k in "ABCDG") and chg["H"] > 0 and chg["F"] == 0
    assert {r["style"] for r in ch_rows if r["style"]} == {"minus", "paren"}
    pages[52] = (h2("5.3 Change justification") + p("sec5", "p52_intro")
                 + table(["Partner", "Change in requested funding"], rows, caption=prose["sec5"]["tab53_caption"],
                         num_cols=(1,), total_rows=(len(rows) - 1,)) + p("sec5", "p52_reasons"))

    # 5.4 cost categories (Table 5.4)
    rows = [[c["name"], fmt_k(c["cents"])] for c in data["cost_categories"]]
    rows += [["Total eligible costs", fmt_k(T["total_eligible_costs_cents"])],
             ["Costs that are not eligible", fmt_k(T["ineligible_costs_cents"])],
             ["Total budget", fmt_k(T["total_budget_cents"])],
             ["Costs of the associated partner", fmt_k(T["associated_partner_costs_cents"])],
             ["Total project cost", fmt_k(T["total_project_cost_cents"])]]
    n_cat = len(data["cost_categories"])
    pages[53] = (h2("5.4 Budget by cost category") + p("sec5", "p53_intro")
                 + table(["Cost category", "Amount"], rows, caption=prose["sec5"]["tab54_caption"], num_cols=(1,),
                         sub_rows=(n_cat, n_cat + 2), total_rows=(n_cat + 4,)))
    pages[54] = p("sec5", "p54_note") + F.take(54, 6, "fin")

    # ------------------------------------------------------------ annexes
    pages[55] = (h1("Annex A Gantt chart and work packages") + p("annex", "a_intro")
                 + fig("fig_a1_gantt.png", prose["annex"]["figa1_caption"], width="150mm"))

    def wp_table(i, w):
        part = ", ".join(P[k]["short_name"] for k in w["participants"] if P[k]["status"] == "current")
        tasks = "; ".join(f'{t["name"]} (months {t["start"]} to {t["end"]})' for t in w["tasks"])
        dels = "; ".join(f'{d["title"]} (month {d["month"]})' for d in w["deliverables"])
        rows = [["Work package", f'{w["id"]} {w["acronym"]}, {w["title"]}'], ["Lead partner", P[w["lead"]]["short_name"]],
                ["Participants", part], ["Duration", f'Month {w["start"]} to month {w["end"]}'],
                ["Objective", w["objective"]], ["Tasks", tasks], ["Deliverables", dels]]
        t = (f'<div class="caption">Table A{i} {esc(w["id"])} {esc(w["acronym"])}</div><table><tbody>'
             + "".join(f'<tr><th style="width:32mm">{esc(a)}</th><td>{esc(b)}</td></tr>' for a, b in rows) + "</tbody></table>")
        return t

    pages[56] = wp_table(1, WP[0]) + wp_table(2, WP[1]) + wp_table(3, WP[2])
    pages[57] = wp_table(4, WP[3]) + wp_table(5, WP[4]) + wp_table(6, WP[5])
    pages[58] = F.take(58, 7, "work")

    rows = []
    for w in WP:
        for j, dl in enumerate(w["deliverables"], 1):
            rows.append([f'D{w["id"][2:]}.{j}', dl["title"], w["id"], str(dl["month"])])
    pages[59] = (h1("Annex B Deliverables and readiness") + p("annex", "b_intro")
                 + table(["Deliverable", "Title", "Work package", "Due month"], rows, caption="Table B1 Deliverables",
                         num_cols=(3,)))
    pages[60] = h2("Quality of deliverables") + F.take(60, 6, "work")
    rows = [["Technology readiness level (TRL) at the end of the project", str(data["readiness"]["trl_target"])],
            ["Regional test areas in operation", str(data["outputs"]["test_areas"])]]
    pages[61] = (h2("Targets for the end of the project") + p("annex", "b2_intro")
                 + table(["Indicator", "Target"], rows, caption="Table B2 Targets for the end of the project", num_cols=(1,))
                 + F.take(61, 3, "gen"))
    rows = [[r["id"], r["title"], r["likelihood"], r["impact"], r["mitigation"]] for r in data["risks"]]
    pages[62] = (h1("Annex C Risk register") + p("annex", "c_intro")
                 + table(["Risk", "Description", "Likelihood", "Impact", "Planned measure"], rows, caption="Table C1 Risk register"))
    pages[63] = F.take(63, 6, "risk")

    assert sorted(pages) == list(range(1, L["total_pages"] + 1)), sorted(pages)
    return [pages[i] for i in range(1, L["total_pages"] + 1)], F


def main():
    OUT.mkdir(exist_ok=True)
    data, prose, bank = common.load_data(), common.load_prose(), common.load_bank()

    errs = scan_prose.scan_filler(bank, data) + scan_prose.scan_prose(prose, data)
    if errs:
        for e in errs:
            print("PROSE SCAN FAIL", e)
        sys.exit(1)
    print("prose scan passed")

    subprocess.run([sys.executable, str(ROOT / "SP04_charts.py")], check=True)

    pages, F = build_pages(data, prose, bank)
    css = (ROOT / "SP04_template" / "style.css").read_text(encoding="utf-8").replace("__FOOTER_TEXT__", data["footer_text"])
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(ROOT / "SP04_template")), autoescape=False)
    html_doc = env.get_template("doc.html.j2").render(meta=data["pdf_metadata"], css=css, pages=pages)
    (OUT / "SP04.html").write_text(html_doc, encoding="utf-8")

    from weasyprint import HTML
    ident = hashlib.sha256(html_doc.encode("utf-8")).digest()[:16]
    doc = HTML(string=html_doc, base_url=str(OUT) + "/").render()
    try:
        doc.write_pdf(str(OUT / "SP04.pdf"), pdf_identifier=ident)
    except TypeError:
        doc.write_pdf(str(OUT / "SP04.pdf"))
    print("pages rendered:", len(doc.pages))
    (OUT / "SP04_filler_selection.json").write_text(json.dumps({str(k): v for k, v in sorted(F.log.items())}, indent=1))

    import make_outputs
    make_outputs.main()
    print("build finished")


if __name__ == "__main__":
    main()
