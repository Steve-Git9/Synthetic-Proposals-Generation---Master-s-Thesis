# Datasheet for SP04

Following Gebru et al. (2021), Datasheets for Datasets. Version 1.0 (release candidate, not yet frozen).

## Summary

SP04 is a synthetic project proposal of 63 pages, born digital PDF, English with European spelling. It is a revised resubmission after a rejection, so it holds values from two rounds: the original round (old budget, old consortium, old call, old date) and the revised round (current values, the extraction targets). It was built to test whether a language model extraction pipeline picks the current values and ignores the historical ones, with a ground truth that is correct by construction. It is one of five synthetic documents in a set.

## Motivation

- Purpose: a controlled test document for the master thesis on language model assisted extraction of structured data from research project proposals (Haaga-Helia, MCI, Universidad de Sevilla, commissioned by CLIC Innovation Oy). It exists only to expose extraction pipelines to known difficulties. It is never submitted to any real call.
- Author: Stefano Fanelli (researcher). Narrative text, names and code were produced with language model assistance; every call is logged in `SP04_generation_log.md`.
- Funding: none specific to this document.

## Composition

- One PDF (`SP04.pdf`), with an answer key (`SP04_answer_key.json`), a manifest of injected difficulties (`SP04_manifest.csv`) and a synthetic partner register (`SP04_partner_register.csv`).
- Instances: one document. Target fields: proposal acronym, title, call identifier, funding programme, submission date, stated total requested amount, TRL start, TRL target, MCRL start, MCRL target (null by design), and for each of the seven current partners the name as written and the requested amount.
- Fictional content: all organisations, persons, projects and call identifiers are fictional. The funding programme name "Interreg Baltic Sea Region" is a real public programme; no real priority, objective or rule of that programme is named. There are no personal data and no named individuals.
- Page map: cover (1), contents (2), response to the previous evaluation (3), executive summary (4 to 5), relevance and objectives (6 to 18), consortium (19 to 26), work plan (27 to 34), impact and market uptake (35 to 39), original budget (40 to 41), budget filler (42 to 49), revised budget (50 to 51), change justification (52), cost categories (53 to 54), annexes (55 to 63).
- Footer on every page: "Synthetic document for research purposes, ID SP04, version 1.0". This string is a known non target string in the answer key.

## Collection and creation process

1. `make_data.py` draws all numbers with a fixed seed (40404) and writes `SP04_data.yaml`, the single source of every number, date, name and acronym in the document. The draw respects the ranges of the task prompt (revised total between EUR 2,000,000 and 4,000,000; original total 5 to 15 percent higher; funding rates 60 to 80 percent; partner H amount exact in euro cents).
2. `build.py` renders the document from the data file, the crafted prose (`SP04_prose.yaml`), the paragraph bank and the template folder, using HTML and CSS to PDF. The build never calls a language model, and two builds give byte identical PDFs.
3. `SP04_charts.py` draws every figure with matplotlib from the same data file. Text inside the figures is part of the raster image.
4. A prose scanner fails the build if any model written prose contains a number, date, organisation name or acronym that does not come from the data file.
5. `verify.py` runs the automatic checks. Human checks are still open (see Maintenance).

## Which parts are filler

- Filler is selected from a bank of 54 neutral paragraphs (`SP04_paragraph_bank.md`) with the seed. It appears on 50 of 63 pages (pages 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 54, 58, 60, 61, 63) as 291 placements of paragraphs, about 82 percent of the words in the PDF text layer. Each of the 54 paragraphs is used 5 or 6 times, because the task prompt allows repeats. This repetition may be noticed by a careful reader.
- Filler contains no numbers, dates, organisation names, acronyms, or the words original, previous, revised and resubmission.
- Crafted elements, in the sense of the task prompt: target fields, distractors and injected difficulties. They sit on the cover, response page, executive summary, sections 1.2, 2.1, 4.2, 5.1 to 5.4, Figure 1.2, Figure 5.1 and Annex B.
- Annex content (work package tables, deliverables, risk register, Gantt chart) is generated from the data file with repeatable structures. No CVs.

## Injected difficulties and their literature

Issue numbers and source papers come from the thesis literature list.

| # | Issue | Difficulty | Source papers | Planned pages |
|---|---|---|---|---|
| 1 | #12 | Same figures in several tables | DocILE (Šimsa et al., 2023) | 50, 51, 52, 53 |
| 2 | #14 | Scale differs between tables | TAT-QA (Zhu et al., 2021), Kleister (Stanisławek et al., 2021) | 40, 50, 52 |
| 3 | #15 | Stale value | VRDU (Wang et al., 2023), TAT-QA (Zhu et al., 2021), Kleister (Stanisławek et al., 2021) | 1, 4 |
| 4 | #16 and #25 | Overlapping terms | VRDU (Wang et al., 2023) | 50, 53, 54 |
| 5 | #17 | Sign of values | TAT-QA (Zhu et al., 2021) | 52 |
| 6 | #19 | Domain knowledge | TAT-QA (Zhu et al., 2021), MMLongBench-Doc (Ma et al., 2024) | 50 |
| 7 | #18 and #20 | Table plus text, renamed partner | TAT-QA (Zhu et al., 2021), MMLongBench-Doc (Ma et al., 2024), Kleister (Stanisławek et al., 2021) | 19, 40, 50 |
| 8 | #24 and #30 | Withdrawn partner and entity ambiguity | Kleister (Stanisławek et al., 2021), VRDU (Wang et al., 2023), DocILE (Šimsa et al., 2023), MMLongBench-Doc (Ma et al., 2024) | 3, 40, 51, 52 |
| 9 | #20 and #30 | Acronym collisions | Kleister (Stanisławek et al., 2021), MMLongBench-Doc (Ma et al., 2024) | 1, 9, 28, 56 |
| 10 | #8 and #26 | Value only in an image | MMLongBench-Doc (Ma et al., 2024), Kleister (Stanisławek et al., 2021) | 12 |
| 11 | #27 | Cross reference | MMLongBench-Doc (Ma et al., 2024) | 11, 61 |
| 12 | #24 and #29 | Absent field | MMLongBench-Doc (Ma et al., 2024) | none (field is null) |
| 13 | #24 | Zero funded partner | Kleister (Stanisławek et al., 2021), VRDU (Wang et al., 2023), DocILE (Šimsa et al., 2023) | 40, 50 |

## Preprocessing, cleaning and labelling

Labels are generated from the data file by `make_outputs.py`. Each target value in `SP04_answer_key.json` carries field, value (euro cents for amounts, ISO 8601 for dates), page, location type (text, table or figure), exact surface string, the authority rule applied and a list of distractors with page, surface string and round (original or revised). The authority rules are written into the answer key header. The correct extraction of MCRL target is null.

Partner G (withdrawn) has no entry in the answer key. It appears in the response (page 3), Table 5.1 (page 40), Table 5.3 (page 52) and Figure 5.1 (page 51, image only), as decided by the researcher.

## Uses

- Intended use: evaluating extraction pipelines on the thesis tasks: choosing current over historical values, resolving scale differences, reading values that exist only in an image, following a cross reference, computing a value from a formula, handling a renamed and a withdrawn partner, and returning null for an absent field.
- Not intended: training models, estimating real world accuracy, or any submission to a real call.
- Rule: the document must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.

## Limitations

- Results on author written synthetic documents are not evidence about real proposals. Results must be reported separately for authorised real documents and synthetic documents.
- One layout only, English only, born digital PDF only. Real proposals have more varied layouts, scans and styles.
- Filler paragraphs repeat (5 to 6 times each), and pages are less dense than many real proposals.
- The sentence below Table 5.2 states "thousand" next to the total, so the scale is not hidden for that one value. The cells of Tables 5.2 to 5.4 state the scale only in the captions.
- Page positions are fixed by the build. Other fonts or library versions may change line breaks; rebuild and re run `verify.py` in that case.
- Fictional names have not yet been checked against the Finnish Trade Register or a web search (open human step).

## Distribution and licence

Licence: not yet chosen. Suggestion for the author to confirm before any release: CC BY 4.0 for the document, data and answer key, and MIT for the scripts. Business confidential material of CLIC Innovation is not used anywhere in this document.

## Maintenance

- Version 1.0 is a release candidate. Open human steps before the freeze: visual legibility check of Figure 1.2, blind second extraction (form in `out/SP04_blind_extraction_form.csv`), realism review (`out/SP04_realism_checklist.md`), name check (`out/SP04_name_check_list.md`).
- After the freeze, no file is edited. Any later change creates a new version recorded in `CHANGELOG.md`.
- Owner: Stefano Fanelli.
