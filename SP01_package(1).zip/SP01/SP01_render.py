#!/usr/bin/env python3
"""Render SP01 from SP01_data.yaml and the template, compile with XeLaTeX, and fit the page map.

Usage:
    python3 SP01_render.py fit      tune the filler counts to the page map, then build the final PDF
    python3 SP01_render.py build    build once with the filler counts stored in the data file
"""
import os
import random
import re
import shutil
import subprocess
import sys

import yaml

from sp01_common import (ROOT, TEMPLATE_DIR, BUILD_DIR, OUT_DIR, load_data, save_data, load_bank,
                         dotted_get, latex_escape, eur_thousand_1dp)

SOURCE_DATE_EPOCH = "1792886400"  # fixed so that the PDF bytes do not depend on the build time

POOLS = {
    "exec": "IDCR", "s1": "IDCR", "s2": "IDCR", "s3": "IDCR", "budget": "C", "s4": "IDCR",
    "annex": "IDCR",
}
GROUP_SIZE = 4  # filler paragraphs per generic sub heading

PARTS = ["exec", "sec1", "sec2", "sec3", "budget", "sec4", "annexes"]
PART_TARGET_KEY = {"exec": "exec_summary", "sec1": "section1", "sec2": "section2",
                   "sec3": "section3", "budget": "budget", "sec4": "section4", "annexes": "annexes"}
PART_PAD_SLOT = {"exec": "exec_pad", "sec1": "s1_pad", "sec2": "s2_pad", "sec3": "s3_pad",
                 "budget": "budget_pad", "sec4": "s4_pad", "annexes": "annex_pad"}


# ------------------------------------------------------------------ helpers for generated blocks
def tex(s):
    return latex_escape(s)


def fig_block(name, caption, width="0.92\\textwidth"):
    return ("\\begin{center}\n\\includegraphics[width=%s]{%s.png}\n\\captionof{figure}{%s}\n"
            "\\end{center}\n" % (width, name, tex(caption)))


def gen_fig_concept(ctx):
    return fig_block("fig_concept", ctx["text_banks"]["figure_captions"]["concept"], "0.95\\textwidth")


def gen_fig_impact(ctx):
    return fig_block("fig_impact", ctx["text_banks"]["figure_captions"]["impact"], "0.85\\textwidth")


def gen_fig_workplan(ctx):
    return fig_block("fig_workplan", ctx["text_banks"]["figure_captions"]["workplan"], "0.95\\textwidth")


def gen_fig_gantt(ctx):
    return fig_block("gantt", ctx["text_banks"]["figure_captions"]["gantt"], "0.98\\textwidth")


def gen_objectives_table(ctx):
    rows = ctx["text_banks"]["objectives_table"]
    out = ["\\begin{center}\\small\\renewcommand{\\arraystretch}{1.25}",
           "\\begin{tabular}{@{}p{0.6cm}p{8.4cm}p{6.6cm}@{}}", "\\toprule",
           "\\textbf{No} & \\textbf{Objective} & \\textbf{Indicator} \\\\", "\\midrule"]
    for i, r in enumerate(rows, 1):
        out.append("O%d & %s & %s \\\\" % (i, tex(r["objective"]), tex(r["indicator"])))
    out += ["\\bottomrule", "\\end{tabular}", "\\end{center}",
            "\\captionof{table}{Objectives of the project and how their achievement is judged.}"]
    return "\n".join(out)


def gen_impact_table(ctx):
    rows = ctx["text_banks"]["impact_table"]
    out = ["\\begin{center}\\small\\renewcommand{\\arraystretch}{1.25}",
           "\\begin{tabular}{@{}p{3.2cm}p{8.2cm}p{4.2cm}@{}}", "\\toprule",
           "\\textbf{Pathway} & \\textbf{Description} & \\textbf{Main audience} \\\\", "\\midrule"]
    for r in rows:
        out.append("%s & %s & %s \\\\" % (tex(r["pathway"]), tex(r["description"]), tex(r["audience"])))
    out += ["\\bottomrule", "\\end{tabular}", "\\end{center}",
            "\\captionof{table}{Impact pathways and the audiences they address.}"]
    return "\n".join(out)


def _partner(ctx, no):
    return ctx["partners"][no - 1]


def gen_wp_text(ctx):
    tb = ctx["text_banks"]
    out = []
    for w in ctx["work_packages"]:
        lead = _partner(ctx, w["lead"])["short_name"]
        s1 = _partner(ctx, w["support"][0])["short_name"]
        s2 = _partner(ctx, w["support"][1])["short_name"]
        out.append("\\subsubsection{WP%d: %s}" % (w["no"], tex(w["title"])))
        out.append("\\textbf{Duration:} month %d to month %d. \\textbf{Lead:} %s.\\par" %
                   (w["start"], w["end"], tex(lead)))
        out.append(tex(tb["wp_objectives"][w["no"]]) + "\\par")
        titles = tb["wp_task_titles"][w["no"]]
        span = w["end"] - w["start"]
        for k, tpl in enumerate(tb["wp_task_templates"]):
            t_start = w["start"] + (span * k) // 3
            t_end = w["start"] + (span * (k + 1)) // 3
            sent = (tpl.replace("{lead:short}", lead).replace("{sup1:short}", s1)
                    .replace("{sup2:short}", s2).replace("{start:m}", str(t_start))
                    .replace("{end:m}", str(t_end)))
            out.append("\\textbf{Task %d.%d, %s.} %s\\par" % (w["no"], k + 1, tex(titles[k]), tex(sent)))
    return "\n\n".join(out)


def _cap(s):
    return s[0].upper() + s[1:]


def gen_consortium_table(ctx):
    out = ["\\begin{center}\\footnotesize\\setlength{\\tabcolsep}{3pt}\\renewcommand{\\arraystretch}{1.5}",
           "\\begin{tabular}{@{}p{0.7cm}p{8.4cm}p{2.0cm}p{2.8cm}p{2.0cm}@{}}", "\\toprule",
           "\\textbf{No} & \\textbf{Legal name} & \\textbf{Country} & \\textbf{Type} & \\textbf{Role} \\\\",
           "\\midrule"]
    for p in ctx["partners"]:
        out.append("%d & %s & %s & %s & %s \\\\" % (
            p["no"], tex(p["legal_name"]), tex(p["country"]), tex(_cap(p["category"])), tex(p["role"])))
    out += ["\\bottomrule", "\\end{tabular}", "\\end{center}",
            "\\captionof{table}{Participating organisations, their countries and their roles.}"]
    return "\n".join(out)


def gen_budget_table(ctx):
    num = ">{\\raggedleft\\arraybackslash}p{%scm}"
    spec = ("@{}>{\\raggedright\\arraybackslash}p{0.5cm}>{\\raggedright\\arraybackslash}p{5.7cm}"
            + num % "1.3" + num % "1.75" + num % "1.3" + num % "1.3" + num % "1.4"
            + num % "1.75" + "@{}")
    cols = ["personnel", "subcontracting", "other_direct", "indirect", "total_eligible"]
    out = ["{\\footnotesize\\setlength{\\tabcolsep}{3pt}\\renewcommand{\\arraystretch}{2.1}",
           "\\captionof{table}{Budget by partner and cost category. All amounts in EUR thousand.}",
           "\\begin{longtable}{%s}" % spec,
           "\\toprule",
           " & & \\multicolumn{5}{c}{\\textbf{Costs}} & \\\\",
           "\\cmidrule(lr){3-7}",
           "{\\scriptsize\\textbf{No}} & {\\scriptsize\\textbf{Partner}} & {\\scriptsize\\textbf{Personnel}} & "
           "{\\scriptsize\\textbf{Subcontracting}} & {\\scriptsize\\textbf{Other direct costs}} & "
           "{\\scriptsize\\textbf{Indirect costs}} & {\\scriptsize\\textbf{Total eligible costs}} & "
           "{\\scriptsize\\textbf{Requested contribution}} \\\\",
           "\\midrule",
           "\\endfirsthead",
           "\\endhead"]
    break_after_groups = {"Companies", "Research organisations"}
    for g in ctx["group_order"]:
        out.append("\\multicolumn{8}{@{}l}{\\cellcolor{mist}\\textbf{%s}} \\\\" % tex(g))
        members = [p for p in ctx["partners"] if p["group"] == g]
        for p in members:
            cells = [str(p["no"]), tex(p["legal_name"])]
            cells += [eur_thousand_1dp(p["costs_cents"][c]) for c in cols]
            cells.append(tex(p["budget_cell_requested"]))
            out.append(" & ".join(cells) + " \\\\")
            out.append("\\cmidrule[0.3pt]{1-8}")
        if g in break_after_groups:
            out.append("\\noalign{\\penalty-10000}")
    ct = ctx["surface"]["col_totals_k"]
    out.append("\\midrule")
    out.append("\\multicolumn{2}{@{}l}{\\textbf{Total}} & " + " & ".join("\\textbf{%s}" % ct[c] for c in cols)
               + " & \\textbf{%s} \\\\" % ctx["surface"]["budget_total_requested_k"])
    out += ["\\bottomrule", "\\end{longtable}", "}"]
    out.append("\\textit{Notes to this table are given in section~\\ref{sub:notes}.}")
    return "\n".join(out)


def gen_budget_notes(ctx):
    tb = ctx["text_banks"]["budget_notes"]
    n3 = _partner(ctx, ctx["totals"]["note3_partner_no"])
    note3 = ("%s %d, %s, amounts to %s and %s" % (
        tb["note3_pre"], n3["no"], n3["short_name"], ctx["surface"]["note3_amount"], tb["note3_post"]))
    notes = [("Note 1", tb["note1"]), ("Note 2", tb["note2"]), ("Note 3", note3), ("Note 4", tb["note4"])]
    out = ["The following notes explain entries in the budget table."]
    for label, text in notes:
        out.append("\\textbf{%s.} %s\\par" % (label, tex(text)))
    return "\n\n".join(out)


def _due(w, k):
    span = w["end"] - w["start"]
    return w["start"] + (span * (k + 1)) // 3


def gen_wp_tables(ctx):
    tb = ctx["text_banks"]
    out = []
    for w in ctx["work_packages"]:
        lead = _partner(ctx, w["lead"])["short_name"]
        tasks = "; ".join("%d.%d %s" % (w["no"], k + 1, t) for k, t in enumerate(tb["wp_task_titles"][w["no"]]))
        out.append("\\begin{center}\\small\\renewcommand{\\arraystretch}{1.25}")
        out.append("\\begin{tabular}{@{}p{3.3cm}p{12.2cm}@{}}\\toprule")
        out.append("\\multicolumn{2}{@{}l}{\\textbf{WP%d: %s}} \\\\ \\midrule" % (w["no"], tex(w["title"])))
        out.append("Lead participant & %s \\\\" % tex(lead))
        out.append("Start month & %d \\\\" % w["start"])
        out.append("End month & %d \\\\" % w["end"])
        out.append("Objective & %s \\\\" % tex(tb["wp_objectives"][w["no"]]))
        out.append("Tasks & %s \\\\" % tex(tasks))
        out.append("\\bottomrule\\end{tabular}\\end{center}")
    return "\n".join(out)


def gen_deliverables(ctx):
    tb = ctx["text_banks"]
    out = ["{\\small\\setlength{\\tabcolsep}{4pt}\\renewcommand{\\arraystretch}{1.3}",
           "\\begin{longtable}{@{}p{1.2cm}p{6.6cm}p{1.0cm}p{2.2cm}p{2.8cm}p{1.6cm}@{}}", "\\toprule",
           "\\textbf{ID} & \\textbf{Title} & \\textbf{WP} & \\textbf{Type} & \\textbf{Dissemination} & "
           "\\textbf{Due month} \\\\ \\midrule", "\\endhead"]
    for w in ctx["work_packages"]:
        for k, title in enumerate(tb["deliverable_titles"][w["no"]]):
            out.append("D%d.%d & %s & %d & %s & %s & %d \\\\" % (
                w["no"], k + 1, tex(title), w["no"], tex(tb["deliverable_types"][w["no"] - 1]),
                tex(tb["deliverable_dissemination"][w["no"] - 1]), _due(w, k)))
    out += ["\\bottomrule", "\\end{longtable}", "}"]
    return "\n".join(out)


def gen_risks(ctx):
    rows = ctx["text_banks"]["risk_register"]
    out = ["{\\small\\setlength{\\tabcolsep}{4pt}\\renewcommand{\\arraystretch}{1.35}",
           "\\begin{longtable}{@{}p{0.9cm}p{5.2cm}p{1.6cm}p{1.4cm}p{6.1cm}p{0.8cm}@{}}", "\\toprule",
           "\\textbf{ID} & \\textbf{Risk} & \\textbf{Likelihood} & \\textbf{Impact} & \\textbf{Mitigation} & "
           "\\textbf{WP} \\\\ \\midrule", "\\endhead"]
    nwp = len(ctx["work_packages"])
    for i, r in enumerate(rows, 1):
        out.append("R%d & %s & %s & %s & %s & %d \\\\" % (
            i, tex(r["risk"]), tex(r["likelihood"]), tex(r["impact"]), tex(r["mitigation"]), (i - 1) % nwp + 1))
    out += ["\\bottomrule", "\\end{longtable}", "}"]
    return "\n".join(out)


TOC_ENTRIES = [
    ("Executive summary", "exec", 0),
    ("1 Excellence", "sec:s1", 0),
    ("1.1 Objectives", "sub:obj", 1), ("1.2 Relation to the work programme", "sub:rel", 1),
    ("1.3 Concept and methodology", "sub:concept", 1), ("1.4 Ambition and novelty", "sub:amb", 1),
    ("2 Impact", "sec:s2", 0),
    ("2.1 Expected impacts", "sub:impacts", 1), ("2.2 Measures to maximise impact", "sub:measures", 1),
    ("2.3 Communication and exploitation", "sub:comm", 1),
    ("3 Implementation", "sec:s3", 0),
    ("3.1 Work plan", "sub:workplan", 1), ("3.2 Work packages and tasks", "sub:wps", 1),
    ("3.3 Consortium", "sub:consortium", 1), ("3.4 Management structure", "sub:mgmt", 1),
    ("3.5 Budget", "sub:budget", 1),
    ("4 Ethics, security and management", "sec:s4", 0),
    ("4.1 Ethics and security", "sub:ethics", 1), ("4.2 Budget notes and management", "sub:notes", 1),
    ("4.3 Data management", "sub:data", 1),
    ("Annexes", "part:annexes", 0),
    ("Annex A: Gantt chart", "annex:a", 1), ("Annex B: Work package tables", "annex:b", 1),
    ("Annex C: List of deliverables", "annex:c", 1), ("Annex D: Risk register", "annex:d", 1),
    ("Annex E: Supplementary notes", "annex:e", 1),
]


def gen_toc(ctx):
    out = ["{\\small\\linespread{1.0}\\selectfont"]
    for title, label, level in TOC_ENTRIES:
        indent = "1.2em" if level else "0em"
        font = "" if level else "\\bfseries"
        out.append("\\noindent\\hspace*{%s}{%s %s}\\dotfill\\pageref{%s}\\par\\vspace{0.15em}" % (
            indent, font, tex(title), label))
    out.append("}")
    return "\n".join(out)


GENERATORS = {
    "fig_concept": gen_fig_concept, "fig_impact": gen_fig_impact, "fig_workplan": gen_fig_workplan,
    "fig_gantt": gen_fig_gantt, "objectives_table": gen_objectives_table,
    "impact_table": gen_impact_table, "wp_text": gen_wp_text, "consortium_table": gen_consortium_table,
    "budget_table": gen_budget_table, "budget_notes": gen_budget_notes, "wp_tables": gen_wp_tables,
    "deliverables": gen_deliverables, "risks": gen_risks, "toc": gen_toc,
}


# ------------------------------------------------------------------ filler selection
SLOT_ORDER = {
    "exec": ["exec_a", "exec_pad"],
    "s1": ["s1_a", "s1_b", "s1_c", "s1_pad"],
    "s2": ["s2_a", "s2_b", "s2_pad"],
    "s3": ["s3_a", "s3_b", "s3_pad"],
    "budget": ["budget_a", "budget_pad"],
    "s4": ["s4_a", "s4_b", "s4_pad"],
    "annex": ["annex_pad"],
}


def section_sequence(bank, seed, section, length):
    """One seeded sequence per section: shuffled cycles of the pool, so that a paragraph repeats
    only after the whole pool has been used within that section."""
    prefix = POOLS[section]
    pool = [(pid, text) for pid, text in bank if pid[0] in prefix]
    rng = random.Random(f"{seed}:{section}")
    seq = []
    last = None
    while len(seq) < length:
        order = pool[:]
        rng.shuffle(order)
        if last is not None and order[0][0] == last:
            order.append(order.pop(0))
        seq.extend(order)
        last = order[-1][0]
    return seq[:length]


def render_filler(bank, seed, slot, counts, headings):
    n = counts.get(slot, 0)
    if n <= 0:
        return ""
    section = slot.split("_")[0]
    order = SLOT_ORDER[section]
    offset = sum(counts.get(x, 0) for x in order[:order.index(slot)])
    seq = section_sequence(bank, seed, section, offset + n)[offset:offset + n]
    hrng = random.Random(f"{seed}:{slot}:headings")
    hs = headings[:]
    hrng.shuffle(hs)
    blocks = []
    for i, (_, text) in enumerate(seq):
        if i > 0 and i % GROUP_SIZE == 0:
            blocks.append("\\subsubsection{%s}" % tex(hs[(i // GROUP_SIZE - 1) % len(hs)]))
        blocks.append(tex(text))
    return "\n\n".join(blocks)


# ------------------------------------------------------------------ rendering and compiling
def make_context(data):
    ctx = dict(data)
    ctx["text_banks"] = yaml.safe_load((TEMPLATE_DIR / "text_banks.yaml").read_text(encoding="utf-8"))
    return ctx


def render(data, counts=None):
    ctx = make_context(data)
    bank = load_bank()
    counts = counts or ctx["layout"]["filler_counts"]
    BUILD_DIR.mkdir(exist_ok=True)
    seed = data["meta"]["seed"]
    for path in TEMPLATE_DIR.glob("*.tex"):
        text = path.read_text(encoding="utf-8")
        text = re.sub(r"\[\[GEN:([a-z_]+)\]\]", lambda m: GENERATORS[m.group(1)](ctx), text)
        text = re.sub(r"\[\[FILLER:([a-z0-9_]+)\]\]",
                      lambda m: render_filler(bank, seed, m.group(1), counts,
                                              ctx["text_banks"]["filler_headings"]), text)
        text = re.sub(r"<<([A-Za-z0-9_.]+)>>", lambda m: tex(dotted_get(ctx, m.group(1))), text)
        (BUILD_DIR / path.name).write_text(text, encoding="utf-8")


def compile_pdf(runs=2):
    env = dict(os.environ, SOURCE_DATE_EPOCH=SOURCE_DATE_EPOCH, FORCE_SOURCE_DATE="1")
    for _ in range(runs):
        r = subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", "main.tex"],
                           cwd=BUILD_DIR, env=env, capture_output=True, text=True)
        if r.returncode != 0:
            tail = "\n".join(r.stdout.splitlines()[-40:])
            raise RuntimeError("xelatex failed:\n" + tail)


def read_labels():
    aux = (BUILD_DIR / "main.aux").read_text(encoding="utf-8", errors="replace")
    labels = {}
    for m in re.finditer(r"\\newlabel\{([^}]+)\}\{\{[^{}]*\}\{(\d+)\}", aux):
        labels[m.group(1)] = int(m.group(2))
    return labels


def part_pages(labels):
    """Return {part: (start_page, end_page)} using the part labels and the last page label."""
    starts = {"cover": 1, "toc": labels["part:toc"], "exec": labels["exec"]}
    names = ["exec", "sec1", "sec2", "sec3", "budget", "sec4", "annexes"]
    start_of = {"exec": labels["exec"], "sec1": labels["part:sec1"], "sec2": labels["part:sec2"],
                "sec3": labels["part:sec3"], "budget": labels["part:budget"],
                "sec4": labels["part:sec4"], "annexes": labels["part:annexes"]}
    result = {}
    for i, n in enumerate(names):
        end = (start_of[names[i + 1]] - 1) if i + 1 < len(names) else labels["lastpage"]
        result[n] = (start_of[n], end)
    return result, starts


def fit(data):
    counts = dict(data["layout"]["filler_counts"])
    pm = data["layout"]["page_map"]
    targets = {p: pm[PART_TARGET_KEY[p]][1] - pm[PART_TARGET_KEY[p]][0] + 1 for p in PARTS}
    lo = {p: 0 for p in PARTS}
    hi = {p: 160 for p in PARTS}
    for it in range(10):
        trial = dict(counts)
        for p in PARTS:
            trial[PART_PAD_SLOT[p]] = (lo[p] + hi[p] + 1) // 2
        render(data, trial)
        compile_pdf(runs=2)
        pages, starts = part_pages(read_labels())
        print(f"fit iteration {it + 1}: " + ", ".join(
            f"{p}={pages[p][1] - pages[p][0] + 1}/{targets[p]}@{trial[PART_PAD_SLOT[p]]}" for p in PARTS))
        for p in PARTS:
            n = trial[PART_PAD_SLOT[p]]
            used = pages[p][1] - pages[p][0] + 1
            if used <= targets[p]:
                lo[p] = n
            else:
                hi[p] = n - 1
        if all(lo[p] >= hi[p] for p in PARTS):
            break
    for p in PARTS:
        counts[PART_PAD_SLOT[p]] = lo[p]
    data["layout"]["filler_counts"] = counts
    save_data(data)
    render(data, counts)
    compile_pdf(runs=2)
    return data


def finalize_placements(data):
    labels = read_labels()
    pages, _ = part_pages(labels)
    data["placements"] = dict(
        part_pages={k: list(v) for k, v in pages.items()},
        labels={k: v for k, v in labels.items() if not k.startswith("Hfootnote")},
        total_pages=labels["lastpage"],
    )
    save_data(data)


def copy_pdf():
    OUT_DIR.mkdir(exist_ok=True)
    shutil.copyfile(BUILD_DIR / "main.pdf", ROOT / "SP01.pdf")


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "build"
    data = load_data()
    if mode == "fit":
        data = fit(data)
    else:
        render(data)
        compile_pdf(runs=2)
    finalize_placements(load_data())
    copy_pdf()
    print("SP01.pdf written")


if __name__ == "__main__":
    main()
