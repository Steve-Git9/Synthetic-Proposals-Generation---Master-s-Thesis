#!/usr/bin/env python3
"""Prose check for SP01.

Scans all model written prose (the paragraph bank and the text banks in the template)
and fails with a non zero exit code if it finds a number, a date, an organisation name,
an acronym, or a word that could leak a target field. Placeholders of the form {short:3}
or <<path>> are removed before the scan and are checked against the data file.
"""
import re
import sys
import yaml
from sp01_common import load_bank, load_data, dotted_get, TEMPLATE_DIR

NUMBER_WORDS = {
    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
    "nineteen", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety",
    "hundred", "thousand", "million", "billion", "first", "second", "third", "once", "twice",
    "half", "single",
}
MONTHS = {
    "january", "february", "march", "april", "may", "june", "july", "august", "september",
    "october", "november", "december", "monday", "tuesday", "wednesday", "thursday", "friday",
    "saturday", "sunday",
}
LEAK_WORDS = {
    "horizon", "european", "europe", "commission", "readiness", "trl", "mcrl", "euro", "eur",
}
PLACEHOLDER = re.compile(r"\{[a-z_0-9]+:[A-Za-z0-9_.]+\}|<<[A-Za-z0-9_.]+>>")


def scan_text(label, text, data, problems):
    for ph in PLACEHOLDER.findall(text):
        if ph.startswith("<<"):
            try:
                dotted_get(data, ph[2:-2])
            except Exception:
                problems.append(f"{label}: placeholder {ph} not found in data file")
    clean = PLACEHOLDER.sub(" ", text)
    if re.search(r"\d", clean):
        problems.append(f"{label}: contains a digit")
    tokens = re.findall(r"[A-Za-z][A-Za-z']*", clean)
    for t in tokens:
        low = t.lower()
        if low in NUMBER_WORDS:
            problems.append(f"{label}: number word '{t}'")
        # lowercase "may" is a modal verb; month names are only flagged when capitalised
        if low in MONTHS and t[0].isupper():
            problems.append(f"{label}: date word '{t}'")
        if low in LEAK_WORDS:
            problems.append(f"{label}: leak word '{t}'")
        if len(t) >= 2 and t.isupper():
            problems.append(f"{label}: possible acronym '{t}'")
    # capitalised word that is not at the start of a sentence: possible organisation name
    sentences = re.split(r"(?<=[.!?:])\s+", clean.strip())
    for s in sentences:
        words = re.findall(r"[A-Za-z][A-Za-z']*", s)
        for w in words[1:]:
            if w[0].isupper():
                problems.append(f"{label}: capitalised word '{w}' inside a sentence")


def collect_bank_texts():
    return [(f"bank:{pid}", text) for pid, text in load_bank()]


def collect_text_bank_texts():
    path = TEMPLATE_DIR / "text_banks.yaml"
    if not path.exists():
        return []
    banks = yaml.safe_load(path.read_text(encoding="utf-8"))
    out = []

    def walk(prefix, node):
        if isinstance(node, str):
            out.append((f"text_banks:{prefix}", node))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(f"{prefix}[{i}]", v)
        elif isinstance(node, dict):
            for k, v in node.items():
                walk(f"{prefix}.{k}" if prefix else k, v)

    walk("", banks)
    return out


def main():
    data = load_data()
    problems = []
    items = collect_bank_texts() + collect_text_bank_texts()
    for label, text in items:
        scan_text(label, text, data, problems)
    if problems:
        print("PROSE CHECK FAILED")
        for p in problems:
            print(" -", p)
        sys.exit(1)
    print(f"PROSE CHECK PASSED: {len(items)} text items scanned, no violations")


if __name__ == "__main__":
    main()
