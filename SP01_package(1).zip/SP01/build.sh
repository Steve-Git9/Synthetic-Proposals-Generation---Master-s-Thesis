#!/usr/bin/env bash
# One command rebuilds everything: data, charts, PDF, answer key, manifest, documentation,
# verification and checksums. Requires python3, xelatex, pdftotext (poppler) and pdfinfo.
set -euo pipefail
cd "$(dirname "$0")"
export SOURCE_DATE_EPOCH=1792886400
export FORCE_SOURCE_DATE=1
mkdir -p build human_steps
python3 SP01_generate_data.py
python3 SP01_prose_check.py
python3 SP01_charts.py
python3 SP01_render.py fit
python3 SP01_make_deliverables.py
python3 SP01_make_docs.py
python3 SP01_verify.py
python3 SP01_checksums.py
