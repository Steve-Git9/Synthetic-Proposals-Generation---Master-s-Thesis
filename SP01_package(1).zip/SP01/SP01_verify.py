#!/usr/bin/env python3
"""Automatic verification of SP01 before release (section 11 of the task specification).

Writes SP01_verification_report.md and exits non zero if any automatic check fails.
"""
import json
import re
import subprocess
import sys

from sp01_common import ROOT, load_data
from sp01_pdftext import page_texts, page_lines, find_pages, norm

results = []  # (status, check, detail)


def check(ok, name, detail=""):
    results.append(("PASS" if ok else "FAIL", name, detail))


def manual(name, detail):
    results.append(("MANUAL", name, detail))


def main():
    d = load_data()
    key = json.loads((ROOT / "SP01_answer_key.json").read_text(encoding="utf-8"))
    texts = page_texts()
    lines = page_lines()
    n = len(texts)
    L = d["placements"]["labels"]
    f = key["fields"]

    # 1. text layer check: every target value on the stated page
    def present(entry, what):
        if entry["value"] is None:
            check(entry["page"] is None and entry["surface_string"] is None, f"{what}: null field has no location")
            return
        if entry.get("manual_check"):
            manual(f"{what}", f"value '{entry['value']}' is in an image, check page {entry['page']} by eye")
            return
        pages = [entry["page"]] + entry.get("additional_pages", [])
        for pg in pages:
            ok = 1 <= pg <= n
            check(ok, f"{what}: page {pg} exists")
        ok = norm(entry["surface_string"]) in texts[entry["page"] - 1]
        check(ok, f"{what}: surface string '{entry['surface_string']}' on page {entry['page']}")

    for k in ["proposal_acronym", "proposal_title", "call_identifier", "funding_programme",
              "submission_date", "stated_total_requested_amount", "trl_start", "trl_target",
              "mcrl_start", "mcrl_target"]:
        present(f[k], k)
    # additional text layer checks for cross reference pages
    check(norm("technology readiness level (TRL) %d" % d["readiness"]["trl_start"])
          in texts[f["trl_start"]["page"] - 1], "TRL start sentence on section 1.3 page")
    for p in f["partners"]:
        present(p["name"], f"partner {p['partner_no']} name")
        present(p["requested_amount"], f"partner {p['partner_no']} requested amount")
        for dd in p["requested_amount"]["distractors"] + p["name"]["distractors"]:
            if dd["surface_string"] in [d["partners"][p["partner_no"] - 1]["acronym"]]:
                manual(f"partner {p['partner_no']} acronym distractor", "inside the Gantt image only")
                continue
            check(norm(dd["surface_string"]) in texts[dd["page"] - 1],
                  f"partner {p['partner_no']} distractor '{dd['surface_string']}' on page {dd['page']}")
    for fld in ("stated_total_requested_amount", "trl_start", "trl_target", "call_identifier",
                "submission_date"):
        for dd in f[fld]["distractors"]:
            check(norm(dd["surface_string"]) in texts[dd["page"] - 1],
                  f"{fld} distractor '{dd['surface_string']}' on page {dd['page']}")

    # budget row amounts: the requested cell is the last token on the partner row
    bf, bl = d["placements"]["part_pages"]["budget"]
    for p in d["partners"]:
        prefix = " ".join(p["legal_name"].split()[:3])
        row = None
        for pg in range(bf, bl + 1):
            for ln in lines[pg - 1]:
                if re.match(rf"^{p['no']} {re.escape(prefix)}", ln):
                    row = ln
        ok = row is not None and row.endswith(p["budget_cell_requested"])
        check(ok, f"budget row {p['no']} ends with requested cell '{p['budget_cell_requested']}'")

    # 2. page count and budget table position
    check(60 <= n <= 70, f"page count {n} between 60 and 70")
    check(41 <= bf and bl <= 43 and (bf, bl) == (41, 43), f"budget pages {bf} to {bl} inside 41 to 43")
    page_map = d["layout"]["page_map"]
    for part, key_name in [("exec", "exec_summary"), ("sec1", "section1"), ("sec2", "section2"),
                           ("sec3", "section3"), ("budget", "budget"), ("sec4", "section4"),
                           ("annexes", "annexes")]:
        got = d["placements"]["part_pages"][part]
        want = page_map[key_name]
        ok = want[0] == got[0] and got[1] <= want[1] + (4 if part == "annexes" else 0)
        check(got[0] == want[0] and got[1] <= max(want[1], 70), f"part {part} pages {got} within map {want}")
    check(L["part:toc"] == 2 and L["exec"] == 3, "cover is page 1, table of contents page 2, summary page 3")

    # table across pages: header row only on the first page of the table
    hdr = [pg for pg in range(bf, bl + 1) if "Subcontracting" in texts[pg - 1]]
    check(hdr == [bf], f"budget header row only on page {bf} (found on {hdr})")
    check(all("Table 4" not in texts[pg - 1] or pg == bf for pg in range(bf, bl + 1)),
          "budget caption only on the first page of the table")
    check("All amounts in EUR thousand" in texts[bf - 1], "caption states the scale on the first page")

    # one partner row wraps, all others do not
    wrapped = []
    for p in d["partners"]:
        full = norm(p["legal_name"])
        found_one_line = any(full in ln for pg in range(bf, bl + 1) for ln in lines[pg - 1])
        if not found_one_line:
            wrapped.append(p["no"])
    check(wrapped == [d["totals"]["wrap_partner_no"]], f"exactly one partner name wraps in the budget table: {wrapped}")
    cons = d["placements"]["labels"]["sub:consortium"]
    for p in d["partners"]:
        ok = any(norm(p["legal_name"]) in ln for pg in range(cons, L["sub:budget"]) for ln in lines[pg - 1])
        check(ok, f"consortium table lists '{p['legal_name']}' on one line")

    # footer on every page, metadata
    foot = norm(d["footer_non_target_string"])
    missing = [pg for pg in range(1, n + 1) if foot not in texts[pg - 1]]
    check(not missing, "footer on every page", f"missing on {missing}")
    info = subprocess.run(["pdfinfo", str(ROOT / "SP01.pdf")], capture_output=True, text=True).stdout
    for fld in ("Title", "Author", "Subject"):
        line = [l for l in info.splitlines() if l.startswith(fld + ":")]
        ok = bool(line) and "SP01" in line[0] and "synthetic" in line[0].lower()
        check(ok, f"PDF metadata {fld} states ID and synthetic")

    # fields that must not be in the text layer or must be absent
    alltext = " ".join(texts)
    for word in ("Horizon", "Europe"):
        check(word not in alltext, f"'{word}' absent from the text layer (programme only in the image)")
    for pat in ("MCRL", "manufacturing readiness", "customer readiness"):
        check(pat.lower() not in alltext.lower(), f"no '{pat}' anywhere in the text layer")
    check(str(d["identity"]["call_identifier"]).startswith("INNO-"), "call identifier does not name the programme")
    for p in d["partners"]:
        check(p["acronym"] not in alltext, f"acronym {p['acronym']} absent from the text layer")
        wp_pages = range(L["sub:wps"], L["sub:consortium"])
        check(not any(p["legal_name"] in " ".join(texts[pg - 1].split()) for pg in wp_pages),
              f"legal name of P{p['no']} not used in work package texts")
    # note 3 amount only in the note, not in the table
    n3 = d["surface"]["note3_amount"]
    pages_n3 = find_pages(texts, n3)
    check(len(pages_n3) == 1 and pages_n3[0] >= L["sub:notes"], f"note 3 amount appears once, on page {pages_n3}")
    n3k = d["surface"]["note3_partner_requested_k"]
    p4 = d["partners"][d["totals"]["note3_partner_no"] - 1]
    row_ok = True
    for pg in range(bf, bl + 1):
        for ln in lines[pg - 1]:
            if ln.startswith(f"{p4['no']} ") and p4["legal_name"].split()[0] in ln:
                row_ok = ln.endswith("see note 3") and not ln.endswith(n3k)
    check(row_ok, "note 3 partner cell reads 'see note 3' in the table")
    # executive summary states the four amounts close together
    ex0, ex1 = d["placements"]["part_pages"]["exec"]
    ex_text = " ".join(texts[ex0 - 1:ex1])
    s = d["surface"]
    idx = [ex_text.find(x) for x in (s["exec_project_cost"], s["exec_eligible"], s["exec_requested"], s["exec_avg_rate"])]
    check(all(i >= 0 for i in idx) and max(idx) - min(idx) < 400, "executive summary states the four amounts close together")
    # MCRL: market readiness distractor present, percentage in section 2
    check(len(find_pages(texts, f"market readiness of {d['readiness']['market_readiness_percent']} percent",
                         *d["placements"]["part_pages"]["sec2"])) == 1, "market readiness distractor in section 2")

    # data consistency (arithmetic by construction)
    parts = d["partners"]
    tot = d["totals"]
    check(sum(p["requested_cents"] for p in parts) == tot["requested_cents"], "sum of partner amounts equals stated total")
    check(3_000_000_00 <= tot["requested_cents"] <= 6_000_000_00, "total requested between 3,000,000 and 6,000,000 euro")
    check(0.10 <= parts[0]["requested_cents"] / tot["requested_cents"] <= 0.15, "coordinator share between 10 and 15 percent")
    for p in parts:
        c = p["costs_cents"]
        check(c["personnel"] + c["subcontracting"] + c["other_direct"] + c["indirect"] == c["total_eligible"],
              f"P{p['no']} cost columns add up")
        if p["no"] != 9:
            r = p["requested_cents"] / c["total_eligible"]
            check(0.70 <= r <= 1.0, f"P{p['no']} funding rate {r:.3f} between 70 and 100 percent")
        check(p["requested_cents"] % 10000 == 0, f"P{p['no']} amount is a whole multiple of 100 euro (table scale)")
    check(tot["project_cost_cents"] >= tot["requested_cents"], "total project cost not below requested funding")
    check(parts[8]["requested_cents"] == 0 and f["partners"][8]["zero_funded"], "associated partner recorded as zero")
    check(f["mcrl_start"]["value"] is None and f["mcrl_target"]["value"] is None, "MCRL start and target are null")
    check(f["trl_target"]["value"] == f["trl_start"]["value"] + 2, "TRL target is start plus two")
    check(len(parts) == 9 and [p["group"] for p in parts].count("Companies") == 3, "nine partners, three companies")

    # gold set equals the answer key and has the ByggMap structure
    gold = json.loads((ROOT / "SP01_gold_set.json").read_text(encoding="utf-8"))
    check(list(gold) == ["proposal", "proposal_facts", "partners", "metadata"], "gold set top level structure")
    check(list(gold["proposal"]) == ["proposal_acronym", "proposal_title", "call_identifier", "submission_date"],
          "gold set proposal keys")
    check(list(gold["proposal_facts"]) == ["requested_total_cents", "trl_start", "trl_target", "mcrl_start",
                                           "mcrl_target"], "gold set proposal_facts keys")
    check(gold["proposal_facts"]["requested_total_cents"] == sum(p["requested_cents"] for p in gold["partners"]),
          "gold set total equals the sum of partner amounts")
    check([p["partner_name"] for p in gold["partners"]] == [p["legal_name"] for p in d["partners"]],
          "gold set partner names equal the consortium table names")
    check(gold["proposal"]["submission_date"] == d["identity"]["submission_date_iso"], "gold set date is ISO 8601")

    # prose check
    r = subprocess.run([sys.executable, str(ROOT / "SP01_prose_check.py")], capture_output=True, text=True, cwd=ROOT)
    check(r.returncode == 0, "prose check", r.stdout.strip().splitlines()[0] if r.stdout.strip() else r.stderr[:200])

    # manual flags
    manual("funding programme banner", "check by eye that page 1 banner reads 'Horizon Europe'")
    manual("Gantt acronyms", "check by eye that the Gantt chart on page %d shows the lead acronyms" % L["annex:a"])

    fails = [r for r in results if r[0] == "FAIL"]
    out = ["# SP01 verification report", "", "Automatic checks run by SP01_verify.py.", "",
           f"Result: {len([r for r in results if r[0] == 'PASS'])} passed, {len(fails)} failed, "
           f"{len([r for r in results if r[0] == 'MANUAL'])} flagged for manual check.", "",
           "| Status | Check | Detail |", "|---|---|---|"]
    for st, name, detail in results:
        out.append(f"| {st} | {name} | {detail} |")
    out += ["", "## Human steps still open", "",
            "- Blind second extraction (human_steps/SP01_blind_extraction_form.md)",
            "- Realism review (human_steps/SP01_realism_checklist.md)",
            "- Name check against YTJ and web search (human_steps/SP01_name_check_list.csv)",
            "- Freeze (only after the three steps above pass)"]
    (ROOT / "SP01_verification_report.md").write_text("\n".join(out) + "\n", encoding="utf-8")
    print(out[4])
    for st, name, detail in results:
        if st == "FAIL":
            print("FAIL:", name, detail)
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
