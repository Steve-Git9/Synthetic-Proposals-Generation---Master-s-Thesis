"""Helpers to read the PDF text layer page by page, normalised for comparison.

The text layer is read with pdftotext (poppler) in layout mode, which keeps table rows on one line
and restores the word spaces that TeX does not store as characters.
"""
import re
import subprocess
import unicodedata

from sp01_common import ROOT

PDF_PATH = ROOT / "SP01.pdf"


def norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip()


def raw_pages(path=PDF_PATH):
    out = subprocess.run(["pdftotext", "-layout", str(path), "-"], capture_output=True, text=True,
                         check=True).stdout
    pages = out.split("\f")
    if pages and not pages[-1].strip():
        pages = pages[:-1]
    return pages


def page_texts(path=PDF_PATH):
    """Return a list of normalised page texts (index 0 is page 1)."""
    return [norm(p) for p in raw_pages(path)]


def page_lines(path=PDF_PATH):
    """Return a list of lists of normalised non empty lines per page."""
    return [[norm(l) for l in p.splitlines() if l.strip()] for p in raw_pages(path)]


def find_pages(texts, needle, first=1, last=None):
    """All pages (1 based) in [first, last] whose text contains the normalised needle."""
    needle = norm(needle)
    last = last or len(texts)
    return [i for i in range(first, last + 1) if needle in texts[i - 1]]
