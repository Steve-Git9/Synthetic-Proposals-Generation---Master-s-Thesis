# SP01 generation log

Document ID: SP01. Version: 1.0 (candidate).

## Model calls

All model calls were made in one working session on 2026-10-25. The model was Claude Sonnet 5.5 (model ID claude-sonnet-5-5), used through the Claude app. The full prompt of every call is the task specification reproduced in the appendix, together with the author's answers to clarifying questions listed below.

| Call | Output | Description |
|---|---|---|
| 1 | paragraph_bank.md | Fifty six neutral filler paragraphs, written once in a single pass. Four paragraphs were edited afterwards to remove a number word, an ordinal word or an idiom that failed the prose check. |
| 2 | SP01_template/text_banks.yaml | Short narrative banks: work package objectives, task titles, deliverable titles, risks, table texts and generic sub headings. |
| 3 | SP01_template/*.tex, SP01_*.py, build.sh | Template, charts, rendering, answer key and verification code. This is code and does not enter the document as prose except for crafted sentences with placeholders in the template. |

## Author answers given to clarifying questions before the build

1. The call identifier must not carry a prefix that names the funding programme. The identifier is therefore INNO-2027-03-CIRCFIBRE-04 style instead of the HORIZON syntax of the task specification.
2. The answer key points the stated total requested amount to the budget table total row. The executive summary figure is a non authoritative distractor.
3. The no dash writing rule is not applied to the generated files.

## Appendix: full task specification used as the prompt

# Task: create synthetic project proposal SP01 (formal EU collaborative proposal)

You are helping a researcher build a synthetic test document for a master thesis. The thesis evaluates how well language models extract structured data from research project proposals. The document will never be submitted to any real call. Its only purpose is to test the extraction pipeline under known, controlled difficulties, with a ground truth that is correct by construction.

Work through the steps in order. Where a step needs a human (marked HUMAN STEP), prepare the material and a checklist, and never claim the step is done.

## 1. Status and identification

* Document ID: SP01. Version: 1.0.
* Every page carries a small footer: "Synthetic document for research purposes, ID SP01, version 1.0". Record this footer in the answer key as a known non target string.
* The PDF metadata fields (title, author, subject) state the ID and the word "synthetic".
* Language: English, with European spelling (organisation, modelling, programme).
* Length: 60 to 70 pages including annexes. Born digital PDF.

## 2. Fictional content rules

* All organisations, persons, projects and call identifiers are fictional.
* The funding programme is Horizon Europe (a real public programme). The call identifier is invented, follows the realistic syntax HORIZON-CL[number]-[year]-[topic]-[number], and must not exist.
* The coordinator is a fictional Finnish innovation cluster organisation. It plays the role a cluster coordinator plays in real proposals. Do not use or imitate CLIC Innovation or any real organisation.
* No personal data. No CVs, no named individuals except obviously fictional contact roles (for example "Project Coordinator").
* Produce a list of all organisation names and the call identifier for the HUMAN STEP check against the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced.
* Produce a synthetic partner register file (`SP01_partner_register.csv`) with the columns legal name, all aliases used in the document, acronym and category (company, university, research organisation, public body, other). It is kept separate from any real partner register.

## 3. Target fields (ground truth schema)

The answer key covers exactly these fields:

1. Proposal acronym
2. Proposal title
3. Call identifier
4. Funding programme
5. Submission date
6. Stated total requested amount
7. TRL start
8. TRL target
9. MCRL start
10. MCRL target
11. For each partner: the name as written in the consortium table (section 3.3) and its requested amount

Formats in the answer key:
* Amounts are integers in euro cents.
* Dates use ISO 8601.
* Booleans are 0 or 1.
* A field not stated in the document is null.

The derived requested total is the sum of the partner amounts. In SP01, the stated total equals that sum.

## 4. Consortium and values

* Nine partners:
  * one coordinator, the fictional cluster organisation;
  * three companies;
  * two universities;
  * two research organisations;
  * one associated partner with no requested funding, recorded as zero in the answer key.
* Total requested amount: between 3,000,000 and 6,000,000 euro.
* Coordinator share of the requested amount: between 10% and 15%.
* Funding rate per funded partner: between 70% and 100%, so total project cost is always higher than or equal to requested funding.
* All values are drawn with a fixed random seed recorded in the data file.

## 5. Build method: data first, document second

1. **Write the data file first** (`SP01_data.yaml`). It holds every target value, every distractor value, every difficulty placement with its page, and the random seed.
2. **Render the document only from the data file** (`SP01_template`), using LaTeX or HTML rendered to PDF. Every number, date, name and acronym in the document must come from the data file.
3. **Generate every chart and diagram with code** (Python with matplotlib), from the same data file and seed. Save the script with the output.
4. **Keep language model text free of facts.** A language model may write narrative prose only. Numbers, dates, organisation names and acronyms enter the text only through template placeholders.
5. **Check the prose.** A script scans all model written prose and fails the build if it finds any number, date, organisation name or acronym that does not come from the data file.
6. **Log every model call:** model name and version, date, temperature and the full prompt, in `SP01_generation_log.md`.

## 6. Effort limits

* The document only has to look plausible to a reader skimming it. Scientific validity, real literature, coherent research logic and compliance with real call rules are not required.
* Only three elements are crafted with care:
  * the target fields;
  * the distractors;
  * the injected difficulties in section 8.

  Everything else is filler.
* Filler comes from a fixed bank of 40 to 60 neutral, domain plausible paragraphs about innovation, consortium work, dissemination and risk. Write the bank once and store it as `paragraph_bank.md`. Paragraphs are selected and ordered with the recorded seed and may repeat.
* Filler contains no numbers, dates, organisation names or acronyms.
* Each filler paragraph is written once, in a single pass, with no iterative polishing. A paragraph is regenerated only if verification in section 11 fails.
* Annexes use repeatable structures generated from the data file: work package tables, deliverable lists, risk tables and a Gantt chart. No CVs.
* Length is reached by adding filler sections and annexes, never by expanding the crafted parts.

## 7. Document structure and page map

Keep within these page ranges. Adjust filler to fit.

| Pages | Content |
|---|---|
| 1 | Cover page. A code generated banner image carries the funding programme name. It is the only place in the document where the funding programme is stated. |
| 2 | Table of contents |
| 3 to 4 | Executive summary |
| 5 to 18 | Section 1, Excellence. TRL start is stated in plain text in section 1.3. |
| 19 to 30 | Section 2, Impact |
| 31 to 40 | Section 3, Implementation. Includes the consortium table in section 3.3, with legal names, and work package descriptions using short names. |
| 41 to 43 | Budget table (section 3.5) |
| 44 to 52 | Section 4, Ethics, security and management. Includes note 3 referenced by the budget table, in section 4.2. |
| 53 to 70 | Annexes: Gantt chart, work package tables, deliverables, risk register |

Cover page fields: proposal acronym, proposal title, call identifier and submission date, as text.

## 8. Difficulties to inject

Record each difficulty in the manifest with its issue number. Issue numbers and source papers come from the thesis literature list: V = VRDU (Wang et al., 2023), D = DocILE (Šimsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanisławek et al., 2021).

1. **#1 Complex layout [V, D, K, M].** Mix running text, tables, captioned figures, footnotes and key and value boxes on the cover page.
2. **#3 Long document [K, M].** The budget table sits deep in the document, on pages 41 to 43.
3. **#10 Two level headers [T].** The budget table has partner rows grouped by partner type, and columns grouped under a top header "Costs" with sub headers personnel, subcontracting, other direct costs, indirect costs and total eligible costs. A separate final column is "Requested contribution".
4. **#11 Grouping values per partner [V, D].** Each partner occupies one row group. One partner's row wraps onto two lines.
5. **Table across pages.** The budget table continues across pages 41 to 43, and the header row appears only on page 41.
6. **#13 Amounts in table structures [K].** All partner amounts appear only in the budget table, except the one in item 9 below.
7. **#14 Scale stated elsewhere [T, K].** The table caption says "All amounts in EUR thousand". Cells show bare numbers with one decimal. The answer key holds full euro cents.
8. **#15 and #16 Several amounts with different meanings [V, T, K].** The executive summary states, close together:
   * total project cost;
   * total eligible costs;
   * total requested contribution, the target;
   * an average funding rate as a percentage.
9. **#18 and #27 Table plus text [T, M].** For one partner, the requested contribution cell reads "see note 3". Note 3 in section 4.2 states the amount in full euro in text. Answering requires linking the table to the note.
10. **#20 Partner names in several forms [K].**
    * Legal names in the consortium table, for example "Northbay Materials Oy".
    * Short names in work package texts, for example "Northbay".
    * Acronyms only inside the Gantt chart image, for example "NBM".
    * The answer key uses the consortium table form.
11. **#24 Zero funded partner [K, V, D].** The associated partner appears in the consortium table and the budget table, with "0.0" as requested contribution.
12. **#24 and #29 Absent fields [M].** MCRL start and MCRL target are not stated anywhere. Both are null in the answer key. Do not include any sentence that suggests an MCRL value.
13. **#26 and #8 Value only in an image [M, K].** The funding programme name appears only in the cover banner image.
14. **#27 and #28 Cross reference [M].** Section 3.2 states the TRL target as "the level defined in section 1.3 plus two". The answer key records the computed value, with both page references.
15. **Distractor near TRL.** Section 2 mentions a "market readiness" percentage, which is not MCRL.

## 9. Authority rules

Write these into the answer key header:

* The budget table (section 3.5) and note 3 are authoritative for partner amounts.
* The executive summary is never authoritative for amounts.
* The TRL target is the computed value from section 3.2 combined with section 1.3.
* The footer text is a non target string.

## 10. Deliverables

1. `SP01.pdf`
2. `SP01_data.yaml`, with the seed
3. `SP01_template` (source files) and `build` script: one command rebuilds everything
4. `SP01_charts.py`
5. `SP01_answer_key.json`. For each target value: field, value, page, location type (text, table, figure), exact surface string, authority rule applied, and a list of distractors with page and surface string.
6. `SP01_manifest.csv`. One row per difficulty, with the columns issue number, source papers, page, affected field, description and expected failure mode.
7. `SP01_partner_register.csv`
8. `paragraph_bank.md`
9. `SP01_generation_log.md`
10. `requirements.lock` with pinned versions, plus a note of operating system and fonts used
11. `SP01_checksums.txt` with SHA-256 checksums of all outputs
12. `CHANGELOG.md`, starting at version 1.0
13. `SP01_datasheet.md`, following Gebru et al. (2021), *Datasheets for Datasets*. It states purpose, creation process, author, intended use, which parts are filler, the link between each difficulty and the literature, licence, and the limitation that results on author written synthetic documents are not evidence about real proposals.

## 11. Verification before release

1. **Text layer check (automatic).** A script confirms that every target value in the answer key is present on the stated page in the PDF text layer. The banner image value and the Gantt acronyms are flagged for manual check.
2. **Page count check (automatic).** The PDF has between 60 and 70 pages, and the budget table falls on pages 41 to 43.
3. **Blind second extraction (HUMAN STEP).** Prepare an empty extraction form with the target fields. A second person extracts all values from the PDF without seeing the answer key. Every disagreement leads to a fix of the design or the key until agreement is complete. Record the initial agreement rate.
4. **Realism review (HUMAN STEP).** Prepare a short plausibility checklist for a person familiar with real proposals.
5. **Name check (HUMAN STEP).** Prepare the list of organisation names and the call identifier for the YTJ and web search.
6. **Freeze.** After all checks pass, tag version 1.0, write checksums, and do not edit the files again. Any later change creates a new version recorded in the changelog. The document must be frozen before any extraction prompt is developed, and must never be opened during prompt tuning.

At the end, report:
* what was produced;
* the results of the automatic checks;
* the human steps still open.
