"""Shared helpers for the SP01 build."""
import re
import yaml
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "SP01_data.yaml"
BANK_FILE = ROOT / "paragraph_bank.md"
TEMPLATE_DIR = ROOT / "SP01_template"
BUILD_DIR = ROOT / "build"
OUT_DIR = ROOT / "out"


def load_data(path=DATA_FILE):
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_data(data, path=DATA_FILE):
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True, width=100)


def load_bank(path=BANK_FILE):
    """Return a list of (id, text) from the paragraph bank."""
    text = Path(path).read_text(encoding="utf-8")
    items = []
    for block in re.split(r"^### ", text, flags=re.M)[1:]:
        head, _, body = block.partition("\n")
        items.append((head.strip(), " ".join(body.strip().split())))
    return items


def dotted_get(data, key):
    cur = data
    for part in key.split("."):
        if isinstance(cur, list):
            cur = cur[int(part)]
        else:
            cur = cur[part]
    return cur


_LATEX_SPECIALS = {
    "&": r"\&", "%": r"\%", "#": r"\#", "_": r"\_",
    "$": r"\$", "{": r"\{", "}": r"\}",
}


def latex_escape(value):
    s = str(value)
    return "".join(_LATEX_SPECIALS.get(ch, ch) for ch in s)


def eur_full(cents):
    """Whole euro with thousands separators, for example EUR 5,214,300."""
    assert cents % 100 == 0
    return f"EUR {cents // 100:,}"


def eur_thousand_1dp(cents):
    """Euro thousand with one decimal, for example 5,214.3. Cents must be a multiple of 10000."""
    assert cents % 10000 == 0, cents
    return f"{cents / 100000:,.1f}"
