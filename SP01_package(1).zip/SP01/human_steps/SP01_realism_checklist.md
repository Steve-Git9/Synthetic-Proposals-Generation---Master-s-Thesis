# SP01 realism review checklist

Status: NOT DONE. Reviewer: a person familiar with real proposals. Reviewer: ____ Date: ____

Judge whether a reader skimming the document would find it plausible. Tick yes or no and add a note.

| Question | Yes | No | Note |
|---|---|---|---|
| The cover page looks like the cover of a real proposal | | | |
| The table of contents and section order look familiar | | | |
| The executive summary reads like a real one | | | |
| The budget table looks like a real budget table | | | |
| The consortium table looks like a real consortium table | | | |
| The work package texts look plausible | | | |
| The Gantt chart looks plausible | | | |
| The deliverables list and risk register look plausible | | | |
| Repeated filler paragraphs are not distracting when skimming | | | |
| Nothing suggests that the document is a copy of a real proposal | | | |
| Anything that looks implausible and should be changed | | | |
