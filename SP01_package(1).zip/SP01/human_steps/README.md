# Human steps for SP01

Status: OPEN. None of these steps has been done.

1. Name check: fill `SP01_name_check_list.csv` using the Finnish Trade Register (YTJ) and a web search. Any match with a real entity must be replaced in `SP01_generate_data.py` and the document rebuilt.
2. Blind second extraction: a second person fills `SP01_blind_extraction_form.md` from `SP01.pdf` without seeing the answer key. Record the initial agreement rate in the form.
3. Realism review: a person familiar with real proposals completes `SP01_realism_checklist.md`.
4. Freeze: only after steps 1 to 3 pass. Tag version 1.0, regenerate checksums and do not edit again.
