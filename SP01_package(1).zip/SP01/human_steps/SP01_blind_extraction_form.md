# SP01 blind extraction form

Status: EMPTY. Fill from SP01.pdf only. Do not open the answer key.

Extractor: ____  Date: ____

Rules: amounts in full euro (not thousand), dates as ISO 8601 (YYYY-MM-DD), write null for a field that is not stated in the document.

| Field | Value | Page where found |
|---|---|---|
| Proposal acronym | | |
| Proposal title | | |
| Call identifier | | |
| Funding programme | | |
| Submission date | | |
| Stated total requested amount | | |
| TRL start | | |
| TRL target | | |
| MCRL start | | |
| MCRL target | | |

## Partners

| No | Name as written in the consortium table | Requested amount | Page |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |

## Result

Number of fields in agreement with the key (filled by the author): ____
Initial agreement rate: ____
Disagreements and fixes: ____
