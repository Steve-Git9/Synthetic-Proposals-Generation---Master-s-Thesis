# SP01 verification report

Automatic checks run by SP01_verify.py.

Result: 197 passed, 0 failed, 12 flagged for manual check.

| Status | Check | Detail |
|---|---|---|
| PASS | proposal_acronym: page 1 exists |  |
| PASS | proposal_acronym: surface string 'LOOPWEAVE' on page 1 |  |
| PASS | proposal_title: page 1 exists |  |
| PASS | proposal_title: surface string 'Circular Weaving of Recycled Fibre Value Chains' on page 1 |  |
| PASS | call_identifier: page 1 exists |  |
| PASS | call_identifier: surface string 'INNO-2027-03-CIRCFIBRE-04' on page 1 |  |
| MANUAL | funding_programme | value 'Horizon Europe' is in an image, check page 1 by eye |
| PASS | submission_date: page 1 exists |  |
| PASS | submission_date: surface string '6 March 2027' on page 1 |  |
| PASS | stated_total_requested_amount: page 43 exists |  |
| PASS | stated_total_requested_amount: page 41 exists |  |
| PASS | stated_total_requested_amount: surface string '4,789.8' on page 43 |  |
| PASS | trl_start: page 6 exists |  |
| PASS | trl_start: surface string 'technology readiness level (TRL) 5' on page 6 |  |
| PASS | trl_target: page 31 exists |  |
| PASS | trl_target: page 6 exists |  |
| PASS | trl_target: surface string 'the level defined in section 1.3 plus two' on page 31 |  |
| PASS | mcrl_start: null field has no location |  |
| PASS | mcrl_target: null field has no location |  |
| PASS | TRL start sentence on section 1.3 page |  |
| PASS | partner 1 name: page 34 exists |  |
| PASS | partner 1 name: surface string 'Kalevra Innovation Cluster Oy' on page 34 |  |
| PASS | partner 1 requested amount: page 41 exists |  |
| PASS | partner 1 requested amount: surface string '575.6' on page 41 |  |
| PASS | partner 1 distractor '596.5' on page 41 |  |
| PASS | partner 1 distractor '420.9' on page 41 |  |
| PASS | partner 1 distractor 'Kalevra' on page 31 |  |
| MANUAL | partner 1 acronym distractor | inside the Gantt image only |
| PASS | partner 2 name: page 34 exists |  |
| PASS | partner 2 name: surface string 'Northbay Materials Oy' on page 34 |  |
| PASS | partner 2 requested amount: page 41 exists |  |
| PASS | partner 2 requested amount: surface string '466.6' on page 41 |  |
| PASS | partner 2 distractor '587.7' on page 41 |  |
| PASS | partner 2 distractor '380.0' on page 41 |  |
| PASS | partner 2 distractor 'Northbay' on page 32 |  |
| MANUAL | partner 2 acronym distractor | inside the Gantt image only |
| PASS | partner 3 name: page 34 exists |  |
| PASS | partner 3 name: surface string 'Corvane Polymer Systems AB' on page 34 |  |
| PASS | partner 3 requested amount: page 41 exists |  |
| PASS | partner 3 requested amount: surface string '578.0' on page 41 |  |
| PASS | partner 3 distractor '798.3' on page 41 |  |
| PASS | partner 3 distractor '509.6' on page 41 |  |
| PASS | partner 3 distractor 'Corvane' on page 32 |  |
| MANUAL | partner 3 acronym distractor | inside the Gantt image only |
| PASS | partner 4 name: page 34 exists |  |
| PASS | partner 4 name: surface string 'Tessilo Process Engineering GmbH' on page 34 |  |
| PASS | partner 4 requested amount: page 44 exists |  |
| PASS | partner 4 requested amount: page 41 exists |  |
| PASS | partner 4 requested amount: surface string 'EUR 552,100' on page 44 |  |
| PASS | partner 4 distractor '731.0' on page 41 |  |
| PASS | partner 4 distractor 'see note 3' on page 41 |  |
| PASS | partner 4 distractor 'Tessilo' on page 33 |  |
| MANUAL | partner 4 acronym distractor | inside the Gantt image only |
| PASS | partner 5 name: page 34 exists |  |
| PASS | partner 5 name: surface string 'Rauvik University' on page 34 |  |
| PASS | partner 5 requested amount: page 42 exists |  |
| PASS | partner 5 requested amount: surface string '643.9' on page 42 |  |
| PASS | partner 5 distractor '663.9' on page 42 |  |
| PASS | partner 5 distractor '478.5' on page 42 |  |
| PASS | partner 5 distractor 'Rauvik' on page 32 |  |
| MANUAL | partner 5 acronym distractor | inside the Gantt image only |
| PASS | partner 6 name: page 34 exists |  |
| PASS | partner 6 name: surface string 'Elvaris University of Technology' on page 34 |  |
| PASS | partner 6 requested amount: page 42 exists |  |
| PASS | partner 6 requested amount: surface string '735.9' on page 42 |  |
| PASS | partner 6 distractor '794.7' on page 42 |  |
| PASS | partner 6 distractor '554.5' on page 42 |  |
| PASS | partner 6 distractor 'Elvaris' on page 32 |  |
| MANUAL | partner 6 acronym distractor | inside the Gantt image only |
| PASS | partner 7 name: page 34 exists |  |
| PASS | partner 7 name: surface string 'Sundmark Applied Research Institute' on page 34 |  |
| PASS | partner 7 requested amount: page 42 exists |  |
| PASS | partner 7 requested amount: surface string '553.2' on page 42 |  |
| PASS | partner 7 distractor '591.2' on page 42 |  |
| PASS | partner 7 distractor '395.1' on page 42 |  |
| PASS | partner 7 distractor 'Sundmark' on page 32 |  |
| MANUAL | partner 7 acronym distractor | inside the Gantt image only |
| PASS | partner 8 name: page 34 exists |  |
| PASS | partner 8 name: surface string 'Brenvik Institute for Sustainable Process Engineering' on page 34 |  |
| PASS | partner 8 requested amount: page 42 exists |  |
| PASS | partner 8 requested amount: surface string '684.5' on page 42 |  |
| PASS | partner 8 distractor '711.4' on page 42 |  |
| PASS | partner 8 distractor '486.5' on page 42 |  |
| PASS | partner 8 distractor 'Brenvik' on page 32 |  |
| MANUAL | partner 8 acronym distractor | inside the Gantt image only |
| PASS | partner 9 name: page 34 exists |  |
| PASS | partner 9 name: surface string 'Lindfors Regional Development Agency' on page 34 |  |
| PASS | partner 9 requested amount: page 43 exists |  |
| PASS | partner 9 requested amount: surface string '0.0' on page 43 |  |
| PASS | partner 9 distractor '179.1' on page 43 |  |
| PASS | partner 9 distractor '123.6' on page 43 |  |
| PASS | partner 9 distractor 'Lindfors' on page 32 |  |
| MANUAL | partner 9 acronym distractor | inside the Gantt image only |
| PASS | stated_total_requested_amount distractor 'EUR 4,789,800' on page 3 |  |
| PASS | stated_total_requested_amount distractor 'EUR 6,142,900' on page 3 |  |
| PASS | stated_total_requested_amount distractor 'EUR 5,653,800' on page 3 |  |
| PASS | stated_total_requested_amount distractor '5,653.8' on page 43 |  |
| PASS | stated_total_requested_amount distractor '84.7 percent' on page 3 |  |
| PASS | trl_start distractor 'market readiness of 34 percent' on page 19 |  |
| PASS | trl_target distractor 'market readiness of 34 percent' on page 19 |  |
| PASS | call_identifier distractor '904673700' on page 1 |  |
| PASS | submission_date distractor '1 April 2027' on page 1 |  |
| PASS | budget row 1 ends with requested cell '575.6' |  |
| PASS | budget row 2 ends with requested cell '466.6' |  |
| PASS | budget row 3 ends with requested cell '578.0' |  |
| PASS | budget row 4 ends with requested cell 'see note 3' |  |
| PASS | budget row 5 ends with requested cell '643.9' |  |
| PASS | budget row 6 ends with requested cell '735.9' |  |
| PASS | budget row 7 ends with requested cell '553.2' |  |
| PASS | budget row 8 ends with requested cell '684.5' |  |
| PASS | budget row 9 ends with requested cell '0.0' |  |
| PASS | page count 66 between 60 and 70 |  |
| PASS | budget pages 41 to 43 inside 41 to 43 |  |
| PASS | part exec pages [3, 4] within map [3, 4] |  |
| PASS | part sec1 pages [5, 18] within map [5, 18] |  |
| PASS | part sec2 pages [19, 30] within map [19, 30] |  |
| PASS | part sec3 pages [31, 40] within map [31, 40] |  |
| PASS | part budget pages [41, 43] within map [41, 43] |  |
| PASS | part sec4 pages [44, 52] within map [44, 52] |  |
| PASS | part annexes pages [53, 66] within map [53, 66] |  |
| PASS | cover is page 1, table of contents page 2, summary page 3 |  |
| PASS | budget header row only on page 41 (found on [41]) |  |
| PASS | budget caption only on the first page of the table |  |
| PASS | caption states the scale on the first page |  |
| PASS | exactly one partner name wraps in the budget table: [8] |  |
| PASS | consortium table lists 'Kalevra Innovation Cluster Oy' on one line |  |
| PASS | consortium table lists 'Northbay Materials Oy' on one line |  |
| PASS | consortium table lists 'Corvane Polymer Systems AB' on one line |  |
| PASS | consortium table lists 'Tessilo Process Engineering GmbH' on one line |  |
| PASS | consortium table lists 'Rauvik University' on one line |  |
| PASS | consortium table lists 'Elvaris University of Technology' on one line |  |
| PASS | consortium table lists 'Sundmark Applied Research Institute' on one line |  |
| PASS | consortium table lists 'Brenvik Institute for Sustainable Process Engineering' on one line |  |
| PASS | consortium table lists 'Lindfors Regional Development Agency' on one line |  |
| PASS | footer on every page | missing on [] |
| PASS | PDF metadata Title states ID and synthetic |  |
| PASS | PDF metadata Author states ID and synthetic |  |
| PASS | PDF metadata Subject states ID and synthetic |  |
| PASS | 'Horizon' absent from the text layer (programme only in the image) |  |
| PASS | 'Europe' absent from the text layer (programme only in the image) |  |
| PASS | no 'MCRL' anywhere in the text layer |  |
| PASS | no 'manufacturing readiness' anywhere in the text layer |  |
| PASS | no 'customer readiness' anywhere in the text layer |  |
| PASS | call identifier does not name the programme |  |
| PASS | acronym KVC absent from the text layer |  |
| PASS | legal name of P1 not used in work package texts |  |
| PASS | acronym NBM absent from the text layer |  |
| PASS | legal name of P2 not used in work package texts |  |
| PASS | acronym CPS absent from the text layer |  |
| PASS | legal name of P3 not used in work package texts |  |
| PASS | acronym TPE absent from the text layer |  |
| PASS | legal name of P4 not used in work package texts |  |
| PASS | acronym RUV absent from the text layer |  |
| PASS | legal name of P5 not used in work package texts |  |
| PASS | acronym ELV absent from the text layer |  |
| PASS | legal name of P6 not used in work package texts |  |
| PASS | acronym SARI absent from the text layer |  |
| PASS | legal name of P7 not used in work package texts |  |
| PASS | acronym BISP absent from the text layer |  |
| PASS | legal name of P8 not used in work package texts |  |
| PASS | acronym LRDA absent from the text layer |  |
| PASS | legal name of P9 not used in work package texts |  |
| PASS | note 3 amount appears once, on page [44] |  |
| PASS | note 3 partner cell reads 'see note 3' in the table |  |
| PASS | executive summary states the four amounts close together |  |
| PASS | market readiness distractor in section 2 |  |
| PASS | sum of partner amounts equals stated total |  |
| PASS | total requested between 3,000,000 and 6,000,000 euro |  |
| PASS | coordinator share between 10 and 15 percent |  |
| PASS | P1 cost columns add up |  |
| PASS | P1 funding rate 0.965 between 70 and 100 percent |  |
| PASS | P1 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P2 cost columns add up |  |
| PASS | P2 funding rate 0.794 between 70 and 100 percent |  |
| PASS | P2 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P3 cost columns add up |  |
| PASS | P3 funding rate 0.724 between 70 and 100 percent |  |
| PASS | P3 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P4 cost columns add up |  |
| PASS | P4 funding rate 0.755 between 70 and 100 percent |  |
| PASS | P4 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P5 cost columns add up |  |
| PASS | P5 funding rate 0.970 between 70 and 100 percent |  |
| PASS | P5 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P6 cost columns add up |  |
| PASS | P6 funding rate 0.926 between 70 and 100 percent |  |
| PASS | P6 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P7 cost columns add up |  |
| PASS | P7 funding rate 0.936 between 70 and 100 percent |  |
| PASS | P7 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P8 cost columns add up |  |
| PASS | P8 funding rate 0.962 between 70 and 100 percent |  |
| PASS | P8 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | P9 cost columns add up |  |
| PASS | P9 amount is a whole multiple of 100 euro (table scale) |  |
| PASS | total project cost not below requested funding |  |
| PASS | associated partner recorded as zero |  |
| PASS | MCRL start and target are null |  |
| PASS | TRL target is start plus two |  |
| PASS | nine partners, three companies |  |
| PASS | gold set top level structure |  |
| PASS | gold set proposal keys |  |
| PASS | gold set proposal_facts keys |  |
| PASS | gold set total equals the sum of partner amounts |  |
| PASS | gold set partner names equal the consortium table names |  |
| PASS | gold set date is ISO 8601 |  |
| PASS | prose check | PROSE CHECK PASSED: 225 text items scanned, no violations |
| MANUAL | funding programme banner | check by eye that page 1 banner reads 'Horizon Europe' |
| MANUAL | Gantt acronyms | check by eye that the Gantt chart on page 53 shows the lead acronyms |

## Human steps still open

- Blind second extraction (human_steps/SP01_blind_extraction_form.md)
- Realism review (human_steps/SP01_realism_checklist.md)
- Name check against YTJ and web search (human_steps/SP01_name_check_list.csv)
- Freeze (only after the three steps above pass)
