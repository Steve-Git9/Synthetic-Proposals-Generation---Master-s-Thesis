# SP01 datasheet

Following Gebru et al. (2021), Datasheets for Datasets. Document: SP01, version 1.0 (candidate, not yet frozen).

## Purpose

SP01 is a synthetic research project proposal written for a master thesis that evaluates how well language models extract structured data from proposal documents. It is a test document with known, controlled difficulties and an answer key that is correct by construction. It was never submitted to any call.

## Author and creation process

The document was specified by the thesis author, Stefano Fanelli (Haaga-Helia, MCI, Universidad de Sevilla), and built with the assistance of a language model (see SP01_generation_log.md).

1. The data file SP01_data.yaml was generated first by SP01_generate_data.py with the fixed seed 20261025. It holds every target value, distractor value and layout parameter.
2. The document is rendered only from the data file and the template in SP01_template with XeLaTeX. Every number, date, name and acronym comes from the data file through template placeholders.
3. All figures are generated with Python and matplotlib from the same data file and seed (SP01_charts.py) and saved as raster images.
4. Narrative prose is limited to a fixed bank of 56 neutral paragraphs (paragraph_bank.md) and short text banks (SP01_template/text_banks.yaml). A script (SP01_prose_check.py) fails the build if this prose contains a digit, a number word, a date word, a capitalised name inside a sentence, an acronym or a word that could leak a target field.
5. The page map was fitted by the build: filler paragraphs are added at the end of each section until the section fills its page range.
6. The answer key was created after rendering by locating each surface string in the PDF text layer, and verified by SP01_verify.py.

## Composition

- 66 pages, English with European spelling, born digital PDF. Cover page 1, table of contents page 2, executive summary pages 3 to 4, section 1 pages 5 to 18, section 2 pages 19 to 30, section 3 pages 31 to 40, budget table pages 41 to 43, section 4 pages 44 to 52, annexes pages 53 to 66.
- Nine fictional partners: one coordinator (a fictional Finnish innovation cluster organisation), three companies, two universities, two research organisations and one associated partner with no requested funding.
- Target fields: proposal acronym, title, call identifier, funding programme, submission date, stated total requested amount, TRL start, TRL target, MCRL start, MCRL target, and for each partner the name as written in the consortium table and the requested amount. Amounts are in euro cents in the answer key.
- Every page carries the footer "Synthetic document for research purposes, ID SP01, version 1.0". It is a known non target string.
- All organisations, persons, projects and identifiers are fictional. The call identifier is invented and does not follow the syntax of a real call. There is no personal data and there are no named individuals.

## Which parts are filler

Only three elements are crafted with care: the target fields, the distractors and the injected difficulties. Everything else is filler: the paragraph bank, generic sub headings, the objective and impact tables, the risk register, the deliverables list and the work package texts. Filler paragraphs repeat because the bank has 56 paragraphs and the document is long. Within a section a paragraph repeats only after the whole bank has been used. Filler paragraphs per slot, as fitted by the build: {'exec_a': 1, 'exec_pad': 13, 's1_a': 4, 's1_b': 3, 's1_c': 3, 's1_pad': 104, 's2_a': 4, 's2_b': 4, 's2_pad': 92, 's3_a': 3, 's3_b': 3, 's3_pad': 52, 'budget_a': 1, 'budget_pad': 7, 's4_a': 4, 's4_b': 2, 's4_pad': 72, 'annex_pad': 72}.

## Difficulties and the literature

Source papers: V = VRDU (Wang et al., 2023), D = DocILE (Simsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanislawek et al., 2021). The full table with pages and expected failure modes is in SP01_manifest.csv.

| Issue | Source papers | Difficulty |
|---|---|---|
| #1 | V, D, K, M | Complex layout on the cover and in the body |
| #3 | K, M | Long document, budget table deep in the document |
| #10 | T | Two level headers in the budget table |
| #11 | V, D | Grouping values per partner, one wrapped partner name |
| not numbered | | Table across pages, header row only on the first page |
| #13 | K | Amounts in table structures |
| #14 | T, K | Scale stated in the caption |
| #15 and #16 | V, T, K | Several amounts with different meanings in the executive summary |
| #18 and #27 | T, M | Table plus text, see note 3 |
| #20 | K | Partner names in several forms |
| #24 | K, V, D | Zero funded partner |
| #24 and #29 | M | Absent fields, MCRL start and MCRL target |
| #26 and #8 | M, K | Funding programme only in an image |
| #27 and #28 | M | Cross reference for the TRL target |
| not numbered | | Distractor near TRL, a market readiness percentage |

## Intended use

Evaluating text extraction pipelines and language models under controlled difficulties. It must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.

## Not intended for

Training or evaluating general document understanding outside this thesis, or any use as an example of a real proposal.

## Limitations

Results on author written synthetic documents are not evidence about real proposals. The layout is one template. The filler is generic and repetitive. The document was built to look plausible to a reader skimming it, not to be scientifically valid.

## Licence

To be confirmed by the author. Suggested licence: CC BY 4.0.

## Maintenance

Any change after the freeze creates a new version recorded in CHANGELOG.md. Contact: the thesis author.
