#!/usr/bin/env python3
"""Write SP01_checksums.txt with SHA-256 checksums of all outputs."""
import hashlib
from sp01_common import ROOT

FILES = [
    "SP01.pdf", "SP01_data.yaml", "build.sh", "SP01_charts.py", "SP01_answer_key.json",
    "SP01_gold_set.json", "SP01_manifest.csv", "SP01_partner_register.csv", "paragraph_bank.md", "SP01_generation_log.md",
    "requirements.lock", "CHANGELOG.md", "SP01_datasheet.md", "SP01_verification_report.md",
    "SP01_task_spec.md", "sp01_common.py", "sp01_pdftext.py", "SP01_generate_data.py",
    "SP01_render.py", "SP01_prose_check.py", "SP01_make_deliverables.py", "SP01_make_docs.py",
    "SP01_verify.py", "SP01_checksums.py",
]


def all_files():
    out = list(FILES)
    out += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "SP01_template").glob("*"))
    out += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "human_steps").glob("*"))
    out += sorted(f"build/{n}" for n in ("banner.png", "gantt.png", "fig_concept.png", "fig_impact.png",
                                        "fig_workplan.png"))
    return out


def main():
    lines = ["# SHA-256 checksums of all SP01 outputs", "# status: candidate 1.0, freeze pending human checks"]
    for rel in all_files():
        h = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
        lines.append(f"{h}  {rel}")
    (ROOT / "SP01_checksums.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"SP01_checksums.txt written ({len(lines) - 2} files)")


if __name__ == "__main__":
    main()
