#!/usr/bin/env python3
"""Write the documentation deliverables: generation log, datasheet, changelog, requirements.lock."""
import platform
import subprocess
from importlib import metadata

from sp01_common import ROOT, load_data

TODAY = "2026-10-25"


def write_requirements(d):
    pkgs = ["PyYAML", "matplotlib", "numpy", "pillow", "pdfplumber", "pypdf"]
    lines = [f"{p}=={metadata.version(p)}" for p in pkgs]
    xetex = subprocess.run(["xelatex", "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    pdftotext = subprocess.run(["pdftotext", "-v"], capture_output=True, text=True).stderr.splitlines()[0]
    lines += [
        "",
        "# Environment note",
        f"# Python {platform.python_version()}",
        f"# Operating system: {platform.system()} {platform.release()} {platform.machine()}",
        f"# TeX engine: {xetex}",
        f"# Text layer reader: {pdftotext}",
        "# Fonts: TeX Gyre Termes (body text), TeX Gyre Heros (headings, footer, cover),",
        "#        DejaVu Sans (matplotlib figures, raster only)",
        "# Build environment variables: SOURCE_DATE_EPOCH=1792886400, FORCE_SOURCE_DATE=1",
    ]
    (ROOT / "requirements.lock").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_changelog(d):
    text = f"""# Changelog

## 1.0 (candidate, not yet frozen), {TODAY}

- First build of SP01 from seed {d['meta']['seed']}.
- 66 page born digital PDF, formal collaborative proposal layout, nine partners.
- Answer key, manifest, partner register, datasheet and generation log created.
- Design decisions taken by the author before the build:
  - the call identifier does not name the funding programme, so that the programme appears only in the banner image;
  - the stated total requested amount is anchored to the budget table total row, the executive summary figure is a non authoritative distractor;
  - the no dash writing rule does not apply to the generated files.
- Open: name check, blind second extraction and realism review (see human_steps). The freeze is pending until these pass.
"""
    (ROOT / "CHANGELOG.md").write_text(text, encoding="utf-8")


def write_datasheet(d):
    pp = d["placements"]["part_pages"]
    fc = d["layout"]["filler_counts"]
    bank_n = 56
    text = f"""# SP01 datasheet

Following Gebru et al. (2021), Datasheets for Datasets. Document: SP01, version 1.0 (candidate, not yet frozen).

## Purpose

SP01 is a synthetic research project proposal written for a master thesis that evaluates how well language models extract structured data from proposal documents. It is a test document with known, controlled difficulties and an answer key that is correct by construction. It was never submitted to any call.

## Author and creation process

The document was specified by the thesis author, Stefano Fanelli (Haaga-Helia, MCI, Universidad de Sevilla), and built with the assistance of a language model (see SP01_generation_log.md).

1. The data file SP01_data.yaml was generated first by SP01_generate_data.py with the fixed seed {d['meta']['seed']}. It holds every target value, distractor value and layout parameter.
2. The document is rendered only from the data file and the template in SP01_template with XeLaTeX. Every number, date, name and acronym comes from the data file through template placeholders.
3. All figures are generated with Python and matplotlib from the same data file and seed (SP01_charts.py) and saved as raster images.
4. Narrative prose is limited to a fixed bank of {bank_n} neutral paragraphs (paragraph_bank.md) and short text banks (SP01_template/text_banks.yaml). A script (SP01_prose_check.py) fails the build if this prose contains a digit, a number word, a date word, a capitalised name inside a sentence, an acronym or a word that could leak a target field.
5. The page map was fitted by the build: filler paragraphs are added at the end of each section until the section fills its page range.
6. The answer key was created after rendering by locating each surface string in the PDF text layer, and verified by SP01_verify.py.

## Composition

- {d['placements']['total_pages']} pages, English with European spelling, born digital PDF. Cover page 1, table of contents page 2, executive summary pages {pp['exec'][0]} to {pp['exec'][1]}, section 1 pages {pp['sec1'][0]} to {pp['sec1'][1]}, section 2 pages {pp['sec2'][0]} to {pp['sec2'][1]}, section 3 pages {pp['sec3'][0]} to {pp['sec3'][1]}, budget table pages {pp['budget'][0]} to {pp['budget'][1]}, section 4 pages {pp['sec4'][0]} to {pp['sec4'][1]}, annexes pages {pp['annexes'][0]} to {pp['annexes'][1]}.
- Nine fictional partners: one coordinator (a fictional Finnish innovation cluster organisation), three companies, two universities, two research organisations and one associated partner with no requested funding.
- Target fields: proposal acronym, title, call identifier, funding programme, submission date, stated total requested amount, TRL start, TRL target, MCRL start, MCRL target, and for each partner the name as written in the consortium table and the requested amount. Amounts are in euro cents in the answer key.
- Every page carries the footer "{d['footer_non_target_string']}". It is a known non target string.
- All organisations, persons, projects and identifiers are fictional. The call identifier is invented and does not follow the syntax of a real call. There is no personal data and there are no named individuals.

## Which parts are filler

Only three elements are crafted with care: the target fields, the distractors and the injected difficulties. Everything else is filler: the paragraph bank, generic sub headings, the objective and impact tables, the risk register, the deliverables list and the work package texts. Filler paragraphs repeat because the bank has {bank_n} paragraphs and the document is long. Within a section a paragraph repeats only after the whole bank has been used. Filler paragraphs per slot, as fitted by the build: {fc}.

## Difficulties and the literature

Source papers: V = VRDU (Wang et al., 2023), D = DocILE (Simsa et al., 2023), T = TAT-QA (Zhu et al., 2021), M = MMLongBench-Doc (Ma et al., 2024), K = Kleister (Stanislawek et al., 2021). The full table with pages and expected failure modes is in SP01_manifest.csv.

| Issue | Source papers | Difficulty |
|---|---|---|
| #1 | V, D, K, M | Complex layout on the cover and in the body |
| #3 | K, M | Long document, budget table deep in the document |
| #10 | T | Two level headers in the budget table |
| #11 | V, D | Grouping values per partner, one wrapped partner name |
| not numbered | | Table across pages, header row only on the first page |
| #13 | K | Amounts in table structures |
| #14 | T, K | Scale stated in the caption |
| #15 and #16 | V, T, K | Several amounts with different meanings in the executive summary |
| #18 and #27 | T, M | Table plus text, see note 3 |
| #20 | K | Partner names in several forms |
| #24 | K, V, D | Zero funded partner |
| #24 and #29 | M | Absent fields, MCRL start and MCRL target |
| #26 and #8 | M, K | Funding programme only in an image |
| #27 and #28 | M | Cross reference for the TRL target |
| not numbered | | Distractor near TRL, a market readiness percentage |

## Intended use

Evaluating text extraction pipelines and language models under controlled difficulties. It must be frozen before any extraction prompt is developed and must never be opened during prompt tuning.

## Not intended for

Training or evaluating general document understanding outside this thesis, or any use as an example of a real proposal.

## Limitations

Results on author written synthetic documents are not evidence about real proposals. The layout is one template. The filler is generic and repetitive. The document was built to look plausible to a reader skimming it, not to be scientifically valid.

## Licence

To be confirmed by the author. Suggested licence: CC BY 4.0.

## Maintenance

Any change after the freeze creates a new version recorded in CHANGELOG.md. Contact: the thesis author.
"""
    (ROOT / "SP01_datasheet.md").write_text(text, encoding="utf-8")


def write_generation_log(d):
    spec = (ROOT / "SP01_task_spec.md").read_text(encoding="utf-8")
    text = f"""# SP01 generation log

Document ID: SP01. Version: 1.0 (candidate).

## Model calls

All model calls were made in one working session on {TODAY}. The model was Claude Sonnet 5.5 (model ID claude-sonnet-5-5), used through the Claude app. The full prompt of every call is the task specification reproduced in the appendix, together with the author's answers to clarifying questions listed below.

| Call | Output | Description |
|---|---|---|
| 1 | paragraph_bank.md | Fifty six neutral filler paragraphs, written once in a single pass. Four paragraphs were edited afterwards to remove a number word, an ordinal word or an idiom that failed the prose check. |
| 2 | SP01_template/text_banks.yaml | Short narrative banks: work package objectives, task titles, deliverable titles, risks, table texts and generic sub headings. |
| 3 | SP01_template/*.tex, SP01_*.py, build.sh | Template, charts, rendering, answer key and verification code. This is code and does not enter the document as prose except for crafted sentences with placeholders in the template. |

## Author answers given to clarifying questions before the build

1. The call identifier must not carry a prefix that names the funding programme. The identifier is therefore INNO-2027-03-CIRCFIBRE-04 style instead of the HORIZON syntax of the task specification.
2. The answer key points the stated total requested amount to the budget table total row. The executive summary figure is a non authoritative distractor.
3. The no dash writing rule is not applied to the generated files.

## Appendix: full task specification used as the prompt

{spec}
"""
    (ROOT / "SP01_generation_log.md").write_text(text, encoding="utf-8")


def main():
    d = load_data()
    write_requirements(d)
    write_changelog(d)
    write_datasheet(d)
    write_generation_log(d)
    print("documentation files written")


if __name__ == "__main__":
    main()
