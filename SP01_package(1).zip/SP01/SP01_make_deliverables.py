#!/usr/bin/env python3
"""Create the answer key, manifest, partner register, name check list and human step forms.

Pages are located in the rendered PDF text layer. Values come from SP01_data.yaml.
"""
import csv
import json
from pathlib import Path

from sp01_common import ROOT, load_data
from sp01_pdftext import page_texts, find_pages, norm

HUMAN_DIR = ROOT / "human_steps"

AUTHORITY_RULES = [
    "The budget table (section 3.5) and note 3 are authoritative for partner amounts.",
    "The executive summary is never authoritative for amounts.",
    "The TRL target is the computed value from section 3.2 combined with section 1.3.",
    "The footer text is a non target string.",
]


def one(pages, what):
    if not pages:
        raise RuntimeError(f"not found in PDF text layer: {what}")
    return pages[0]


def entry(field, value, page, location, surface, rule, distractors=None, extra=None):
    e = dict(field=field, value=value, page=page, location_type=location, surface_string=surface,
             authority_rule=rule, distractors=distractors or [])
    if extra:
        e.update(extra)
    return e


def dist(page, surface, note):
    return dict(page=page, surface_string=surface, note=note)


def build_answer_key(d, texts):
    L = d["placements"]["labels"]
    idn = d["identity"]
    rd = d["readiness"]
    sf = d["surface"]
    tot = d["totals"]
    parts = d["partners"]
    n = len(texts)
    bud_first, bud_last = d["placements"]["part_pages"]["budget"]

    # ---- cover fields
    p_cover = 1
    assert find_pages(texts, idn["acronym"], 1, 1)
    assert find_pages(texts, idn["title"], 1, 1)
    assert find_pages(texts, idn["call_identifier"], 1, 1)
    assert find_pages(texts, idn["submission_date_text"], 1, 1)

    fields = {}
    fields["proposal_acronym"] = entry(
        "Proposal acronym", idn["acronym"], p_cover, "text", idn["acronym"],
        "Cover page key and value box.")
    fields["proposal_title"] = entry(
        "Proposal title", idn["title"], p_cover, "text", idn["title"], "Cover page key and value box.")
    fields["call_identifier"] = entry(
        "Call identifier", idn["call_identifier"], p_cover, "text", idn["call_identifier"],
        "Cover page key and value box.",
        [dist(p_cover, idn["proposal_number"], "Proposal number, not the call identifier")])
    fields["funding_programme"] = entry(
        "Funding programme", idn["funding_programme"], p_cover, "figure", idn["funding_programme"],
        "Stated only in the cover banner image. Not present in the PDF text layer. Manual check.",
        [dist(p_cover, idn["action_type"], "Type of action, not the funding programme")],
        extra=dict(manual_check=True))
    fields["submission_date"] = entry(
        "Submission date", idn["submission_date_iso"], p_cover, "text", idn["submission_date_text"],
        "Cover page key and value box labelled Submission date. ISO 8601 in the value.",
        [dist(p_cover, idn["call_deadline_text"], "Call deadline, not the submission date")])

    # ---- stated total
    p_total = one(find_pages(texts, sf["budget_total_requested_k"], bud_first, bud_last), "budget total")
    p_caption = one(find_pages(texts, "All amounts in EUR thousand", bud_first, bud_last), "caption")
    exec_first, exec_last = d["placements"]["part_pages"]["exec"]
    p_exec_req = one(find_pages(texts, sf["exec_requested"], exec_first, exec_last), "exec requested")
    fields["stated_total_requested_amount"] = entry(
        "Stated total requested amount", tot["requested_cents"], p_total, "table",
        sf["budget_total_requested_k"],
        "Budget table total row, column Requested contribution. Scale from the table caption "
        "(All amounts in EUR thousand). The value is in euro cents.",
        [dist(p_exec_req, sf["exec_requested"], "Executive summary, equal in value, not authoritative"),
         dist(p_exec_req, sf["exec_project_cost"], "Total project cost"),
         dist(p_exec_req, sf["exec_eligible"], "Total eligible costs"),
         dist(p_total, sf["budget_total_eligible_k"], "Total eligible costs column total"),
         dist(p_exec_req, sf["exec_avg_rate"], "Average funding rate")],
        extra=dict(additional_pages=[p_caption], derived_sum_of_partner_amounts=tot["requested_cents"]))

    # ---- readiness
    sec1_first, sec1_last = d["placements"]["part_pages"]["sec1"]
    sec2_first, sec2_last = d["placements"]["part_pages"]["sec2"]
    sec3_first, sec3_last = d["placements"]["part_pages"]["sec3"]
    trl_sentence = f"technology readiness level (TRL) {rd['trl_start']}"
    p_trl_start = one(find_pages(texts, trl_sentence, sec1_first, sec1_last), "TRL start")
    assert L["sub:concept"] <= p_trl_start <= L["sub:amb"]
    target_sentence = (f"the level defined in section 1.3 plus {rd['trl_delta_word']}")
    p_trl_target = one(find_pages(texts, target_sentence, sec3_first, sec3_last), "TRL target")
    mr_text = f"market readiness of {rd['market_readiness_percent']} percent"
    p_mr = one(find_pages(texts, mr_text, sec2_first, sec2_last), "market readiness")
    mr_dist = dist(p_mr, mr_text, "Market readiness percentage, not MCRL and not TRL")
    fields["trl_start"] = entry(
        "TRL start", rd["trl_start"], p_trl_start, "text", trl_sentence,
        "Plain text in section 1.3.", [mr_dist])
    fields["trl_target"] = entry(
        "TRL target", rd["trl_target"], p_trl_target, "text", target_sentence,
        "Computed value: the level in section 1.3 plus the stated increment in section 3.2.",
        [mr_dist],
        extra=dict(additional_pages=[p_trl_start],
                   computation=f"{rd['trl_start']} + {rd['trl_delta']} = {rd['trl_target']}",
                   page_references=dict(section_3_2=p_trl_target, section_1_3=p_trl_start)))
    for key, label in (("mcrl_start", "MCRL start"), ("mcrl_target", "MCRL target")):
        fields[key] = entry(
            label, None, None, None, None,
            "Absent field. Not stated anywhere in the document. The value is null.", [mr_dist])

    # ---- partners
    cons_first = L["sub:consortium"]
    cons_last = L["sub:budget"] - 1
    note_label_first = L["sub:notes"]
    sec4_last = d["placements"]["part_pages"]["sec4"][1]
    partners = []
    for p in parts:
        no = p["no"]
        p_name = one(find_pages(texts, p["legal_name"], cons_first, cons_last), f"name {p['legal_name']}")
        name_entry = entry(
            f"Partner {no} name", p["legal_name"], p_name, "table", p["legal_name"],
            "Name as written in the consortium table (section 3.3).",
            [dist(one(find_pages(texts, p["short_name"], d['placements']['part_pages']['sec3'][0],
                                 d['placements']['part_pages']['sec3'][1]), p["short_name"]),
                  p["short_name"], "Short name used in work package texts. Not the name form of the key"),
             dist(L["annex:a"], p["acronym"], "Acronym, appears only inside the Gantt chart image "
                                              "if the partner leads a work package")])
        # amount
        eligible_k = f"{p['costs_cents']['total_eligible'] / 100000:,.1f}"
        row_key = " ".join(p["legal_name"].split()[:3])
        p_row = one(find_pages(texts, row_key, bud_first, bud_last), f"budget row {no}")
        if p["requested_in_note_3"]:
            p_note = one(find_pages(texts, sf["note3_amount"], note_label_first, sec4_last), "note 3 amount")
            amount_entry = entry(
                f"Partner {no} requested amount", p["requested_cents"], p_note, "text",
                sf["note3_amount"],
                "Note 3 in section 4.2 is authoritative. The budget table cell reads see note 3.",
                [dist(p_row, eligible_k, "Total eligible costs cell of the same row"),
                 dist(p_row, "see note 3", "Table cell, no amount")],
                extra=dict(additional_pages=[p_row],
                           table_cell_surface_string="see note 3", scale_note="Full euro in text"))
        else:
            amount_entry = entry(
                f"Partner {no} requested amount", p["requested_cents"], p_row, "table",
                p["budget_cell_requested"],
                "Budget table, column Requested contribution. Scale from the caption "
                "(All amounts in EUR thousand).",
                [dist(p_row, eligible_k, "Total eligible costs cell of the same row"),
                 dist(p_row, f"{p['costs_cents']['personnel'] / 100000:,.1f}", "Personnel cost cell")])
        partners.append(dict(partner_no=no, group=p["group"], category=p["category"],
                             name=name_entry, requested_amount=amount_entry,
                             zero_funded=(p["requested_cents"] == 0)))
    fields["partners"] = partners

    key = dict(
        header=dict(
            document_id=d["meta"]["document_id"], version=d["meta"]["version"], seed=d["meta"]["seed"],
            authority_rules=AUTHORITY_RULES,
            non_target_strings=[d["footer_non_target_string"]],
            formats=dict(amounts="integers in euro cents", dates="ISO 8601", booleans="0 or 1",
                         absent_fields="null"),
            derived_requested_total_cents=sum(p["requested_cents"] for p in parts),
            total_pages=len(texts),
            notes=["The stated total equals the sum of the partner amounts in SP01.",
                   "Page numbers are PDF page numbers, page 1 is the cover.",
                   "manual_check marks values that cannot be verified in the text layer."],
        ),
        fields=fields,
    )
    return key


MANIFEST_ROWS = [
    # issue, sources, affected field, description, expected failure mode
    ("#1", "V, D, K, M", "all fields",
     "Complex layout: running text, tables, captioned figures, footnotes and key and value boxes on the cover page.",
     "Reading order errors, values taken from the wrong box, loss of table structure in conversion."),
    ("#3", "K, M", "partner amounts, stated total",
     "Long document: the budget table sits deep in the document.",
     "Budget table missed or truncated when the context is long or when pages are sampled."),
    ("#10", "T", "partner amounts",
     "Two level headers: cost columns grouped under the header Costs, with a separate final column Requested contribution.",
     "A cost column (for example total eligible costs) is read as the requested contribution."),
    ("#11", "V, D", "partner names and amounts",
     "Grouping values per partner: partner rows grouped by partner type, one partner name wraps onto two lines.",
     "Wrapped name split into two entries, amounts assigned to the wrong partner."),
    ("Table across pages", "", "partner amounts, stated total",
     "The budget table continues across three pages and the header row appears only on the first page.",
     "Columns misassigned on pages without a header row."),
    ("#13", "K", "partner amounts",
     "Amounts in table structures: all partner amounts appear only in the budget table, except the amount in note 3.",
     "Amounts invented or taken from the executive summary when the table is parsed badly."),
    ("#14", "T, K", "partner amounts, stated total",
     "Scale stated elsewhere: the caption says all amounts in EUR thousand, cells show bare numbers with one decimal.",
     "Amounts returned in thousands instead of full euro cents."),
    ("#15 and #16", "V, T, K", "stated total requested amount",
     "Several amounts with different meanings close together in the executive summary: total project cost, total eligible costs, total requested contribution and an average funding rate.",
     "Total project cost or total eligible costs returned as the requested total."),
    ("#18 and #27", "T, M", "one partner amount",
     "Table plus text: for one partner the cell reads see note 3, and note 3 in section 4.2 states the amount in full euro.",
     "Amount returned as null, or the eligible costs cell used instead."),
    ("#20", "K", "partner names",
     "Partner names in several forms: legal names in the consortium table, short names in work package texts, acronyms only inside the Gantt chart image.",
     "Short name or acronym returned instead of the legal name, duplicate partners."),
    ("#24", "K, V, D", "one partner amount",
     "Zero funded partner: the associated partner is in the consortium table and in the budget table with 0.0 as requested contribution.",
     "Partner omitted, or the associated partner eligible costs returned as a requested amount."),
    ("#24 and #29", "M", "MCRL start, MCRL target",
     "Absent fields: MCRL start and MCRL target are not stated anywhere. Both are null.",
     "Hallucinated MCRL values, or the market readiness percentage returned as MCRL."),
    ("#26 and #8", "M, K", "funding programme",
     "Value only in an image: the funding programme name appears only in the cover banner image.",
     "Field returned as null by a text only pipeline, or guessed from the call identifier."),
    ("#27 and #28", "M", "TRL target",
     "Cross reference: section 3.2 states the target as the level defined in section 1.3 plus two.",
     "Target returned as null, or as the start value, or as the increment."),
    ("Distractor near TRL", "", "TRL start, TRL target, MCRL",
     "Section 2 mentions a market readiness percentage that is not MCRL.",
     "Percentage returned as an MCRL or TRL value."),
]


def build_manifest(d, texts, key):
    L = d["placements"]["labels"]
    f = key["fields"]
    parts = d["partners"]
    bf, bl = d["placements"]["part_pages"]["budget"]
    wrap = parts[d["totals"]["wrap_partner_no"] - 1]
    wrap_page = one(find_pages(texts, " ".join(wrap["legal_name"].split()[:3]), bf, bl), "wrap")
    zero = parts[8]
    zero_page = one(find_pages(texts, " ".join(zero["legal_name"].split()[:3]), bf, bl), "zero")
    exec_first, exec_last = d["placements"]["part_pages"]["exec"]
    p_exec = one(find_pages(texts, d["surface"]["exec_requested"], exec_first, exec_last), "exec")
    note_p = f["partners"][d["totals"]["note3_partner_no"] - 1]["requested_amount"]["page"]
    table_cell_p = f["partners"][d["totals"]["note3_partner_no"] - 1]["requested_amount"]["additional_pages"][0]
    pages = {
        "#1": "1; 5 to 18",
        "#3": f"{bf} to {bl}",
        "#10": f"{bf}",
        "#11": f"{wrap_page}",
        "Table across pages": f"{bf} to {bl}",
        "#13": f"{bf} to {bl}",
        "#14": f"{f['stated_total_requested_amount']['additional_pages'][0]}",
        "#15 and #16": f"{p_exec}",
        "#18 and #27": f"{table_cell_p}; {note_p}",
        "#20": f"{f['partners'][0]['name']['page']}; {L['sub:wps']} to {L['sub:consortium'] - 1}; {L['annex:a']}",
        "#24": f"{zero_page}",
        "#24 and #29": "not stated (absent)",
        "#26 and #8": "1",
        "#27 and #28": f"{f['trl_target']['page']}; {f['trl_start']['page']}",
        "Distractor near TRL": f"{f['trl_start']['distractors'][0]['page']}",
    }
    rows = []
    for issue, src, field, desc, fail in MANIFEST_ROWS:
        rows.append(dict(issue_number=issue, source_papers=src, page=pages[issue], affected_field=field,
                         description=desc, expected_failure_mode=fail))
    return rows


def write_partner_register(d):
    path = ROOT / "SP01_partner_register.csv"
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["legal_name", "aliases_used_in_document", "acronym", "category"])
        for p in d["partners"]:
            w.writerow([p["legal_name"], p["short_name"], p["acronym"], p["category"]])


def write_name_check(d):
    HUMAN_DIR.mkdir(exist_ok=True)
    path = HUMAN_DIR / "SP01_name_check_list.csv"
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["item", "type", "name_to_check", "ytj_checked", "web_search_checked",
                    "match_with_real_entity", "action", "checked_by", "date"])
        for p in d["partners"]:
            w.writerow([f"P{p['no']}", "legal name", p["legal_name"], "", "", "", "", "", ""])
            w.writerow([f"P{p['no']}", "short name", p["short_name"], "", "", "", "", "", ""])
            w.writerow([f"P{p['no']}", "acronym", p["acronym"], "", "", "", "", "", ""])
        w.writerow(["call", "call identifier", d["identity"]["call_identifier"], "", "", "", "", "", ""])
        w.writerow(["project", "proposal acronym", d["identity"]["acronym"], "", "", "", "", "", ""])
        w.writerow(["project", "proposal title", d["identity"]["title"], "", "", "", "", "", ""])
    (HUMAN_DIR / "README.md").write_text(
        "# Human steps for SP01\n\nStatus: OPEN. None of these steps has been done.\n\n"
        "1. Name check: fill `SP01_name_check_list.csv` using the Finnish Trade Register (YTJ) and a web "
        "search. Any match with a real entity must be replaced in `SP01_generate_data.py` and the document rebuilt.\n"
        "2. Blind second extraction: a second person fills `SP01_blind_extraction_form.md` from `SP01.pdf` "
        "without seeing the answer key. Record the initial agreement rate in the form.\n"
        "3. Realism review: a person familiar with real proposals completes `SP01_realism_checklist.md`.\n"
        "4. Freeze: only after steps 1 to 3 pass. Tag version 1.0, regenerate checksums and do not edit again.\n",
        encoding="utf-8")


def write_forms(d):
    HUMAN_DIR.mkdir(exist_ok=True)
    n = len(d["partners"])
    lines = [
        "# SP01 blind extraction form", "",
        "Status: EMPTY. Fill from SP01.pdf only. Do not open the answer key.", "",
        "Extractor: ____  Date: ____", "",
        "Rules: amounts in full euro (not thousand), dates as ISO 8601 (YYYY-MM-DD), write null for a field "
        "that is not stated in the document.", "",
        "| Field | Value | Page where found |", "|---|---|---|",
        "| Proposal acronym | | |", "| Proposal title | | |", "| Call identifier | | |",
        "| Funding programme | | |", "| Submission date | | |",
        "| Stated total requested amount | | |", "| TRL start | | |", "| TRL target | | |",
        "| MCRL start | | |", "| MCRL target | | |", "",
        "## Partners", "", "| No | Name as written in the consortium table | Requested amount | Page |",
        "|---|---|---|---|",
    ]
    for i in range(1, n + 1):
        lines.append(f"| {i} | | | |")
    lines += ["", "## Result", "", "Number of fields in agreement with the key (filled by the author): ____",
              "Initial agreement rate: ____", "Disagreements and fixes: ____"]
    (HUMAN_DIR / "SP01_blind_extraction_form.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    checklist = [
        "# SP01 realism review checklist", "",
        "Status: NOT DONE. Reviewer: a person familiar with real proposals. Reviewer: ____ Date: ____", "",
        "Judge whether a reader skimming the document would find it plausible. Tick yes or no and add a note.", "",
        "| Question | Yes | No | Note |", "|---|---|---|---|",
        "| The cover page looks like the cover of a real proposal | | | |",
        "| The table of contents and section order look familiar | | | |",
        "| The executive summary reads like a real one | | | |",
        "| The budget table looks like a real budget table | | | |",
        "| The consortium table looks like a real consortium table | | | |",
        "| The work package texts look plausible | | | |",
        "| The Gantt chart looks plausible | | | |",
        "| The deliverables list and risk register look plausible | | | |",
        "| Repeated filler paragraphs are not distracting when skimming | | | |",
        "| Nothing suggests that the document is a copy of a real proposal | | | |",
        "| Anything that looks implausible and should be changed | | | |",
    ]
    (HUMAN_DIR / "SP01_realism_checklist.md").write_text("\n".join(checklist) + "\n", encoding="utf-8")


def write_gold_set(key):
    """Gold set in the structure of the ByggMap gold file, built from the answer key."""
    f = key["fields"]
    gold = {
        "proposal": {
            "proposal_acronym": f["proposal_acronym"]["value"],
            "proposal_title": f["proposal_title"]["value"],
            "call_identifier": f["call_identifier"]["value"],
            "submission_date": f["submission_date"]["value"],
        },
        "proposal_facts": {
            "requested_total_cents": f["stated_total_requested_amount"]["value"],
            "trl_start": f["trl_start"]["value"],
            "trl_target": f["trl_target"]["value"],
            "mcrl_start": f["mcrl_start"]["value"],
            "mcrl_target": f["mcrl_target"]["value"],
        },
        "partners": [
            {"partner_name": p["name"]["value"], "requested_cents": p["requested_amount"]["value"]}
            for p in f["partners"]
        ],
        "metadata": {"extraction_timestamp": None, "source_file": None},
    }
    (ROOT / "SP01_gold_set.json").write_text(json.dumps(gold, indent=4, ensure_ascii=False) + "\n",
                                             encoding="utf-8")


def main():
    d = load_data()
    texts = page_texts()
    key = build_answer_key(d, texts)
    (ROOT / "SP01_answer_key.json").write_text(json.dumps(key, indent=2, ensure_ascii=False) + "\n",
                                               encoding="utf-8")
    write_gold_set(key)
    rows = build_manifest(d, texts, key)
    with open(ROOT / "SP01_manifest.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["issue_number", "source_papers", "page", "affected_field",
                                           "description", "expected_failure_mode"])
        w.writeheader()
        w.writerows(rows)
    write_partner_register(d)
    write_name_check(d)
    write_forms(d)
    print("answer key, manifest, partner register and human step material written")


if __name__ == "__main__":
    main()
