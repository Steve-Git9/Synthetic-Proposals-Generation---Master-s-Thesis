# Changelog

## 1.0 (candidate, not yet frozen), 2026-10-25

- First build of SP01 from seed 20261025.
- 66 page born digital PDF, formal collaborative proposal layout, nine partners.
- Answer key, manifest, partner register, datasheet and generation log created.
- Design decisions taken by the author before the build:
  - the call identifier does not name the funding programme, so that the programme appears only in the banner image;
  - the stated total requested amount is anchored to the budget table total row, the executive summary figure is a non authoritative distractor;
  - the no dash writing rule does not apply to the generated files.
- Open: name check, blind second extraction and realism review (see human_steps). The freeze is pending until these pass.
