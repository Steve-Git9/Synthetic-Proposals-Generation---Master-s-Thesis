#!/usr/bin/env python3
"""Generate every chart and diagram of SP01 from SP01_data.yaml and its seed.

All figures are saved as raster PNG files so that their text is not part of the PDF text layer.
That is intended: the funding programme name (banner) and the partner acronyms (Gantt chart)
must only be readable from an image.
"""
import random
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch

from sp01_common import load_data, BUILD_DIR

DPI = 200
NAVY = "#1f3a5f"
TEAL = "#2a7f8e"
SAND = "#e9e2d0"
GREY = "#5b6770"
LIGHT = "#dfe7ee"


def banner(data):
    fig = plt.figure(figsize=(7.0, 1.5), dpi=DPI)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 7.0)
    ax.set_ylim(0, 1.5)
    ax.axis("off")
    ax.add_patch(Rectangle((0, 0), 7.0, 1.5, color=NAVY))
    rng = random.Random(data["meta"]["seed"])
    # decorative woven pattern, generated from the seed
    for i in range(34):
        x = 4.2 + i * 0.085
        h = 0.25 + rng.random() * 1.0
        ax.add_patch(Rectangle((x, 0.0), 0.05, h, color=TEAL, alpha=0.55))
        ax.add_patch(Rectangle((x + 0.03, 1.5 - h * 0.6), 0.04, h * 0.6, color=SAND, alpha=0.35))
    ax.text(0.3, 0.80, data["identity"]["funding_programme"], color="white", fontsize=30,
            fontweight="bold", va="center", ha="left")
    fig.savefig(BUILD_DIR / "banner.png", dpi=DPI)
    plt.close(fig)


def gantt(data):
    wps = data["work_packages"]
    partners = {p["no"]: p for p in data["partners"]}
    dur = data["identity"]["duration_months"]
    fig, ax = plt.subplots(figsize=(7.2, 3.6), dpi=DPI)
    for i, w in enumerate(wps):
        y = len(wps) - i
        ax.barh(y, w["end"] - w["start"] + 1, left=w["start"] - 1, height=0.55, color=TEAL,
                edgecolor=NAVY)
        lead = partners[w["lead"]]["acronym"]
        ax.text(w["start"] - 1 + 0.4, y, f"Lead {lead}", va="center", ha="left", color="white",
                fontsize=7, fontweight="bold")
    ax.set_yticks([len(wps) - i for i in range(len(wps))])
    ax.set_yticklabels([f"WP{w['no']}" for w in wps], fontsize=8)
    ticks = list(range(0, dur + 1, 6))
    ax.set_xticks(ticks)
    ax.set_xticklabels([str(t) if t else "" for t in ticks], fontsize=8)
    ax.set_xlim(0, dur)
    ax.set_xlabel("Project month", fontsize=8)
    ax.grid(axis="x", color=LIGHT, linewidth=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(BUILD_DIR / "gantt.png", dpi=DPI)
    plt.close(fig)


def _box(ax, x, y, w, h, text, fc=LIGHT, fs=7.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=fc, ec=NAVY, lw=1.0))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, color=NAVY)


def _arrow(ax, x1, y1, x2, y2):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9,
                                 color=GREY, lw=1.0))


def concept(data):
    fig, ax = plt.subplots(figsize=(6.4, 2.3), dpi=DPI)
    ax.set_xlim(0, 6.4)
    ax.set_ylim(0, 2.3)
    ax.axis("off")
    labels = ["Collection", "Sorting", "Fibre recovery", "Spinning", "Fabric", "Use and return"]
    w, h = 0.90, 0.62
    for i, lab in enumerate(labels):
        x = 0.1 + i * 1.04
        _box(ax, x, 1.25, w, h, lab, fc=LIGHT if i % 2 == 0 else SAND, fs=6.6)
        if i < len(labels) - 1:
            _arrow(ax, x + w + 0.01, 1.56, x + 1.04 - 0.01, 1.56)
    _box(ax, 0.1, 0.2, 5.94, 0.55, "Shared quality data and decision support", fc="#cfe3e6")
    for i in (1, 3, 5):
        x = 0.1 + i * 1.04 + w / 2
        _arrow(ax, x, 0.77, x, 1.24)
    fig.savefig(BUILD_DIR / "fig_concept.png", dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def impact(data):
    rng = random.Random(data["meta"]["seed"] + 1)
    labels = ["Industrial uptake", "Scientific progress", "Policy support", "Skills and education"]
    vals = [0.9, 0.7, 0.55, 0.45]
    vals = [v * (0.95 + 0.1 * rng.random()) for v in vals]
    fig, ax = plt.subplots(figsize=(6.0, 2.2), dpi=DPI)
    ax.barh(labels[::-1], vals[::-1], color=[TEAL, TEAL, TEAL, NAVY][::-1])
    ax.set_xlim(0, 1.1)
    ax.set_xticks([0.0, 0.5, 1.0])
    ax.set_xticklabels(["low", "medium", "high"], fontsize=8)
    ax.tick_params(axis="y", labelsize=8)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(BUILD_DIR / "fig_impact.png", dpi=DPI)
    plt.close(fig)


def workplan(data):
    wps = data["work_packages"]
    fig, ax = plt.subplots(figsize=(6.4, 2.9), dpi=DPI)
    ax.set_xlim(0, 6.4)
    ax.set_ylim(0, 2.9)
    ax.axis("off")
    pos = {1: (0.2, 2.15), 2: (0.2, 1.1), 3: (1.75, 1.1), 4: (3.3, 1.1), 5: (4.85, 1.1),
           6: (3.3, 0.1), 7: (4.85, 2.15)}
    short = {1: "WP1 Management", 2: "WP2 Requirements", 3: "WP3 Recovery", 4: "WP4 Manufacturing",
             5: "WP5 Pilot", 6: "WP6 Assessment", 7: "WP7 Dissemination"}
    for no, (x, y) in pos.items():
        _box(ax, x, y, 1.35, 0.6, short[no], fc=SAND if no in (1, 7) else LIGHT)
    for a, b in [(2, 3), (3, 4), (4, 5)]:
        _arrow(ax, pos[a][0] + 1.36, pos[a][1] + 0.3, pos[b][0] - 0.01, pos[b][1] + 0.3)
    _arrow(ax, pos[3][0] + 0.9, pos[3][1] - 0.01, pos[6][0] + 0.2, pos[6][1] + 0.61)
    _arrow(ax, pos[6][0] + 1.2, pos[6][1] + 0.61, pos[5][0] + 0.2, pos[5][1] - 0.01)
    _arrow(ax, pos[5][0] + 0.68, pos[5][1] + 0.61, pos[7][0] + 0.68, pos[7][1] - 0.01)
    fig.savefig(BUILD_DIR / "fig_workplan.png", dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def main():
    BUILD_DIR.mkdir(exist_ok=True)
    data = load_data()
    banner(data)
    gantt(data)
    concept(data)
    impact(data)
    workplan(data)
    print("charts written to", BUILD_DIR)


if __name__ == "__main__":
    main()
