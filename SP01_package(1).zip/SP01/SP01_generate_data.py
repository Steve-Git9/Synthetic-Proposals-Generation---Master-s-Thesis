#!/usr/bin/env python3
"""Generate SP01_data.yaml from the recorded seed.

The data file is the single source for every target value, every distractor value and the
layout plan. Everything downstream (charts, template rendering, answer key) reads this file.
"""
import datetime
import math
import random

from sp01_common import save_data, eur_full, eur_thousand_1dp

SEED = 20261025
rng = random.Random(SEED)

UNIT = 10000  # one unit is 100 euro, expressed in euro cents


def rnd(x):
    return int(math.floor(x + 0.5))


def decompose(total_u, s_frac, o_frac):
    """Split total eligible costs (units of 100 euro) into personnel, subcontracting,
    other direct and indirect costs so that the parts add up exactly.
    Indirect costs are a flat quarter of personnel plus other direct costs, rounded."""
    s0 = rnd(total_u * s_frac)
    for d in (0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5):
        s = max(0, s0 + d)
        rest = total_u - s
        x0 = rnd(rest / 1.25)
        for x in (x0, x0 - 1, x0 + 1):
            if x + rnd(x * 0.25) == rest:
                o = rnd(x * o_frac)
                p = x - o
                i = rnd(x * 0.25)
                assert p + s + o + i == total_u
                return p, s, o, i
    raise RuntimeError("no exact decomposition")


# ---------------------------------------------------------------- fixed fictional content
IDENTITY_TEXT = dict(
    acronym="LOOPWEAVE",
    title="Circular Weaving of Recycled Fibre Value Chains",
    action_type="Collaborative research and innovation action",
    funding_programme="Horizon Europe",
)

PARTNER_DEFS = [
    # no, group, legal name, short, acronym, country, category, role, rate range, s_frac, o_frac
    (1, "Coordinator", "Kalevra Innovation Cluster Oy", "Kalevra", "KVC", "Finland", "other",
     "Coordinator", (0.85, 1.00), 0.02, 0.10),
    (2, "Companies", "Northbay Materials Oy", "Northbay", "NBM", "Finland", "company",
     "Beneficiary", (0.72, 0.80), 0.06, 0.14),
    (3, "Companies", "Corvane Polymer Systems AB", "Corvane", "CPS", "Sweden", "company",
     "Beneficiary", (0.72, 0.80), 0.05, 0.16),
    (4, "Companies", "Tessilo Process Engineering GmbH", "Tessilo", "TPE", "Germany", "company",
     "Beneficiary", (0.72, 0.80), 0.08, 0.12),
    (5, "Universities", "Rauvik University", "Rauvik", "RUV", "Finland", "university",
     "Beneficiary", (0.92, 1.00), 0.01, 0.09),
    (6, "Universities", "Elvaris University of Technology", "Elvaris", "ELV", "Netherlands",
     "university", "Beneficiary", (0.92, 1.00), 0.02, 0.11),
    (7, "Research organisations", "Sundmark Applied Research Institute", "Sundmark", "SARI",
     "Denmark", "research organisation", "Beneficiary", (0.90, 1.00), 0.04, 0.13),
    (8, "Research organisations", "Brenvik Institute for Sustainable Process Engineering",
     "Brenvik", "BISP", "Norway", "research organisation", "Beneficiary", (0.90, 1.00), 0.05, 0.10),
    (9, "Associated partner", "Lindfors Regional Development Agency", "Lindfors", "LRDA",
     "Finland", "public body", "Associated partner", None, 0.02, 0.12),
]
GROUP_ORDER = ["Coordinator", "Companies", "Universities", "Research organisations",
               "Associated partner"]


def main():
    # ------------------------------------------------------------ requested amounts
    total_u = rng.randint(34000, 57000)               # 3.4 to 5.7 million euro
    coord_share = rng.uniform(0.105, 0.145)
    r1 = rnd(total_u * coord_share)
    rest = total_u - r1
    funded = [d for d in PARTNER_DEFS if d[0] != 1 and d[8] is not None]
    weights = []
    for d in funded:
        if d[1] == "Companies":
            weights.append(rng.uniform(1.0, 1.6))
        elif d[1] == "Universities":
            weights.append(rng.uniform(1.3, 1.9))
        else:
            weights.append(rng.uniform(1.1, 1.7))
    wsum = sum(weights)
    req_u = {1: r1}
    for d, w in zip(funded, weights):
        req_u[d[0]] = rnd(rest * w / wsum)
    req_u[funded[-1][0]] += total_u - sum(req_u.values())
    req_u[9] = 0
    assert sum(req_u.values()) == total_u
    assert 0.10 <= req_u[1] / total_u <= 0.15

    # ------------------------------------------------------------ eligible costs and rates
    partners = []
    for d in PARTNER_DEFS:
        no, group, legal, short, acr, country, cat, role, rate_rng, s_frac, o_frac = d
        if no == 9:
            elig_u = rng.randint(800, 2000)
            rate = 0.0
        else:
            rate = rng.uniform(*rate_rng)
            elig_u = int(math.ceil(req_u[no] / rate))
            actual = req_u[no] / elig_u
            assert 0.70 <= actual <= 1.0, (no, actual)
            rate = actual
        p, s, o, i = decompose(elig_u, s_frac, o_frac)
        partners.append(dict(
            no=no, group=group, legal_name=legal, short_name=short, acronym=acr,
            country=country, category=cat, role=role,
            costs_cents=dict(personnel=p * UNIT, subcontracting=s * UNIT,
                             other_direct=o * UNIT, indirect=i * UNIT,
                             total_eligible=elig_u * UNIT),
            requested_cents=req_u[no] * UNIT,
            funding_rate=round(rate, 4),
        ))

    # ------------------------------------------------------------ difficulty flags
    note3_candidates = [p for p in partners if p["group"] == "Companies"]
    note3_partner = rng.choice(note3_candidates)["no"]
    wrap_partner = max(partners, key=lambda p: len(p["legal_name"]))["no"]
    for p in partners:
        p["budget_cell_requested"] = ("see note 3" if p["no"] == note3_partner
                                      else eur_thousand_1dp(p["requested_cents"]))
        p["requested_in_note_3"] = p["no"] == note3_partner
        p["wraps_in_budget_table"] = p["no"] == wrap_partner

    # ------------------------------------------------------------ totals
    cols = ["personnel", "subcontracting", "other_direct", "indirect", "total_eligible"]
    col_totals = {c: sum(p["costs_cents"][c] for p in partners) for c in cols}
    requested_total = sum(p["requested_cents"] for p in partners)
    eligible_total = col_totals["total_eligible"]
    other_costs_u = rnd(eligible_total / UNIT * rng.uniform(0.04, 0.09))
    project_cost = eligible_total + other_costs_u * UNIT
    avg_rate_pct = round(requested_total / eligible_total * 100, 1)
    assert project_cost >= requested_total
    assert 3_000_000_00 <= requested_total <= 6_000_000_00

    # ------------------------------------------------------------ dates and numbers
    sub = datetime.date(2027, 3, 1) + datetime.timedelta(days=rng.randint(0, 91))
    deadline = sub + datetime.timedelta(days=rng.randint(7, 28))
    trl_start = rng.randint(3, 5)
    market_readiness_pct = rng.randint(31, 68)
    duration = rng.choice([36, 42, 48])
    proposal_number = "9" + "".join(str(rng.randint(0, 9)) for _ in range(8))
    call_no = rng.randint(1, 5)
    item_no = rng.randint(1, 9)
    call_id = f"INNO-2027-{call_no:02d}-CIRCFIBRE-{item_no:02d}"

    months = ["January", "February", "March", "April", "May", "June", "July", "August",
              "September", "October", "November", "December"]

    def long_date(d):
        return f"{d.day} {months[d.month - 1]} {d.year}"

    # ------------------------------------------------------------ work packages
    wps = [
        dict(no=1, title="Project management and coordination", lead=1, start=1, end=duration),
        dict(no=2, title="Requirements and value chain analysis", lead=7, start=1, end=12),
        dict(no=3, title="Fibre recovery process development", lead=2, start=4, end=duration - 12),
        dict(no=4, title="Yarn and fabric manufacturing trials", lead=3, start=10, end=duration - 6),
        dict(no=5, title="Pilot demonstration and validation", lead=4, start=18, end=duration - 2),
        dict(no=6, title="Sustainability and standards assessment", lead=8, start=6, end=duration),
        dict(no=7, title="Dissemination, exploitation and communication", lead=5, start=1, end=duration),
    ]
    # support partners per work package (indices into partner list by partner number)
    support = {1: (9, 5), 2: (6, 1), 3: (8, 6), 4: (7, 2), 5: (3, 5), 6: (6, 9), 7: (1, 9)}
    for w in wps:
        w["support"] = list(support[w["no"]])

    # ------------------------------------------------------------ layout plan (page map)
    layout = dict(
        page_map=dict(
            cover=[1, 1], toc=[2, 2], exec_summary=[3, 4], section1=[5, 18], section2=[19, 30],
            section3=[31, 40], budget=[41, 43], section4=[44, 52], annexes=[53, 66],
        ),
        total_pages_target=66,
        # number of filler paragraphs per slot; slots named *_pad are tuned by the build
        filler_counts=dict(
            exec_a=1, exec_pad=2,
            s1_a=4, s1_b=3, s1_c=3, s1_pad=8,
            s2_a=4, s2_b=4, s2_pad=8,
            s3_a=3, s3_b=3, s3_pad=6,
            budget_a=1, budget_pad=0,
            s4_a=4, s4_b=2, s4_pad=6,
            annex_pad=10,
        ),
    )

    data = dict(
        meta=dict(
            document_id="SP01", version="1.0", seed=SEED,
            footer="Synthetic document for research purposes, ID SP01, version 1.0",
            language="English (European spelling)",
            pdf_title="SP01 synthetic proposal: " + IDENTITY_TEXT["title"],
            pdf_author="SP01 synthetic document generator",
            pdf_subject="SP01 synthetic test document for research purposes, version 1.0",
            generated_by="SP01_generate_data.py",
        ),
        identity=dict(
            acronym=IDENTITY_TEXT["acronym"], title=IDENTITY_TEXT["title"],
            call_identifier=call_id,
            funding_programme=IDENTITY_TEXT["funding_programme"],
            action_type=IDENTITY_TEXT["action_type"],
            submission_date_iso=sub.isoformat(), submission_date_text=long_date(sub),
            call_deadline_iso=deadline.isoformat(), call_deadline_text=long_date(deadline),
            proposal_number=proposal_number, duration_months=duration,
            contact_role="Project Coordinator",
        ),
        readiness=dict(
            trl_start=trl_start, trl_delta=2, trl_target=trl_start + 2,
            trl_delta_word="two", mcrl_start=None, mcrl_target=None,
            market_readiness_percent=market_readiness_pct,
        ),
        partners=partners,
        group_order=GROUP_ORDER,
        work_packages=wps,
        totals=dict(
            requested_cents=requested_total,
            eligible_cents=eligible_total,
            project_cost_cents=project_cost,
            other_costs_cents=other_costs_u * UNIT,
            column_totals_cents=col_totals,
            average_funding_rate_percent=avg_rate_pct,
            coordinator_share=round(partners[0]["requested_cents"] / requested_total, 4),
            note3_partner_no=note3_partner,
            wrap_partner_no=wrap_partner,
            partner_count=len(partners),
            country_count=len({p["country"] for p in partners}),
        ),
        surface=dict(
            budget_total_requested_k=eur_thousand_1dp(requested_total),
            budget_total_eligible_k=eur_thousand_1dp(eligible_total),
            exec_project_cost=eur_full(project_cost),
            exec_eligible=eur_full(eligible_total),
            exec_requested=eur_full(requested_total),
            exec_avg_rate=f"{avg_rate_pct:.1f} percent",
            note3_amount=eur_full(partners[note3_partner - 1]["requested_cents"]),
            note3_partner_requested_k=eur_thousand_1dp(partners[note3_partner - 1]["requested_cents"]),
            col_totals_k={c: eur_thousand_1dp(v) for c, v in col_totals.items()},
            count_word="nine", country_word={5: "five", 6: "six", 7: "seven"}.get(
                len({p["country"] for p in partners}), str(len({p["country"] for p in partners}))),
        ),
        layout=layout,
        footer_non_target_string="Synthetic document for research purposes, ID SP01, version 1.0",
        placements={},
    )
    save_data(data)
    print(f"SP01_data.yaml written. Requested total {eur_full(requested_total)}, "
          f"eligible {eur_full(eligible_total)}, project cost {eur_full(project_cost)}, "
          f"coordinator share {data['totals']['coordinator_share']:.3f}, "
          f"note 3 partner P{note3_partner}, wrapping partner P{wrap_partner}")


if __name__ == "__main__":
    main()
